import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/user_profile.dart';
import '../services/profile_service.dart';
import '../services/auth_service.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import '../providers/workout_provider.dart';

class AuthProvider with ChangeNotifier {
  final _profileService = ProfileService();
  final _supabase = Supabase.instance.client;
  final _authService = AuthService();
  final WorkoutProvider workoutProvider;

  User? _user;
  UserProfile? _userProfile;
  bool _isLoading = false;
  bool _hasAcceptedDisclaimer = false;
  bool _isNewUser = false;

  AuthProvider(this.workoutProvider);

  User? get user {
    if (_user == null) {
      _user = _supabase.auth.currentUser;
      if (_user != null && _userProfile == null) {
        loadUserProfile();
      }
    }
    return _user;
  }

  UserProfile? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  bool get hasAcceptedDisclaimer => _hasAcceptedDisclaimer;
  bool get isNewUser => _isNewUser;

  void setDisclaimerAccepted(bool accepted) {
    _hasAcceptedDisclaimer = accepted;
    notifyListeners();
  }

  Future<void> setUser(User? user) async {
    _user = user;
    if (user != null) {
      // Wait until the user appears in the database
      await Future.delayed(const Duration(milliseconds: 500));
      await loadUserProfile();
    } else {
      _userProfile = null;
      _hasAcceptedDisclaimer = false;
    }
    notifyListeners();
  }

  Future<void> loadUserProfile() async {
    try {
      _isLoading = true;
      notifyListeners();

      if (_user == null) {
        _userProfile = null;
        _isLoading = false;
        notifyListeners();
        return;
      }

      //debugPrint('Загрузка профиля для пользователя: ${_user!.id}');

      // Загружаем данные профиля из базы
      final response = await _supabase
          .from('user_profiles')
          .select('*')
          .eq('id', _user!.id)
          .single();

      if (response != null) {
        //debugPrint('Получен профиль из базы данных: ${response['id']}');
        //debugPrint(
            'Значение has_completed_survey в базе: ${response['has_completed_survey']}');

        // ВАЖНО: принудительно устанавливаем has_completed_survey из базы данных
        bool hasCompletedFromDb = response['has_completed_survey'] == true;

        _userProfile = UserProfile.fromJson(response);

        // Если значение hasCompletedSurvey в профиле не совпадает с базой
        if (_userProfile!.hasCompletedSurvey != hasCompletedFromDb) {
          //debugPrint(
              'Внимание: hasCompletedSurvey в профиле (${_userProfile!.hasCompletedSurvey}) ' +
                  'не соответствует значению в базе данных ($hasCompletedFromDb)');

          // Корректируем значение в профиле
          _userProfile =
              _userProfile!.copyWith(hasCompletedSurvey: hasCompletedFromDb);
          //debugPrint(
              'Исправлено значение в профиле: hasCompletedSurvey = ${_userProfile!.hasCompletedSurvey}');
        }

        // Явная проверка на hasCompletedSurvey
        final hasCompletedSurveyValue = response['has_completed_survey'];
        //debugPrint(
            'Загружен профиль, has_completed_survey из базы: $hasCompletedSurveyValue');
        //debugPrint(
            'После конвертации hasCompletedSurvey = ${_userProfile!.hasCompletedSurvey}');

        // Проверка наличия logs как индикатора пройденного опроса
        final logs = await _supabase
            .from('workout_logs')
            .select('id')
            .eq('user_id', _user!.id)
            .limit(1);

        // Если есть логи тренировок, то опрос точно должен быть пройден
        if (logs != null &&
            logs.isNotEmpty &&
            !_userProfile!.hasCompletedSurvey) {
          //debugPrint(
              'У пользователя есть логи тренировок, но hasCompletedSurvey = false. Исправляем...');
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
        }
      } else {
        //debugPrint('Профиль не найден в базе данных');
      }
    } catch (e) {
      //debugPrint('Ошибка при загрузке профиля: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<UserProfile?> getUserProfile(String userId) async {
    try {
      final response = await _supabase
          .from('user_profiles')
          .select()
          .eq('id', userId)
          .single();

      return UserProfile.fromJson(response);
    } catch (e) {
      //debugPrint('Error getting user profile: $e');
      return null;
    }
  }

  Future<bool> hasCompletedSurvey() async {
    if (user == null) return false;

    try {
      final response = await _supabase
          .from('user_profiles')
          .select('has_completed_survey')
          .eq('id', user!.id)
          .single();

      return response['has_completed_survey'] as bool;
    } catch (e) {
      //debugPrint('Error checking survey completion: $e');
      return false;
    }
  }

  Future<void> saveUserProfile(UserProfile profile) async {
    try {
      //debugPrint('Сохраняем профиль: ${profile.id}');
      //debugPrint('hasCompletedSurvey = ${profile.hasCompletedSurvey}');

      // Принудительно убеждаемся, что в базе данных флаг установлен правильно
      if (profile.hasCompletedSurvey) {
        await _supabase
            .from('user_profiles')
            .update({'has_completed_survey': true}).eq('id', profile.id);

        //debugPrint('Принудительно обновили has_completed_survey в базе');

        // Сохраняем флаг в метаданных пользователя
        await updateSurveyCompletionFlag(true);
      }

      // Сохраняем полный профиль
      await _supabase
          .from('user_profiles')
          .update(profile.toJson())
          .eq('id', profile.id);

      //debugPrint('Профиль сохранен через Supabase');

      // Обновляем локальный профиль
      _userProfile = profile;

      // Если hasCompletedSurvey == true, то пользователь больше не новый
      if (profile.hasCompletedSurvey) {
        _isNewUser = false;
        //debugPrint(
            'Profile saved with completed survey, isNewUser set to false');
      }

      notifyListeners();
      //debugPrint('Профиль успешно сохранен!');
    } catch (e) {
      //debugPrint('Ошибка при сохранении профиля: $e');
      rethrow;
    }
  }

  // Новый метод для обновления флага завершения опроса в метаданных пользователя
  Future<void> updateSurveyCompletionFlag(bool completed) async {
    try {
      if (_user == null) return;

      // Получаем текущие метаданные
      final currentMetadata = _user!.userMetadata ?? {};

      // Добавляем или обновляем флаг завершения опроса
      final updatedMetadata = {
        ...currentMetadata,
        'has_completed_survey': completed,
      };

      // Обновляем метаданные пользователя
      await _supabase.auth.updateUser(
        UserAttributes(
          data: updatedMetadata,
        ),
      );

      //debugPrint('Флаг завершения опроса обновлен в метаданных пользователя');
    } catch (e) {
      //debugPrint('Ошибка при обновлении метаданных пользователя: $e');
    }
  }

  // Проверка флага завершения опроса в метаданных пользователя
  bool hasSurveyCompletionFlag() {
    if (_user == null || _user!.userMetadata == null) return false;

    // Проверяем наличие флага в метаданных
    final metadata = _user!.userMetadata!;
    return metadata['has_completed_survey'] == true;
  }

  // Принудительно проверяет флаг завершения опроса непосредственно в базе данных
  Future<bool> checkSurveyCompletionInDatabase() async {
    if (_user == null) return false;

    try {
      // Проверяем профиль в базе данных
      final response = await _supabase
          .from('user_profiles')
          .select('has_completed_survey')
          .eq('id', _user!.id)
          .single();

      final hasCompletedSurveyInDb = response['has_completed_survey'] == true;
      //debugPrint('Флаг has_completed_survey в базе: $hasCompletedSurveyInDb');

      // Проверяем метаданные пользователя
      final userData = await _supabase.auth.getUser();
      final userMetadata = userData.user?.userMetadata;
      final hasCompletedSurveyInMeta =
          userMetadata != null && userMetadata['has_completed_survey'] == true;

      //debugPrint(
          'Флаг has_completed_survey в метаданных: $hasCompletedSurveyInMeta');

      // Если хотя бы один флаг установлен, возвращаем true
      return hasCompletedSurveyInDb || hasCompletedSurveyInMeta;
    } catch (e) {
      //debugPrint('Ошибка при проверке завершения опроса в базе: $e');
      return false;
    }
  }

  Future<void> updateUserProfile(UserProfile profile) async {
    if (user == null) throw Exception('No user logged in');

    try {
      _isLoading = true;
      notifyListeners();

      final profileData = profile.toJson();
      await _supabase
          .from('user_profiles')
          .update(profileData)
          .eq('id', user!.id);
      _userProfile = profile;
    } catch (e) {
      //debugPrint('Error updating user profile: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Инициализация при запуске
  Future<void> initialize() async {
    try {
      _isLoading = true;
      notifyListeners();

      // Проверяем текущего пользователя
      _user = _supabase.auth.currentUser;

      if (_user != null) {
        // Загружаем профиль пользователя
        await loadUserProfile();

        // Проверяем и синхронизируем флаг завершения опроса
        await syncSurveyCompletionFlag();

        // Загружаем статистику
        await workoutProvider.loadStatistics();
      }

      // Инициализируем слушатель изменений сессии
      _supabase.auth.onAuthStateChange.listen((data) async {
        final AuthChangeEvent event = data.event;
        final Session? session = data.session;

        if (event == AuthChangeEvent.signedIn) {
          setUser(session?.user);

          // При входе обновляем статистику
          await workoutProvider.loadStatistics();
        } else if (event == AuthChangeEvent.signedOut) {
          setUser(null);
        }
      });
    } catch (e) {
      //debugPrint('Error initializing AuthProvider: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Синхронизация флага завершения опроса между профилем и метаданными
  Future<void> syncSurveyCompletionFlag() async {
    if (_user == null || _userProfile == null) return;

    try {
      // Проверяем флаг в профиле
      final hasCompletedSurveyInProfile = _userProfile!.hasCompletedSurvey;

      // Проверяем флаг в метаданных
      final hasCompletedSurveyInMeta = hasSurveyCompletionFlag();

      //debugPrint(
          'Синхронизация флагов: в профиле = $hasCompletedSurveyInProfile, в метаданных = $hasCompletedSurveyInMeta');

      // Если хотя бы один из флагов true, устанавливаем оба в true
      if (hasCompletedSurveyInProfile || hasCompletedSurveyInMeta) {
        // Если флаг в профиле не установлен, обновляем профиль
        if (!hasCompletedSurveyInProfile) {
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
          //debugPrint('Флаг в профиле обновлен: hasCompletedSurvey = true');
        }

        // Если флаг в метаданных не установлен, обновляем метаданные
        if (!hasCompletedSurveyInMeta) {
          await updateSurveyCompletionFlag(true);
          //debugPrint('Флаг в метаданных обновлен: has_completed_survey = true');
        }
      }

      // Дополнительная проверка наличия тренировок
      final logs = await _supabase
          .from('workout_logs')
          .select('id')
          .eq('user_id', _user!.id)
          .limit(1);

      if (logs != null &&
          logs.isNotEmpty &&
          (!hasCompletedSurveyInProfile || !hasCompletedSurveyInMeta)) {
        //debugPrint(
            'Обнаружены логи тренировок, устанавливаем флаги завершения опроса');

        // Обновляем профиль
        if (!hasCompletedSurveyInProfile) {
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
        }

        // Обновляем метаданные
        if (!hasCompletedSurveyInMeta) {
          await updateSurveyCompletionFlag(true);
        }
      }
    } catch (e) {
      //debugPrint('Ошибка при синхронизации флага завершения опроса: $e');
    }
  }

  Future<void> signUp(String email, String password) async {
    try {
      //print('Starting signUp in AuthProvider');
      _isLoading = true;
      notifyListeners();

      // Регистрация пользователя
      final response = await _supabase.auth.signUp(
        email: email,
        password: password,
        data: {
          "email": email,
        },
      );

      //print('Supabase auth.signUp response received');
      //print('User in response: ${response.user?.id}');
      //print('Session in response: ${response.session != null}');

      if (response.user == null) {
        throw Exception('Registration failed');
      }

      // Если регистрация успешна, но сессия не создана, выполняем явный вход
      if (response.session == null) {
        //print('No session created during signup, performing explicit sign in');
        final signInResponse = await _supabase.auth.signInWithPassword(
          email: email,
          password: password,
        );

        if (signInResponse.user == null) {
          throw Exception('Auto sign-in after registration failed');
        }

        _user = signInResponse.user;
        //print('User signed in after registration: ${_user?.id}');
      } else {
        _user = response.user;
        //print('User registered successfully with session: ${_user?.id}');
      }

      // SQL триггер создаст базовый профиль, получаем его
      await Future.delayed(
          Duration(milliseconds: 500)); // Даем время триггеру сработать
      await loadUserProfile();

      return;
    } catch (e) {
      //print('Error during signup: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> createInitialProfile() async {
    try {
      // Сначала проверяем пользователя в currentUser
      User? currentUser = _supabase.auth.currentUser;

      // Если currentUser null, проверяем в currentSession
      if (currentUser == null) {
        final session = _supabase.auth.currentSession;
        if (session != null) {
          currentUser = session.user;
          //print('Using user from session: ${currentUser.id}');
        }
      }

      if (currentUser == null) {
        //print('No user logged in - cannot create profile');
        throw Exception('No user logged in');
      }

      // Проверяем, существует ли уже профиль
      //print('Checking if profile exists for user: ${currentUser.id}');
      final existingProfile =
          await _profileService.getProfile(userId: currentUser.id);

      if (existingProfile != null) {
        //print('Profile already exists, not creating a new one');
        _userProfile = existingProfile;
        // Важно: проверяем и устанавливаем флаг isNewUser
        _isNewUser = !existingProfile.hasCompletedSurvey;
        //debugPrint(
            'Profile exists, isNewUser set to: $_isNewUser, hasCompletedSurvey: ${existingProfile.hasCompletedSurvey}');
        notifyListeners();
        return;
      }

      //print(
          'Profile does not exist, creating new profile for user: ${currentUser.id}');

      // Сначала проверяем метаданные Supabase
      String? userName;
      String? avatarUrl;

      if (currentUser.userMetadata != null) {
        final metadata = currentUser.userMetadata!;

        if (metadata.containsKey('full_name')) {
          userName = metadata['full_name'] as String?;
        } else if (metadata.containsKey('name')) {
          userName = metadata['name'] as String?;
        } else if (metadata.containsKey('user_name')) {
          userName = metadata['user_name'] as String?;
        } else if (metadata.containsKey('display_name')) {
          userName = metadata['display_name'] as String?;
        }

        if (metadata.containsKey('avatar_url')) {
          avatarUrl = metadata['avatar_url'] as String?;
        } else if (metadata.containsKey('picture')) {
          avatarUrl = metadata['picture'] as String?;
        } else if (metadata.containsKey('photo_url')) {
          avatarUrl = metadata['photo_url'] as String?;
        }

        if (userName != null) {
          //debugPrint('Using name from Supabase metadata: $userName');
        }
        if (avatarUrl != null) {
          //debugPrint('Using avatar from Supabase metadata: $avatarUrl');
        }
      }

      // Если нет данных в метаданных, пытаемся получить из Google
      if (userName == null) {
        final googleAccount = await _authService.getGoogleUserData();
        if (googleAccount != null) {
          userName = googleAccount.displayName;
          avatarUrl = googleAccount.photoUrl ?? avatarUrl;
          //debugPrint('Using Google account data for profile: $userName');
        }
      }

      // Если нет данных из Google, пробуем из Apple
      if (userName == null) {
        final appleUserData = await _authService.getAppleUserData();
        if (appleUserData != null &&
            appleUserData.containsKey('full_name') &&
            appleUserData['full_name'] != null) {
          userName = appleUserData['full_name'] as String;
          //debugPrint('Using Apple account data for profile: $userName');
        }
      }

      // Если нет данных ни из метаданных, ни из Google, ни из Apple, используем email
      if (userName == null || userName.isEmpty) {
        userName = currentUser.email?.split('@')[0] ?? 'User';
        //debugPrint('Using email for profile name: $userName');
      }

      final defaultBirthDate =
          DateTime.now().subtract(const Duration(days: 365 * 25));

      try {
        // Создаем базовый профиль с минимальным количеством полей
        final Map<String, dynamic> profileData = {
          'id': currentUser.id,
          'email': currentUser.email,
          'full_name': userName,
          'birth_date': defaultBirthDate.toIso8601String(),
          'gender': 'Prefer not to say',
          'height': 170,
          'weight': 70,
          'fitness_level': 'Beginner',
          'weekly_workouts': '3-4 times per week',
          'workout_duration': '30-45 minutes',
          'goals': ['General health improvement'],
          'equipment': ['Bodyweight'],
          'has_completed_survey':
              false // Важно: устанавливаем false для новых профилей
        };

        // Если есть avatarUrl, добавляем его
        if (avatarUrl != null && avatarUrl.isNotEmpty) {
          profileData['avatar_url'] = avatarUrl;
        }

        //print('Attempting direct upsert with profile data: $profileData');

        // Прямой вызов вместо использования метода класса
        await _supabase.from('user_profiles').upsert(profileData);

        //print('Profile inserted successfully via direct upsert');

        // Создаем объект профиля
        final defaultProfile = UserProfile(
          id: currentUser.id,
          email: currentUser.email,
          fullName: userName,
          avatarUrl: avatarUrl,
          birthDate: defaultBirthDate,
          weight: 70.0,
          height: 170.0,
          gender: 'Prefer not to say',
          fitnessLevel: 'Beginner',
          weeklyWorkouts: '3-4 times per week',
          workoutDuration: '30-45 minutes',
          goals: ['General health improvement'],
          equipment: ['Bodyweight'],
          hasCompletedSurvey: false, // Важно: явно устанавливаем false
        );

        _userProfile = defaultProfile;
        _isNewUser =
            true; // Важно: явно устанавливаем true для новых пользователей
        //debugPrint('New profile created, isNewUser set to: true');
        notifyListeners();

        //print('Profile created successfully');
      } catch (innerE) {
        //print('Error during upsert: $innerE');
        // Пробуем альтернативный подход - через insert
        try {
          //print('Trying insert instead of upsert');
          final Map<String, dynamic> simpleProfileData = {
            'id': currentUser.id,
            'full_name': userName,
            'birth_date': defaultBirthDate.toIso8601String(),
            'gender': 'Prefer not to say',
            'height': 170,
            'weight': 70,
            'fitness_level': 'Beginner',
            'weekly_workouts': '3-4 times per week',
            'workout_duration': '30-45 minutes',
            'goals': ['General health improvement'],
            'equipment': ['Bodyweight'],
            'has_completed_survey': false
          };

          // Если есть avatarUrl, добавляем его
          if (avatarUrl != null && avatarUrl.isNotEmpty) {
            simpleProfileData['avatar_url'] = avatarUrl;
          }

          await _supabase.from('user_profiles').insert(simpleProfileData);
          //print('Profile inserted successfully via direct insert');

          // Загружаем созданный профиль
          await loadUserProfile();
        } catch (insertE) {
          //print('Error during insert: $insertE');

          // Если все методы не сработали, пробуем SQL запрос напрямую
          try {
            //print('Trying direct SQL query');
            final birthDateStr =
                defaultBirthDate.toIso8601String().split('T')[0];

            // Экранируем имя пользователя для SQL
            final sanitizedName = userName.replaceAll("'", "''");

            String query;
            if (avatarUrl != null && avatarUrl.isNotEmpty) {
              // SQL с аватаром
              final sanitizedAvatarUrl = avatarUrl.replaceAll("'", "''");
              query = '''
INSERT INTO user_profiles (
  id, full_name, birth_date, gender, height, weight, 
  fitness_level, weekly_workouts, workout_duration, 
  goals, equipment, has_completed_survey, avatar_url
) VALUES (
  '${currentUser.id}', 
  '$sanitizedName', 
  '$birthDateStr', 
  'Prefer not to say', 
  170, 
  70, 
  'Beginner', 
  '3-4 times per week', 
  '30-45 minutes', 
  ARRAY['General health improvement'], 
  ARRAY['Bodyweight'], 
  false,
  '$sanitizedAvatarUrl'
)
ON CONFLICT (id) DO NOTHING;
''';
            } else {
              // SQL без аватара
              query = '''
INSERT INTO user_profiles (
  id, full_name, birth_date, gender, height, weight, 
  fitness_level, weekly_workouts, workout_duration, 
  goals, equipment, has_completed_survey
) VALUES (
  '${currentUser.id}', 
  '$sanitizedName', 
  '$birthDateStr', 
  'Prefer not to say', 
  170, 
  70, 
  'Beginner', 
  '3-4 times per week', 
  '30-45 minutes', 
  ARRAY['General health improvement'], 
  ARRAY['Bodyweight'], 
  false
)
ON CONFLICT (id) DO NOTHING;
''';
            }

            await _supabase.rpc('run_sql', params: {'query': query});
            //print('Profile created via direct SQL');

            // Загружаем созданный профиль
            await loadUserProfile();
          } catch (sqlE) {
            //print('Error during direct SQL: $sqlE');
            throw Exception('Failed to create profile after multiple attempts');
          }
        }
      }
    } catch (e) {
      //print('Error creating profile: $e');
      rethrow;
    }
  }

  // Проверяем, завершил ли пользователь регистрацию
  Future<bool> hasCompletedRegistration() async {
    if (_userProfile == null) await loadUserProfile();

    //debugPrint('hasCompletedRegistration called');

    // Если профиль не найден или не заполнен, считаем это первым входом
    if (_userProfile == null) {
      //debugPrint('hasCompletedRegistration: profile is null, returning false');
      return false;
    }

    // Явно используем hasCompletedSurvey для определения, завершен ли опрос
    final hasCompleted = _userProfile!.hasCompletedSurvey;
    //debugPrint('hasCompletedRegistration: hasCompletedSurvey = $hasCompleted');

    return hasCompleted;
  }

  Future<void> signIn(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      final response = await _supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user == null) {
        throw Exception('Login failed');
      }

      _user = response.user;

      // Загружаем профиль пользователя
      await loadUserProfile();

      // Если профиля нет (что странно, т.к. должен создаваться автоматически), создаем его
      if (_userProfile == null) {
        await createInitialProfile();
      }

      // После успешного входа загружаем данные
      await workoutProvider.loadWorkoutLogs();
    } catch (e) {
      //debugPrint('Error during signin: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Добавим метод для проверки авторизации
  Future<bool> checkAuth() async {
    if (_user == null) {
      _user = _supabase.auth.currentUser;
      if (_user != null) {
        await loadUserProfile();
      }
    }
    return _user != null;
  }

  // Метод для удаления аккаунта
  Future<void> deleteAccount() async {
    try {
      _isLoading = true;
      notifyListeners();

      // Получение текущего пользователя
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) {
        throw Exception('No user logged in');
      }

      // Используем AuthService для удаления аккаунта
      await _authService.deleteAccount();

      // Сброс состояния провайдера
      _user = null;
      _userProfile = null;
      _hasAcceptedDisclaimer = false;
      _isNewUser = false;

      //debugPrint('Account successfully deleted');
    } catch (e) {
      //debugPrint('Error deleting account: $e');
      // Важно: переброс ошибки позволит UI коду выполнить собственную обработку
      rethrow;
    } finally {
      // Обязательное завершение независимо от результата
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> resendVerificationEmail(String email) async {
    try {
      await _supabase.auth.resend(
        type: OtpType.signup,
        email: email,
      );
      //debugPrint('Verification email sent to $email');
    } catch (e) {
      //debugPrint('Error resending verification email: $e');
      rethrow;
    }
  }

  Future<void> updateWorkoutStats({
    required int addSets,
    required double addHours,
  }) async {
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      await _profileService.updateWorkoutStats(
        userId: userId,
        addSets: addSets,
        addHours: addHours,
      );

      await loadUserProfile(); // Перезагружаем профиль
    } catch (e) {
      //print('Error updating workout stats: $e');
      rethrow;
    }
  }

  // Метод для входа через Apple ID
  Future<void> signInWithApple() async {
    try {
      _isLoading = true;
      notifyListeners();

      //debugPrint('Starting Apple Sign In...');

      // Используем AuthService для входа через Apple
      final response = await _authService.signInWithApple();

      if (response?.user == null) {
        throw Exception('Apple sign in failed: No user object returned');
      }

      _user = response!.user;
      //debugPrint('Apple Sign In successful for user: ${_user?.id}');

      // Дадим время на создание профиля в базе данных (триггеры Supabase)
      await Future.delayed(const Duration(milliseconds: 800));

      // Получаем данные из Apple аккаунта через AuthService
      final appleUserData = await _authService.getAppleUserData();

      // Загружаем или создаем профиль пользователя с повторными попытками
      int profileRetries = 0;
      const maxProfileRetries = 3;
      bool isNewUser = false;

      while (profileRetries < maxProfileRetries) {
        await loadUserProfile();

        if (_userProfile != null) {
          // Проверяем, есть ли у профиля установленный флаг hasCompletedSurvey
          isNewUser = !_userProfile!.hasCompletedSurvey;
          //debugPrint(
              'Profile loaded with hasCompletedSurvey=${_userProfile!.hasCompletedSurvey}, setting isNewUser=$isNewUser');

          // Проверяем, есть ли у пользователя данные имени из Apple
          if (appleUserData != null &&
              appleUserData.containsKey('full_name') &&
              appleUserData['full_name'] != null) {
            // Обновляем профиль с именем из Apple
            final fullName = appleUserData['full_name'] as String;
            if (fullName.isNotEmpty) {
              final updatedProfile = _userProfile!.copyWith(
                fullName: fullName,
              );

              await _profileService.updateProfile(updatedProfile);
              _userProfile = updatedProfile;
              //debugPrint('Updated profile with Apple account name: $fullName');
            }
          }

          //debugPrint('User profile loaded successfully');
          break;
        }

        //debugPrint(
            'Profile not found, retry ${profileRetries + 1}/${maxProfileRetries}');
        await Future.delayed(
            Duration(milliseconds: 1000 * (profileRetries + 1)));
        profileRetries++;
      }

      // Если профиля нет, создаем новый
      if (_userProfile == null) {
        //debugPrint('Creating initial profile after Apple Sign In');
        await createInitialProfile();
        isNewUser = true;
        //debugPrint('Created new profile, setting isNewUser=true');
      }

      // Проверка, правильно ли установлен флаг hasCompletedSurvey
      if (_userProfile != null) {
        //debugPrint(
            'Before loading workout logs: hasCompletedSurvey=${_userProfile!.hasCompletedSurvey}');
      }

      // Загружаем данные workout логов
      //debugPrint('Loading workout logs after Apple Sign In');
      await workoutProvider.loadWorkoutLogs();

      // Еще раз проверяем, что флаг hasCompletedSurvey установлен правильно
      if (_userProfile != null) {
        // Проверяем базу данных напрямую, чтобы убедиться, что профиль обновлен
        final dbProfile = await _profileService.getProfile(userId: _user!.id);
        if (dbProfile != null) {
          //debugPrint(
              'DB Profile hasCompletedSurvey=${dbProfile.hasCompletedSurvey}');

          // Если в БД и в памяти разные значения, синхронизируем
          if (dbProfile.hasCompletedSurvey !=
              _userProfile!.hasCompletedSurvey) {
            _userProfile = dbProfile;
            isNewUser = !dbProfile.hasCompletedSurvey;
            //debugPrint('Updated isNewUser from DB: $isNewUser');
          }
        }
      }

      //debugPrint(
          'Apple Sign In and data loading complete, isNewUser=$isNewUser');

      // Возвращаем информацию, новый ли это пользователь, чтобы внешний код мог решить,
      // показывать ли опрос
      _isNewUser = isNewUser;
    } catch (e) {
      //debugPrint('Error during Apple sign in: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Метод для входа через Google
  Future<void> signInWithGoogle() async {
    try {
      _isLoading = true;
      notifyListeners();

      //debugPrint('Starting Google Sign In...');

      // Используем AuthService для входа через Google
      final response = await _authService.signInWithGoogle();

      if (response?.user == null) {
        throw Exception('Google sign in failed: No user object returned');
      }

      _user = response!.user;
      //debugPrint('Google Sign In successful for user: ${_user?.id}');

      // Дадим время на создание профиля в базе данных (триггеры Supabase)
      await Future.delayed(const Duration(milliseconds: 800));

      // Получаем данные из Google аккаунта через AuthService
      final googleAccount = await _authService.getGoogleUserData();

      // Загружаем или создаем профиль пользователя с повторными попытками
      int profileRetries = 0;
      const maxProfileRetries = 3;
      bool isNewUser = false;

      while (profileRetries < maxProfileRetries) {
        await loadUserProfile();

        if (_userProfile != null) {
          // Проверяем, есть ли у профиля установленный флаг hasCompletedSurvey
          isNewUser = !_userProfile!.hasCompletedSurvey;
          //debugPrint(
              'Profile loaded with hasCompletedSurvey=${_userProfile!.hasCompletedSurvey}, setting isNewUser=$isNewUser');

          // Обновляем профиль данными из Google
          if (googleAccount != null) {
            final updatedProfile = _userProfile!.copyWith(
              fullName: googleAccount.displayName ?? _userProfile!.fullName,
              avatarUrl: googleAccount.photoUrl ?? _userProfile!.avatarUrl,
            );

            await _profileService.updateProfile(updatedProfile);
            _userProfile = updatedProfile;
            //debugPrint('Updated profile with Google account data');
          }

          //debugPrint('User profile loaded successfully');
          break;
        }

        //debugPrint(
            'Profile not found, retry ${profileRetries + 1}/${maxProfileRetries}');
        await Future.delayed(
            Duration(milliseconds: 1000 * (profileRetries + 1)));
        profileRetries++;
      }

      // Если профиля нет, создаем новый
      if (_userProfile == null) {
        //debugPrint('Creating initial profile after Google Sign In');
        await createInitialProfile();
        isNewUser = true;
        //debugPrint('Created new profile, setting isNewUser=true');
      }

      // Проверка, правильно ли установлен флаг hasCompletedSurvey
      if (_userProfile != null) {
        //debugPrint(
            'Before loading workout logs: hasCompletedSurvey=${_userProfile!.hasCompletedSurvey}');
      }

      // Загружаем данные workout логов
      //debugPrint('Loading workout logs after Google Sign In');
      await workoutProvider.loadWorkoutLogs();

      // Еще раз проверяем, что флаг hasCompletedSurvey установлен правильно
      if (_userProfile != null) {
        // Проверяем базу данных напрямую, чтобы убедиться, что профиль обновлен
        final dbProfile = await _profileService.getProfile(userId: _user!.id);
        if (dbProfile != null) {
          //debugPrint(
              'DB Profile hasCompletedSurvey=${dbProfile.hasCompletedSurvey}');

          // Если в БД и в памяти разные значения, синхронизируем
          if (dbProfile.hasCompletedSurvey !=
              _userProfile!.hasCompletedSurvey) {
            _userProfile = dbProfile;
            isNewUser = !dbProfile.hasCompletedSurvey;
            //debugPrint('Updated isNewUser from DB: $isNewUser');
          }
        }
      }

      //debugPrint(
          'Google Sign In and data loading complete, isNewUser=$isNewUser');

      // Возвращаем информацию, новый ли это пользователь, чтобы внешний код мог решить,
      // показывать ли опрос
      _isNewUser = isNewUser;
    } catch (e) {
      //debugPrint('Error during Google sign in: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Метод для выхода из аккаунта
  Future<void> signOut() async {
    try {
      _isLoading = true;
      notifyListeners();

      //debugPrint('Signing out user...');

      // Проверяем, есть ли активная сессия
      final currentSession = _supabase.auth.currentSession;
      final currentUser = _supabase.auth.currentUser;

      if (currentUser != null) {
        //debugPrint('Current user found: ${currentUser.id}');
      } else {
        //debugPrint('No active user found');
      }

      if (currentSession != null) {
        //debugPrint('Current session found, signing out');
      } else {
        //debugPrint('No active session found');
      }

      // Выполняем выход
      await _supabase.auth.signOut();
      //debugPrint('Supabase auth signOut completed');

      // Проверяем, действительно ли пользователь вышел
      final postSignOutUser = _supabase.auth.currentUser;
      if (postSignOutUser == null) {
        //debugPrint('Sign out successful: no current user detected');
      } else {
        //debugPrint(
            'Warning: User still detected after signOut: ${postSignOutUser.id}');
      }

      // Сбрасываем данные пользователя
      _user = null;
      _userProfile = null;
      _hasAcceptedDisclaimer = false;

      //debugPrint('User signed out successfully');

      // Обновляем UI, чтобы приложение знало, что пользователь вышел
      notifyListeners();
    } catch (e) {
      //debugPrint('Error during sign out: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Метод для прямой проверки столбца has_completed_survey в базе данных
  Future<bool> forceCheckSurveyCompletionInDatabase() async {
    if (_user == null) return false;

    try {
      //debugPrint('===== НАЧАЛО ПОЛНОЙ ПРОВЕРКИ ПРОХОЖДЕНИЯ ОПРОСА =====');

      // 1. Прямой запрос к Supabase для проверки значения has_completed_survey в профиле
      final response = await _supabase
          .from('user_profiles')
          .select('has_completed_survey, height, weight')
          .eq('id', _user!.id)
          .single();

      // Получаем значение из ответа
      final hasCompletedSurvey = response['has_completed_survey'] == true;

      //debugPrint(
          '1. Проверка has_completed_survey в базе = $hasCompletedSurvey');

      // Если флаг установлен в true в базе данных, это главный признак
      if (hasCompletedSurvey) {
        //debugPrint('Флаг установлен в базе данных, опрос считается пройденным');

        // Обновляем локальные данные
        if (_userProfile != null && !_userProfile!.hasCompletedSurvey) {
          _userProfile = _userProfile!.copyWith(hasCompletedSurvey: true);
          notifyListeners();
        }

        // Обновляем метаданные
        await updateSurveyCompletionFlag(true);

        return true;
      }

      // 2. Проверяем метаданные пользователя
      final userData = await _supabase.auth.getUser();
      final userMetadata = userData.user?.userMetadata;
      final hasCompletedInMetadata =
          userMetadata != null && userMetadata['has_completed_survey'] == true;

      //debugPrint('2. Проверка метаданных = $hasCompletedInMetadata');

      if (hasCompletedInMetadata) {
        //debugPrint('Флаг установлен в метаданных, опрос считается пройденным');

        // Обновляем флаг в профиле, так как метаданные говорят, что опрос пройден
        if (_userProfile != null) {
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
        } else {
          // Принудительно обновляем базу данных
          await _supabase
              .from('user_profiles')
              .update({'has_completed_survey': true}).eq('id', _user!.id);
        }

        return true;
      }

      // 3. Проверяем наличие логов тренировок
      final logs = await _supabase
          .from('workout_logs')
          .select('id')
          .eq('user_id', _user!.id)
          .limit(1);

      final hasWorkoutLogs = logs != null && logs.isNotEmpty;
      //debugPrint('3. Наличие логов тренировок = $hasWorkoutLogs');

      if (hasWorkoutLogs) {
        //debugPrint('Найдены логи тренировок, опрос считается пройденным');

        // Обновляем флаги везде
        if (_userProfile != null) {
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
        } else {
          // Принудительно обновляем базу данных
          await _supabase
              .from('user_profiles')
              .update({'has_completed_survey': true}).eq('id', _user!.id);
        }

        // Обновляем метаданные
        await updateSurveyCompletionFlag(true);

        return true;
      }

      // 4. Проверяем наличие роста и веса
      final height = response['height'];
      final weight = response['weight'];

      final hasHeightAndWeight = height != null &&
          weight != null &&
          height.toString() != '0' &&
          weight.toString() != '0';

      //debugPrint(
          '4. Наличие роста и веса = $hasHeightAndWeight (height=$height, weight=$weight)');

      if (hasHeightAndWeight) {
        //debugPrint('Профиль содержит рост и вес, опрос считается пройденным');

        // Обновляем флаги везде
        if (_userProfile != null) {
          final updatedProfile =
              _userProfile!.copyWith(hasCompletedSurvey: true);
          await saveUserProfile(updatedProfile);
        } else {
          // Принудительно обновляем базу данных
          await _supabase
              .from('user_profiles')
              .update({'has_completed_survey': true}).eq('id', _user!.id);
        }

        // Обновляем метаданные
        await updateSurveyCompletionFlag(true);

        return true;
      }

      //debugPrint(
          '===== Ни один из признаков прохождения опроса не найден =====');
      return false;
    } catch (e) {
      //debugPrint('Ошибка при проверке завершения опроса: $e');
      return false;
    }
  }
}
