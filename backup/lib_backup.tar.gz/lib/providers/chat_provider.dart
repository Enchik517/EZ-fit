import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart' as provider_pkg;
import '../models/chat_message.dart';
import '../services/chat_service.dart' as chat_service hide ChatMessage;
import '../services/survey_service.dart';
import '../models/workout.dart';
import '../models/exercise.dart';
import '../models/ai_workout_plan.dart';
import '../providers/workout_provider.dart';
import '../main.dart'; // Для доступа к navigatorKey
import 'package:supabase_flutter/supabase_flutter.dart' hide Provider;
import 'package:uuid/uuid.dart';
import '../services/chat_functions.dart';

class ChatProvider with ChangeNotifier {
  final _uuid = Uuid();
  final _supabase = Supabase.instance.client;
  final List<ChatMessage> _messages = [];
  final chat_service.ChatService _chatService;
  final SurveyService _surveyService = SurveyService();
  bool _isLoading = false;
  String? _currentText;
  Map<String, dynamic>? _lastWorkoutSuggestion;
  double? _savedScrollPosition;
  ScrollController get scrollController => _chatService.scrollController;

  ChatProvider(this._chatService) {
    _initializeSubscription();
    _chatService.scrollController.addListener(_saveScrollPosition);
  }

  void _saveScrollPosition() {
    if (_chatService.scrollController.hasClients) {
      _savedScrollPosition = _chatService.scrollController.position.pixels;
    }
  }

  void _restoreScrollPosition() {
    if (_savedScrollPosition != null && _chatService.scrollController.hasClients) {
      _chatService.scrollController.jumpTo(_savedScrollPosition!);
    }
  }

  void _initializeSubscription() {
    _chatService.messagesStream.listen(
      (messages) {
        _messages.clear();
        _messages.addAll(messages);
        notifyListeners();
        // Restore scroll position after messages are loaded
        Future.delayed(const Duration(milliseconds: 100), _restoreScrollPosition);
      },
      onError: (error) {
        //debugPrint('Error in chat subscription: $error');
      },
    );
  }

  List<ChatMessage> get messages => List.unmodifiable(_messages);
  bool get isLoading => _isLoading;

  Map<String, dynamic>? get lastWorkoutSuggestion => _lastWorkoutSuggestion;

  set lastWorkoutSuggestion(Map<String, dynamic>? workout) {
    _lastWorkoutSuggestion = workout;
    notifyListeners();
  }

  String _generateMessageId() {
    return _uuid.v4();
  }

  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    _isLoading = true;
    _currentText = text;
    notifyListeners();

    try {
      await _chatService.sendMessage(text);
    } catch (e) {
      //debugPrint('Error sending message: $e');
      _messages.add(ChatMessage(
        id: _generateMessageId(),
        userId: 'ai',
        content: 'Error: Failed to get response from AI',
        isUser: false,
        chatId: 'default',
        createdAt: DateTime.now(),
      ));
      notifyListeners();
    } finally {
      _isLoading = false;
      _currentText = null;
      notifyListeners();
    }
  }

  Future<void> clearHistory() async {
    try {
      await _chatService.clearHistory();
      notifyListeners();
    } catch (e) {
      //debugPrint('Error clearing history: $e');
    }
  }

  Future<void> deleteMessages(List<ChatMessage> messages) async {
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      // Delete messages from chat_messages table
      final messageIds = messages.map((m) => m.id).toList();
      await _supabase
          .from('chat_messages')
          .delete()
          .filter('id', 'in', messageIds)
          .eq('user_id', userId);
      
      // Update local state
      _messages.removeWhere((m) => messageIds.contains(m.id));
      notifyListeners();
    } catch (e) {
      //debugPrint('Error deleting messages: $e');
    }
  }

  Future<void> sendImage(String imagePath) async {
    try {
      final imageUrl = await _chatService.sendImage(imagePath);
      await _chatService.sendMessage('Sent an image', imageUrl: imageUrl);
    } catch (e) {
      //debugPrint('Error sending image: $e');
    }
  }

  Future<void> saveWorkout(Map<String, dynamic> workout) async {
    await _chatService.saveWorkout(workout);
    _lastWorkoutSuggestion = null;
    notifyListeners();
  }

  void dispose() {
    _chatService.dispose();
  }
} 