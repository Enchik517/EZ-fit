import 'package:flutter/foundation.dart';
import 'package:superwallkit_flutter/superwallkit_flutter.dart';

/// Сервис для взаимодействия с Superwall SDK
class SuperwallService {
  static final SuperwallService _instance = SuperwallService._internal();

  /// Статический метод для получения синглтона
  factory SuperwallService() => _instance;

  SuperwallService._internal();

  /// Проверяет, запущено ли приложение на iOS
  bool get _isIOS => defaultTargetPlatform == TargetPlatform.iOS;

  /// Инициализирует SDK Superwall
  Future<void> initialize() async {
    try {
      // Создаем объект опций и отключаем любые проверки, которые могут блокировать показ
      final options = SuperwallOptions();
      options.paywalls.shouldPreload = true;

      // Сбросим пользователя и его статус при инициализации
      if (Superwall.shared != null) {
        Superwall.shared.reset();
      }

      // Инициализация SDK с API ключом и опциями
      await Superwall.configure(
        'pk_a8d000b9824387f66332c9958e30bfad0e9b22ec844b52fc',
        options: options,
      );

      //debugPrint('Superwall успешно инициализирован');
    } catch (e) {
      //debugPrint('Ошибка при инициализации Superwall: $e');
    }
  }

  /// Показывает paywall при регистрации placement
  Future<void> registerPaywallForPlacement(String placement) async {
    try {
      // Вместо прямого вызова paywall, показываем промежуточный экран с возможностью пропуска
      // Это будет обрабатываться в UI через Navigator.pushNamed('/paywall')
      //debugPrint(
          'Перенаправление на экран выбора подписки для placement: $placement');
      return;

      /* Старый код, теперь не используется:
      // Регистрируем placement и показываем paywall
      Superwall.shared.registerPlacement(placement, feature: () {
        // Этот блок выполнится после закрытия paywall
        //debugPrint('Paywall был закрыт для placement: $placement');
      });
      */
    } catch (e) {
      //debugPrint('Ошибка при регистрации paywall: $e');
    }
  }

  /// Устанавливает атрибуты пользователя
  void setUserAttributes(Map<String, dynamic> attributes) {
    Superwall.shared.setUserAttributes(attributes);
  }

  /// Идентифицирует пользователя
  void identifyUser(String userId) {
    Superwall.shared.identify(userId);
  }

  /// Сбрасывает пользователя
  void resetUser() {
    Superwall.shared.reset();
  }
}
