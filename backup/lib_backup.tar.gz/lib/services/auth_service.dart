import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'dart:io' show Platform;

class AuthService extends ChangeNotifier {
  final _supabase = Supabase.instance.client;
  final _googleSignIn = GoogleSignIn(
    clientId: Platform.isIOS
        ? '543784915804-mvhe2hbph5ad7vmsb38950gih4rgb6pv.apps.googleusercontent.com'
        : null,
    serverClientId:
        '543784915804-mvhe2hbph5ad7vmsb38950gih4rgb6pv.apps.googleusercontent.com',
    scopes: ['email', 'profile'],
  );

  User? get currentUser => _supabase.auth.currentUser;

  Future<AuthResponse> signUp({
    required String email,
    required String password,
  }) async {
    final response = await _supabase.auth.signUp(
      email: email,
      password: password,
    );

    if (response.user != null) {
      notifyListeners();
    }

    return response;
  }

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    final response = await _supabase.auth.signInWithPassword(
      email: email,
      password: password,
    );

    if (response.user != null) {
      notifyListeners();
    }

    return response;
  }

  Future<AuthResponse> signInWithGoogle() async {
    try {
      // Начинаем процесс входа через Google
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) throw Exception('Google sign in aborted');

      // Получаем данные аутентификации
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // Проверяем наличие необходимых токенов
      if (googleAuth.idToken == null) {
        throw Exception('No ID Token found from Google Sign In');
      }

      // Создаем OAuthCredential
      final AuthResponse res = await _supabase.auth.signInWithIdToken(
        provider: OAuthProvider.google,
        idToken: googleAuth.idToken!,
        accessToken: googleAuth.accessToken,
      );

      if (res.user != null) {
        notifyListeners();
      }

      return res;
    } catch (e) {
      //debugPrint('Error signing in with Google: $e');
      rethrow;
    }
  }

  Future<AuthResponse?> signInWithApple() async {
    try {
      // Проверяем доступность Apple Sign In (только на iOS/macOS или в интернете)
      final isAvailable = await SignInWithApple.isAvailable();
      if (!isAvailable && !kIsWeb) {
        //debugPrint('Apple Sign In is not available on this device');
        throw UnsupportedError('Apple Sign In is not available on this device');
      }

      // Получаем учетные данные Apple
      final credential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName,
        ],
      );

      // Если нет idToken или authCode, выход
      if (credential.identityToken == null ||
          credential.authorizationCode == null) {
        throw Exception('Failed to get valid Apple Sign In credentials');
      }

      // Аутентификация с Supabase через Apple OAuth
      final AuthResponse response = await _supabase.auth.signInWithIdToken(
        provider: OAuthProvider.apple,
        idToken: credential.identityToken!,
      );

      if (response.user != null) {
        // Обновляем имя пользователя, если предоставлено Apple
        if (credential.givenName != null && credential.familyName != null) {
          final fullName =
              '${credential.givenName} ${credential.familyName}'.trim();
          if (fullName.isNotEmpty) {
            await _supabase.auth.updateUser(UserAttributes(
              data: {'full_name': fullName},
            ));
          }
        }
        notifyListeners();
      }

      return response;
    } catch (e) {
      //debugPrint('Error signing in with Apple: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    await Future.wait([
      _supabase.auth.signOut(),
      _googleSignIn.signOut(),
    ]);
    notifyListeners();
  }

  Future<void> deleteAccount() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) throw Exception('No user logged in');

      // Вызываем RPC функцию для удаления пользователя
      await _supabase.rpc('delete_user_account');

      await signOut();
    } catch (e) {
      //debugPrint('Error deleting account: $e');
      rethrow;
    }
  }

  Stream<AuthState> get authStateChanges => _supabase.auth.onAuthStateChange;

  // Возвращает текущий Google аккаунт, если пользователь авторизован через Google
  Future<GoogleSignInAccount?> getGoogleUserData() async {
    try {
      // Проверяем, залогинен ли пользователь уже в Google
      GoogleSignInAccount? account = await _googleSignIn.signInSilently();

      // Если не залогинен, пробуем с интерактивным входом (но без окна авторизации)
      account ??= _googleSignIn.currentUser;

      if (account != null) {
        //debugPrint(
            'Retrieved Google user data: ${account.displayName}, photo URL: ${account.photoUrl}');
      } else {
        //debugPrint('No active Google session found');
      }

      return account;
    } catch (e) {
      //debugPrint('Error retrieving Google user data: $e');
      return null;
    }
  }

  // Получает данные пользователя из метаданных Apple аутентификации
  Future<Map<String, dynamic>?> getAppleUserData() async {
    try {
      final user = _supabase.auth.currentUser;
      if (user == null) {
        //debugPrint('No active user found');
        return null;
      }

      // Проверяем провайдер аутентификации
      final authProviders = user.appMetadata['providers'] as List?;
      if (authProviders == null || !authProviders.contains('apple')) {
        //debugPrint('User not authenticated via Apple');
        return null;
      }

      // Получаем метаданные пользователя
      final userData = user.userMetadata;
      if (userData != null && userData.isNotEmpty) {
        //debugPrint('Retrieved Apple user data: $userData');
        return userData;
      } else {
        //debugPrint('No Apple user metadata found');
        return null;
      }
    } catch (e) {
      //debugPrint('Error retrieving Apple user data: $e');
      return null;
    }
  }
}
