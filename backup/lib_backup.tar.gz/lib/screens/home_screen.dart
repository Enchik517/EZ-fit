import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/workout_provider.dart';
import '../models/workout.dart';
import '../widgets/workout_card.dart';
import '../widgets/stats_card.dart';
import '../providers/auth_provider.dart';
import '../screens/active_workout_screen.dart';
import '../screens/streak_screen.dart';
import '../screens/profile_screen.dart';
import '../widgets/workout_details_modal.dart';
import '../screens/workout_details_screen.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'active_workout_screen.dart';
import '../models/exercise.dart';
import '../widgets/add_exercise_bottom_sheet.dart';
import '../screens/exercise_history_screen.dart';
import '../widgets/exercise_video_instructions.dart';
import '../widgets/filter_bottom_sheets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:math' as Math;
import '../services/exercise_rating_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedTimeRange = 'Last 7 days';
  final List<String> _timeRanges = [
    'Last 7 days',
    'Last 30 days',
    'This Year',
    'All-Time'
  ];
  int _selectedIndex = 0;
  String _selectedDuration = 'All';
  String _selectedMuscles = 'All';
  String _selectedEquipment = 'All';
  String _selectedDifficulty = 'All';
  String _selectedFocus = 'All';
  List<Exercise> exercises = [];
  String _selectedFilter = 'All';
  List<Exercise> _filteredExercises = [];

  final List<String> _durations = [
    '15 min',
    '30 min',
    '45 min',
    '60 min',
    '90 min'
  ];
  final List<String> _muscleGroups = [
    'All',
    'Chest',
    'Back',
    'Shoulders',
    'Arms',
    'Legs',
    'Core',
    'Full Body',
    'Triceps',
    'Biceps',
    'Quads',
    'Glutes',
    'Hamstrings',
    'Calves'
  ];
  final List<String> _equipment = [
    'All',
    'None',
    'Dumbbells',
    'Barbell',
    'Resistance Band',
    'Pull-up Bar',
    'Box',
    'Bench',
    'Kettlebell'
  ];
  final List<String> _difficulties = [
    'All',
    'Beginner',
    'Intermediate',
    'Advanced'
  ];
  final List<String> _focuses = [
    'All',
    'Strength',
    'Hypertrophy',
    'Endurance',
    'HIIT',
    'Cardio',
    'Flexibility'
  ];

  String _selectedDurationFilter = '45 min';
  Set<String> _selectedMusclesFilters = {'All'};
  Set<String> _selectedEquipmentFilters = {'All'};
  Set<String> _selectedDifficultyFilters = {'All'};

  // Обновляем лимиты для упражнений по времени
  final Map<String, int> _durationLimits = {
    '15 min': 2,
    '30 min': 5,
    '45 min': 7,
    '60 min': 9,
    '90 min': 14,
  };

  final ExerciseRatingService _ratingService = ExerciseRatingService();

  // Добавляем переменную для отслеживания состояния загрузки
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.black,
        systemNavigationBarDividerColor: Colors.transparent,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.edgeToEdge,
      overlays: [SystemUiOverlay.top],
    );

    // Загружаем данные после инициализации виджета
    WidgetsBinding.instance.addPostFrameCallback((_) {
      loadExercises().then((_) => _loadData());
    });

    // Убираем загрузку профиля при инициализации
    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   context.read<AuthProvider>().loadUserProfile();
    // });
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0: // Home
        break;
      case 1: // Workout
        Navigator.pushNamed(context, '/workouts');
        break;
      case 2: // Chat
        Navigator.pushNamed(context, '/chat');
        break;
      case 3: // Profile
        Navigator.pushNamed(context, '/profile');
        break;
    }
  }

  Future<void> _loadData() async {
    try {
      final workoutProvider =
          Provider.of<WorkoutProvider>(context, listen: false);
      await workoutProvider.loadWorkouts();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading workouts: $e')),
        );
      }
    }
  }

  Future<void> loadExercises() async {
    if (!mounted) return;

    try {
      //print('Attempting to load exercises...');

      final String jsonString =
          await rootBundle.loadString('assets/exercise.json');
      //print('Loaded JSON string: ${jsonString.substring(0, 100)}...');

      final List<dynamic> jsonList = json.decode(jsonString);
      //print('Decoded JSON list length: ${jsonList.length}');

      final newExercises = jsonList
          .map((json) {
            if (json is Map<String, dynamic>) {
              return Exercise.fromJson(json);
            } else {
              //print('Invalid exercise data: $json');
              return null;
            }
          })
          .whereType<Exercise>()
          .toList();

      //print('Parsed ${newExercises.length} exercises');

      if (mounted) {
        setState(() {
          exercises = newExercises;
          _filterExercises();
        });
      }
    } catch (e, stackTrace) {
      //print('Error loading exercises: $e');
      //print('Stack trace: $stackTrace');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading exercises: $e')),
        );
      }
    }
  }

  Future<Map<String, DateTime>> _getExerciseHistory() async {
    final Map<String, DateTime> lastPerformedDates = {};

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return lastPerformedDates;

      // Получаем историю всех упражнений пользователя
      final response = await Supabase.instance.client
          .from('exercise_history')
          .select('exercise_name, created_at')
          .eq('user_id', userId)
          .order('created_at', ascending: false);

      // Создаем словарь: название упражнения -> дата последнего выполнения
      for (var record in response) {
        final exerciseName = record['exercise_name'] as String;
        if (record['created_at'] != null) {
          final workoutDate = DateTime.parse(record['created_at']);
          if (!lastPerformedDates.containsKey(exerciseName) ||
              workoutDate.isAfter(lastPerformedDates[exerciseName]!)) {
            lastPerformedDates[exerciseName] = workoutDate;
          }
        }
      }

      //debugPrint('Loaded history for ${lastPerformedDates.length} exercises');
    } catch (e) {
      //debugPrint('Error loading exercise history: $e');
    }

    return lastPerformedDates;
  }

  void _filterExercises() async {
    if (!mounted) return;

    // Показываем небольшой индикатор загрузки
    setState(() {
      _isLoading = true;
    });

    try {
      // Получаем историю упражнений
      final exerciseHistory = await _getExerciseHistory();

      // Получаем фильтры из провайдера
      final workoutProvider =
          Provider.of<WorkoutProvider>(context, listen: false);
      final selectedMusclesFilters = workoutProvider.homeMusclesFilters;
      final selectedEquipmentFilters = workoutProvider.homeEquipmentFilters;
      final selectedDifficultyFilters = workoutProvider.homeDifficultyFilters;
      final selectedDurationFilter = workoutProvider.homeDurationFilter;

      // Получаем профиль пользователя для персонализации
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final userProfile = authProvider.userProfile;

      List<Exercise> personalizedExercises = [];

      // Если профиль пользователя доступен, используем персонализированные рейтинги
      if (userProfile != null) {
        // Формируем параметры для получения персонализированных упражнений
        String focusArea = 'full body'; // По умолчанию
        if (!selectedMusclesFilters.contains('All')) {
          // Берем первую выбранную группу мышц
          focusArea = selectedMusclesFilters.first.toLowerCase();
        }

        String difficulty = 'intermediate'; // По умолчанию
        if (!selectedDifficultyFilters.contains('All')) {
          // Берем первую выбранную сложность
          difficulty = selectedDifficultyFilters.first.toLowerCase();
        }

        // Получаем персонализированные упражнения с использованием ExerciseRatingService
        try {
          personalizedExercises = await _ratingService.getPersonalizedExercises(
            muscleGroup: focusArea == 'full body' ? null : focusArea,
            equipment: selectedEquipmentFilters.contains('All')
                ? null
                : selectedEquipmentFilters.isEmpty
                    ? null
                    : selectedEquipmentFilters.first,
            difficulty: difficulty == 'all' ? null : difficulty,
            userProfile: userProfile,
          );
        } catch (e) {
          //debugPrint('Ошибка при получении персонализированных упражнений: $e');
          // Если не удалось получить персонализированные упражнения, продолжаем стандартную фильтрацию
        }
      }

      setState(() {
        if (personalizedExercises.isNotEmpty) {
          // Если удалось получить персонализированные упражнения, используем их
          _filteredExercises = personalizedExercises;
        } else {
          // Иначе выполняем стандартную фильтрацию
          // ПЕРВЫЙ ЭТАП: Основная фильтрация по выбранным критериям
          _filteredExercises = exercises.where((exercise) {
            // Проверка мышечных групп
            bool matchesMuscles = selectedMusclesFilters.contains('All') ||
                exercise.muscleGroup
                    .toLowerCase()
                    .split(',')
                    .map((e) => e.trim())
                    .any((group) => selectedMusclesFilters
                        .any((filter) => group.contains(filter.toLowerCase())));

            // Проверка оборудования
            bool matchesEquipment = selectedEquipmentFilters.contains('All') ||
                selectedEquipmentFilters.any((eq) => exercise.equipment
                    .toLowerCase()
                    .contains(eq.toLowerCase()));

            // Проверка сложности
            bool matchesDifficulty =
                selectedDifficultyFilters.contains('All') ||
                    selectedDifficultyFilters.any((diff) =>
                        exercise.difficultyLevel.toLowerCase() ==
                        diff.toLowerCase());

            // Применяем все основные фильтры
            return matchesMuscles && matchesEquipment && matchesDifficulty;
          }).toList();

          // ВТОРОЙ ЭТАП: Сортировка по рейтингу и истории выполнения
          _filteredExercises.sort((a, b) {
            // Сначала сортируем по рейтингу (если доступен)
            if (a.currentRating != b.currentRating) {
              return b.currentRating
                  .compareTo(a.currentRating); // Более высокий рейтинг сначала
            }

            // При равном рейтинге сортируем по истории выполнения
            final aLastPerformed = exerciseHistory[a.name];
            final bLastPerformed = exerciseHistory[b.name];

            if (aLastPerformed == null && bLastPerformed == null) {
              // Оба упражнения не выполнялись ранее, сортируем по имени
              return a.name.compareTo(b.name);
            }

            // Если упражнение не выполнялось, оно имеет высший приоритет
            if (aLastPerformed == null) return -1;
            if (bLastPerformed == null) return 1;

            // Упражнения с более ранней датой последнего выполнения идут первыми
            return aLastPerformed.compareTo(bLastPerformed);
          });
        }

        // ТРЕТИЙ ЭТАП: Применяем ограничения по времени
        if (selectedDurationFilter != 'All') {
          // Получаем лимит для выбранного времени или используем 7 (как в 45 min) по умолчанию
          int maxExercises = _durationLimits[selectedDurationFilter] ?? 7;

          // Группируем упражнения по superSetId
          Map<String?, List<Exercise>> supersets = {};
          List<Exercise> regularExercises = [];

          for (var exercise in _filteredExercises) {
            if (exercise.superSetId != null) {
              if (!supersets.containsKey(exercise.superSetId)) {
                supersets[exercise.superSetId!] = [];
              }
              supersets[exercise.superSetId]!.add(exercise);
            } else {
              regularExercises.add(exercise);
            }
          }

          // Проверяем суперсеты на валидность (минимум 2 упражнения)
          supersets.forEach((id, exercises) {
            if (exercises.length < 2) {
              regularExercises.addAll(exercises);
              supersets[id] = [];
            }
          });

          // Удаляем пустые суперсеты
          supersets.removeWhere((key, value) => value.isEmpty);

          // Сортируем суперсеты по количеству упражнений
          List<MapEntry<String?, List<Exercise>>> sortedSupersets =
              supersets.entries.toList()
                ..sort((a, b) => b.value.length.compareTo(a.value.length));

          // Рассчитываем, сколько упражнений отвести на суперсеты и сколько на обычные
          int totalExercisesInSupersets =
              sortedSupersets.fold(0, (sum, entry) => sum + entry.value.length);

          if (totalExercisesInSupersets > 0) {
            // Если есть суперсеты, используем до 40% лимита для них
            int maxSupersetExercises = (maxExercises * 0.4).round();
            int remainingExercises = maxExercises - maxSupersetExercises;

            // Очищаем и формируем новый список
            _filteredExercises = [];

            // Добавляем суперсеты, но не превышаем лимит
            int addedSupersetExercises = 0;
            for (var entry in sortedSupersets) {
              if (addedSupersetExercises + entry.value.length <=
                  maxSupersetExercises) {
                _filteredExercises.addAll(entry.value);
                addedSupersetExercises += entry.value.length;
              } else {
                break;
              }
            }

            // Добавляем обычные упражнения до лимита
            int regularToAdd =
                Math.min(regularExercises.length, remainingExercises);
            if (regularToAdd > 0) {
              _filteredExercises
                  .addAll(regularExercises.sublist(0, regularToAdd));
            }
          } else {
            // Если нет суперсетов, просто ограничиваем количество обычных упражнений
            if (regularExercises.length > maxExercises) {
              _filteredExercises = regularExercises.sublist(0, maxExercises);
            } else {
              _filteredExercises = regularExercises;
            }
          }
        }

        // Отключаем индикатор загрузки
        _isLoading = false;
      });
    } catch (e) {
      //debugPrint('Ошибка при фильтрации упражнений: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Widget _buildWorkoutSection(WorkoutProvider provider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const StreakScreen(),
                  ),
                );
              },
              child:
                  Consumer<AuthProvider>(builder: (context, authProvider, _) {
                final streakValue =
                    authProvider.userProfile?.workoutStreak ?? 0;
                return Row(
                  children: [
                    Icon(Icons.local_fire_department, color: Colors.orange),
                    SizedBox(width: 4),
                    Text(
                      '$streakValue',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                );
              }),
            ),
            Consumer<AuthProvider>(builder: (context, authProvider, _) {
              final userName = authProvider.userProfile?.fullName ??
                  authProvider.userProfile?.name ??
                  'there';
              return Text(
                'Hey, $userName',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w500,
                ),
              );
            }),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfileScreen(),
                  ),
                );
              },
              child:
                  Consumer<AuthProvider>(builder: (context, authProvider, _) {
                // Получаем аватарку пользователя, если она есть
                final String? avatarUrl = authProvider.userProfile?.avatarUrl;
                final String firstInitial =
                    authProvider.userProfile?.fullName?.isNotEmpty == true
                        ? authProvider.userProfile!.fullName![0].toUpperCase()
                        : (authProvider.userProfile?.name?.isNotEmpty == true
                            ? authProvider.userProfile!.name![0].toUpperCase()
                            : 'A');

                // Если есть URL аватарки, показываем изображение
                return CircleAvatar(
                  backgroundColor: Colors.blue,
                  backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                      ? NetworkImage(avatarUrl)
                      : null,
                  child: avatarUrl == null || avatarUrl.isEmpty
                      ? Text(firstInitial)
                      : null,
                );
              }),
            ),
          ],
        ),
        const SizedBox(height: 20),
        // Time range selector
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: _timeRanges.map((range) {
              final isSelected = range == _selectedTimeRange;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(range),
                  selected: isSelected,
                  onSelected: (selected) {
                    if (selected) {
                      setState(() => _selectedTimeRange = range);
                    }
                  },
                  backgroundColor: Colors.grey[900],
                  selectedColor: Colors.white,
                  labelStyle: TextStyle(
                    color: isSelected ? Colors.black : Colors.white,
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 20),
        // Stats cards
        Container(
          height: 72,
          child: Row(
            children: [
              _buildStatsCard(
                value: provider.totalWorkouts.toString(),
                label: 'WORKOUTS',
                gradient: [Color(0xFFC66000), Colors.white],
              ),
              SizedBox(width: 8),
              _buildStatsCard(
                value: provider.totalSets.toString(),
                label: 'SETS',
                gradient: [Color(0xFF009DFF), Color(0xFFFF0004)],
              ),
              SizedBox(width: 8),
              _buildStatsCard(
                value: provider.totalHours.toStringAsFixed(1),
                label: 'HOURS',
                gradient: [
                  Color(0xFFEACDE9),
                  Color(0xFFEE0BD7),
                  Color(0xFF1BF57D)
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        // Заголовок Workout
        Text(
          'Workout',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontFamily: 'Inter',
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),
        // Сначала фильтры
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _buildFilterButton('45 min', Icons.timer),
              SizedBox(width: 8),
              _buildFilterButton('Muscles', Icons.fitness_center),
              SizedBox(width: 8),
              _buildFilterButton('Equipment', Icons.sports_gymnastics),
              SizedBox(width: 8),
              _buildFilterButton('Difficulty', Icons.star),
              SizedBox(width: 8),
              // Добавляем кнопку настроек (шестеренки)
              InkWell(
                onTap: () {
                  _showSettingsDialog();
                },
                child: Container(
                  height: 36,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey[900],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      Text(
                        'Settings',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Icon(
                        Icons.settings,
                        color: Colors.white,
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        // Количество упражнений с кнопкой плюс
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '${_filteredExercises.length} exercises',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
              ),
            ),
            Container(
              width: 26,
              height: 25,
              child: IconButton(
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
                icon: Icon(
                  Icons.add,
                  color: Colors.white,
                  size: 24,
                ),
                onPressed: () {
                  _showAddExerciseModal();
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Expanded(
          child: _buildExercisesList(),
        ),
        Container(
          width: double.infinity,
          height: 56,
          margin: EdgeInsets.only(top: 16, bottom: 80),
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ActiveWorkoutScreen(
                    exercises: _filteredExercises,
                    onComplete: () {
                      // Можно добавить действия после завершения тренировки
                    },
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '⚡',
                  style: TextStyle(
                    fontSize: 24,
                    color: Colors.amber[400],
                  ),
                ),
                SizedBox(width: 8),
                Text(
                  'START WORKOUT',
                  style: TextStyle(
                    fontSize: 16,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterButton(String label, IconData icon) {
    return InkWell(
      onTap: () {
        switch (label) {
          case '45 min':
            _showDurationPicker();
            break;
          case 'Muscles':
            _showMusclesPicker();
            break;
          case 'Equipment':
            _showEquipmentPicker();
            break;
          case 'Difficulty':
            _showDifficultyFilterDialog();
            break;
        }
      },
      child: Container(
        height: 36,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Text(
              _getDisplayLabel(label),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(width: 4),
            const Icon(
              Icons.arrow_drop_down,
              color: Colors.white,
            ),
          ],
        ),
      ),
    );
  }

  String _getDisplayLabel(String label) {
    final workoutProvider =
        Provider.of<WorkoutProvider>(context, listen: false);

    switch (label) {
      case '45 min':
        return workoutProvider.homeDurationFilter;
      case 'Muscles':
        return workoutProvider.homeMusclesFilters.contains('All')
            ? 'All muscles'
            : '${workoutProvider.homeMusclesFilters.length} selected';
      case 'Equipment':
        return workoutProvider.homeEquipmentFilters.contains('All')
            ? 'All equipment'
            : '${workoutProvider.homeEquipmentFilters.length} selected';
      case 'Difficulty':
        return workoutProvider.homeDifficultyFilters.contains('All')
            ? 'All levels'
            : '${workoutProvider.homeDifficultyFilters.length} selected';
      default:
        return label;
    }
  }

  void _showDurationPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => DurationFilterSheet(
        durations: _durations,
        selectedDuration: Provider.of<WorkoutProvider>(context, listen: false)
            .homeDurationFilter,
        durationLimits: _durationLimits,
        onDurationSelected: (duration) {
          Provider.of<WorkoutProvider>(context, listen: false)
              .setHomeDurationFilter(duration);
          _filterExercises();
        },
      ),
    );
  }

  void _showMusclesPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => MusclesFilterSheet(
        muscleGroups: _muscleGroups,
        selectedMuscles: Provider.of<WorkoutProvider>(context, listen: false)
            .homeMusclesFilters,
        onApply: (selected) {
          Provider.of<WorkoutProvider>(context, listen: false)
              .setHomeMusclesFilters(selected);
          _filterExercises();
        },
      ),
    );
  }

  void _showEquipmentPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => EquipmentFilterSheet(
        equipment: _equipment,
        selectedEquipment: Provider.of<WorkoutProvider>(context, listen: false)
            .homeEquipmentFilters,
        onApply: (selected) {
          Provider.of<WorkoutProvider>(context, listen: false)
              .setHomeEquipmentFilters(selected);
          _filterExercises();
        },
      ),
    );
  }

  void _showDifficultyFilterDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => DifficultyFilterSheet(
        difficulties: _difficulties,
        selectedDifficulties:
            Provider.of<WorkoutProvider>(context, listen: false)
                .homeDifficultyFilters,
        onApply: (selected) {
          Provider.of<WorkoutProvider>(context, listen: false)
              .setHomeDifficultyFilters(selected);
          _filterExercises();
        },
      ),
    );
  }

  Widget _buildExercisesList() {
    // Разделяем упражнения на обычные и суперсеты
    List<Exercise> regularExercises = [];
    Map<String?, List<Exercise>> supersets = {};

    // Сначала группируем упражнения по superSetId
    for (var exercise in _filteredExercises) {
      if (exercise.superSetId != null) {
        if (!supersets.containsKey(exercise.superSetId)) {
          supersets[exercise.superSetId!] = [];
        }
        supersets[exercise.superSetId]!.add(exercise);
      } else {
        regularExercises.add(exercise);
      }
    }

    // Проверяем суперсеты на валидность (минимум 2 упражнения)
    // Если суперсет невалидный, переносим упражнения в обычные
    supersets.forEach((id, exercises) {
      if (exercises.length < 2) {
        regularExercises.addAll(exercises);
        supersets[id] = [];
      }
    });

    // Удаляем пустые суперсеты
    supersets.removeWhere((key, value) => value.isEmpty);

    // Создаем список всех элементов для отображения
    List<Widget> allItems = [];

    // Сначала добавляем валидные суперсеты
    for (var superset in supersets.values) {
      allItems.add(
        Container(
          margin: EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Color(0xFF252527),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'SUPERSET — ${superset.first.sets} rounds',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 12,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              ...superset
                  .map((exercise) => Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: Colors.white.withOpacity(0.1),
                              width: 1,
                            ),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    exercise.name,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    '${exercise.sets} sets • ${exercise.reps} reps • ${exercise.weight ?? 50} lbs',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.6),
                                      fontSize: 13,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            GestureDetector(
                              onTap: () =>
                                  _showExerciseOptions(context, exercise),
                              child: Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  Icons.more_horiz,
                                  color: Colors.white70,
                                  size: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ))
                  .toList(),
            ],
          ),
        ),
      );
    }

    // Затем добавляем обычные упражнения
    for (var exercise in regularExercises) {
      allItems.add(
        Container(
          margin: EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Color(0xFF252527),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exercise.name,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        '${exercise.sets} sets • ${exercise.reps} reps • ${exercise.weight ?? 50} lbs',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 13,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => _showExerciseOptions(context, exercise),
                  child: Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.more_horiz,
                      color: Colors.white70,
                      size: 18,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return ListView(
      children: allItems,
    );
  }

  Widget _buildSettingsSheet() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Settings',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        ListTile(
          leading: Icon(Icons.timer, color: Colors.white),
          title: Text('Duration', style: TextStyle(color: Colors.white)),
          onTap: () {
            Navigator.pop(context);
            _showDurationPicker();
          },
        ),
        ListTile(
          leading: Icon(Icons.fitness_center, color: Colors.white),
          title: Text('Muscles', style: TextStyle(color: Colors.white)),
          onTap: () {
            Navigator.pop(context);
            _showMusclesPicker();
          },
        ),
        ListTile(
          leading: Icon(Icons.sports_gymnastics, color: Colors.white),
          title: Text('Equipment', style: TextStyle(color: Colors.white)),
          onTap: () {
            Navigator.pop(context);
            _showEquipmentPicker();
          },
        ),
        ListTile(
          leading: Icon(Icons.star, color: Colors.white),
          title: Text('Difficulty', style: TextStyle(color: Colors.white)),
          onTap: () {
            Navigator.pop(context);
            _showDifficultyFilterDialog();
          },
        ),
      ],
    );
  }

  void _showAddExerciseModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewPadding.bottom),
        child: AddExerciseBottomSheet(
          allExercises: exercises,
          onExercisesAdded: (selectedExercises) {
            setState(() {
              // Добавляем выбранные упражнения и обновляем список
              _filteredExercises.addAll(selectedExercises);
            });
          },
        ),
      ),
    );
  }

  String _getExerciseEmoji(String equipment) {
    switch (equipment.toLowerCase()) {
      case 'dumbbells':
        return '🏋️';
      case 'bench':
        return '🛏️';
      case 'none':
        return '🦵';
      default:
        return '💪';
    }
  }

  // Добавим метод для показа красивых уведомлений
  void _showCustomSnackBar(String message,
      {required IconData icon, Color? color}) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        margin: EdgeInsets.all(16),
        duration: Duration(seconds: 2),
        backgroundColor: Color(0xFF252527),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        content: Row(
          children: [
            Icon(
              icon,
              color: color ?? Colors.white,
            ),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleFavorite(String workoutId) {
    try {
      // Ensure workoutId is a valid UUID format
      if (!_isValidUUID(workoutId)) {
        throw FormatException('Invalid UUID format');
      }

      // Your existing favorite logic here
      // ...
    } catch (e) {
      _showCustomSnackBar(
        "Error updating favorites: Invalid workout ID",
        icon: Icons.error,
        color: Colors.red.shade800,
      );
    }
  }

  // Add this helper method to validate UUID format
  bool _isValidUUID(String? uuid) {
    if (uuid == null) return false;

    RegExp uuidRegExp = RegExp(
      r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
      caseSensitive: false,
    );

    return uuidRegExp.hasMatch(uuid);
  }

  Widget _buildStatsCard({
    required String value,
    required String label,
    required List<Color> gradient,
  }) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: gradient.map((c) => c.withOpacity(0.71)).toList(),
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withOpacity(0.7),
                fontSize: 12,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showExerciseOptions(BuildContext context, Exercise e) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewPadding.bottom),
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xFF1C1C1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle
              Container(
                margin: EdgeInsets.symmetric(vertical: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Title
              Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: Text(
                  e.name,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              // First group - no dividers
              _buildOptionTile(
                icon: Icons.play_circle_outline,
                iconColor: Colors.blue,
                title: 'Video & Instructions',
                onTap: () {
                  Navigator.pop(context);
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => ExerciseVideoInstructions(
                      exercise: e,
                      videoUrl: e.videoUrl,
                    ),
                  );
                },
              ),
              _buildOptionTile(
                icon: Icons.history,
                iconColor: Colors.purple,
                title: 'Exercise History',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ExerciseHistoryScreen(
                        exercise: e,
                      ),
                    ),
                  );
                },
              ),
              _buildOptionTile(
                icon: Icons.swap_horiz,
                iconColor: Colors.blue,
                title: 'Replace',
                onTap: () {
                  Navigator.pop(context);
                  // Replace logic
                },
              ),

              // Divider with gradient
              Container(
                height: 1,
                margin: EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              // Second group
              _buildOptionTile(
                icon: Icons.thumb_up,
                iconColor: Colors.green,
                title: 'Recommend more',
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Обновляем предпочтение пользователя (лайк)
                    await _ratingService.updateUserPreference(e, 1);
                    _showCustomSnackBar(
                      "We'll recommend more exercises like ${e.name}",
                      icon: Icons.thumb_up,
                      color: Colors.green.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.thumb_down,
                iconColor: Colors.orange,
                title: 'Recommend less',
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Обновляем предпочтение пользователя (дизлайк)
                    await _ratingService.updateUserPreference(e, -1);
                    _showCustomSnackBar(
                      "We'll recommend fewer exercises like ${e.name}",
                      icon: Icons.thumb_down,
                      color: Colors.orange.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.block,
                iconColor: Colors.red,
                title: "Don't recommend again",
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Устанавливаем сильный негативный рейтинг
                    final updatedExercise =
                        e.copyWith(baseRating: 1.0, userPreference: -1);
                    await _ratingService.updateExerciseRating(updatedExercise);
                    _showCustomSnackBar(
                      "You won't see ${e.name} in recommendations anymore",
                      icon: Icons.block,
                      color: Colors.red.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.delete,
                iconColor: Colors.red,
                title: 'Delete from this workout',
                isDestructive: true,
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _filteredExercises.remove(e);
                  });
                },
              ),

              SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOptionTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: iconColor,
                size: 18,
              ),
            ),
            SizedBox(width: 12),
            Text(
              title,
              style: TextStyle(
                color: isDestructive ? Colors.red : Colors.white,
                fontSize: 16,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Метод для отображения диалога настроек
  void _showSettingsDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Индикатор перетаскивания
              Center(
                child: Container(
                  width: 40,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: BorderRadius.circular(2.5),
                  ),
                ),
              ),
              SizedBox(height: 24),
              // Заголовок
              Text(
                'Settings',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              // Быстрые действия с фильтрами
              _buildSettingsOption(
                icon: Icons.restart_alt,
                color: Colors.blue,
                title: 'Reset All Filters',
                subtitle: 'Return to default filter settings',
                onTap: () {
                  setState(() {
                    _selectedDurationFilter = '45 min';
                    _selectedMusclesFilters = {'All'};
                    _selectedEquipmentFilters = {'All'};
                    _selectedDifficultyFilters = {'All'};
                    _filterExercises();
                  });
                  Navigator.pop(context);
                  _showCustomSnackBar(
                    "All filters have been reset",
                    icon: Icons.check_circle,
                    color: Colors.green,
                  );
                },
              ),
              Divider(color: Colors.grey[800]),
              _buildSettingsOption(
                icon: Icons.save,
                color: Colors.amber,
                title: 'Save Current Filters as Preset',
                subtitle: 'Create a preset with your current filters',
                onTap: () {
                  // В будущей версии можно реализовать сохранение
                  Navigator.pop(context);
                  _showCustomSnackBar(
                    "This feature will be available soon",
                    icon: Icons.info,
                    color: Colors.blue,
                  );
                },
              ),
              Divider(color: Colors.grey[800]),
              _buildSettingsOption(
                icon: Icons.fitness_center,
                color: Colors.purple,
                title: 'Advanced Exercise Settings',
                subtitle: 'Customize your exercise preferences',
                onTap: () {
                  Navigator.pop(context);
                  // В будущей версии можно добавить экран
                  _showCustomSnackBar(
                    "This feature will be available soon",
                    icon: Icons.info,
                    color: Colors.blue,
                  );
                },
              ),
              Divider(color: Colors.grey[800]),
              _buildSettingsOption(
                icon: Icons.sort,
                color: Colors.green,
                title: 'Sort Exercises',
                subtitle: 'Change the exercise sorting method',
                onTap: () {
                  Navigator.pop(context);
                  _showSortingOptionsDialog();
                },
              ),
              SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  // Вспомогательный метод для создания опций в диалоге настроек
  Widget _buildSettingsOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.grey[600],
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  // Новый метод для отображения диалога сортировки
  void _showSortingOptionsDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.grey[900],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey[600],
                    borderRadius: BorderRadius.circular(2.5),
                  ),
                ),
              ),
              SizedBox(height: 24),
              Text(
                'Sort Exercises',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 16),
              ListTile(
                leading: Icon(Icons.history, color: Colors.white),
                title: Text('Last performed date',
                    style: TextStyle(color: Colors.white)),
                subtitle: Text(
                    'Exercises you haven\'t done recently appear first',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                onTap: () {
                  Navigator.pop(context);
                  _showCustomSnackBar(
                    "Exercises sorted by last performed date",
                    icon: Icons.check_circle,
                    color: Colors.green,
                  );
                  // Текущая логика сортировки уже реализована по дате
                },
              ),
              ListTile(
                leading: Icon(Icons.sort_by_alpha, color: Colors.white),
                title:
                    Text('Alphabetical', style: TextStyle(color: Colors.white)),
                subtitle: Text('Sort exercises by name',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _filteredExercises.sort((a, b) => a.name.compareTo(b.name));
                  });
                  _showCustomSnackBar(
                    "Exercises sorted alphabetically",
                    icon: Icons.check_circle,
                    color: Colors.green,
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.fitness_center, color: Colors.white),
                title:
                    Text('Muscle group', style: TextStyle(color: Colors.white)),
                subtitle: Text('Group exercises by muscle',
                    style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _filteredExercises
                        .sort((a, b) => a.muscleGroup.compareTo(b.muscleGroup));
                  });
                  _showCustomSnackBar(
                    "Exercises sorted by muscle group",
                    icon: Icons.check_circle,
                    color: Colors.green,
                  );
                },
              ),
              SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<WorkoutProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading) {
          return const Scaffold(
            backgroundColor: Colors.black,
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        // Всегда отображаем интерфейс, игнорируя проверку наличия профиля
        return Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _isLoading
                        ? Center(
                            child: Container(
                              width: 240,
                              padding: EdgeInsets.all(24),
                              decoration: BoxDecoration(
                                color: Color(0xFF1C1C1E),
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.3),
                                    blurRadius: 10,
                                    spreadRadius: 2,
                                  ),
                                ],
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.1),
                                  width: 1,
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color: Color(0xFF3D5AFE).withOpacity(0.1),
                                      shape: BoxShape.circle,
                                    ),
                                    child: SizedBox(
                                      width: 40,
                                      height: 40,
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Color(0xFF3D5AFE)),
                                        strokeWidth: 3,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20),
                                  Column(
                                    children: [
                                      Text(
                                        'Personalizing',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600,
                                          letterSpacing: 0.5,
                                        ),
                                      ),
                                      SizedBox(height: 6),
                                      Text(
                                        'Creating your perfect workout',
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.7),
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400,
                                        ),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        : _buildWorkoutSection(provider),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
