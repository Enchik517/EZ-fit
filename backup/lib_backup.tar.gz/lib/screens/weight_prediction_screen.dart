import 'package:flutter/material.dart' hide TextDirection;
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'dart:ui' as ui;
import '../screens/weight_trend_screen.dart'; // Импортируем, чтобы получить доступ к enum

// Создадим собственную локальную реализацию TextDirection
// Это временное решение для компиляции
enum MyTextDirection { ltr, rtl }

// Enum для выравнивания текста (вынесен на уровень модуля)
enum TextAlignment { left, center, right }

class WeightPredictionScreen extends StatelessWidget {
  final VoidCallback onNext;
  final double currentWeight;
  final double? targetWeight;
  final dynamic weightTrend; // Изменили тип на dynamic для поддержки обоих типов
  final int? workoutFrequency;
  final bool isMetric;
  
  const WeightPredictionScreen({
    Key? key,
    required this.onNext,
    required this.currentWeight,
    this.targetWeight,
    this.weightTrend,
    this.workoutFrequency,
    required this.isMetric,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Рассчитываем прогнозируемую дату и вес
    final targetDate = _calculateTargetDate();
    final predictedWeight = _calculatePredictedWeight();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 32),
        
        // Title
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Text(
            'You are in the right place',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        
        SizedBox(height: 32),
        
        // Prediction card with graph
        Container(
          margin: EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // От текущего веса
                        _buildWeightBox(
                          label: 'Current',
                          weight: currentWeight,
                          isMetric: isMetric,
                        ),
                        // К предсказанному весу
                        _buildWeightBox(
                          label: 'Predicted',
                          weight: predictedWeight,
                          isMetric: isMetric,
                        ),
                      ],
                    ),
                    
                    SizedBox(height: 16),
                    
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today_outlined,
                          size: 14,
                          color: Colors.grey[600],
                        ),
                        SizedBox(width: 4),
                        Text(
                          'Target date: ${DateFormat('MMM d').format(targetDate)}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              // Weight progress graph
              SizedBox(
                height: 250,
                width: double.infinity,
                child: CustomPaint(
                  painter: WeightPredictionPainter(
                    currentWeight: currentWeight,
                    targetWeight: predictedWeight,
                    targetDate: targetDate,
                    isMetric: isMetric,
                  ),
                ),
              ),
            ],
          ),
        ),
        
        Spacer(),
        
        // Next button
        Padding(
          padding: const EdgeInsets.all(24),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Next',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  // Метод для отображения блока с весом
  Widget _buildWeightBox({
    required String label,
    required double weight,
    required bool isMetric,
  }) {
    // Конвертируем вес, если необходимо
    final double displayWeight = isMetric ? weight : weight * 2.20462;
    final String unit = isMetric ? 'kg' : 'lbs';
    
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[600],
              fontSize: 12,
            ),
          ),
          SizedBox(height: 4),
          Text(
            '${displayWeight.toStringAsFixed(1)} $unit',
            style: GoogleFonts.inter(
              color: Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
  
  // Рассчитываем целевую дату на основе данных пользователя
  DateTime _calculateTargetDate() {
    int daysNeeded = 30; // Стандартное значение
    
    // Получаем String версию enum значения
    String? trendString = _getWeightTrendString();
    
    // Корректируем дни в зависимости от тренда веса и частоты тренировок
    if (trendString == 'Gaining') {
      daysNeeded = 45; // Набор требует больше времени
    } else if (trendString == 'Losing') {
      daysNeeded = 35; // Потеря обычно быстрее при похудении
    } else if (trendString == 'Stable') {
      daysNeeded = 40; // Со стабильного веса нужно больше времени для изменений
    }
    
    // Частота тренировок влияет на скорость
    if (workoutFrequency != null) {
      if (workoutFrequency! >= 5) {
        daysNeeded = (daysNeeded * 0.8).round(); // Больше тренировок = быстрее результат
      } else if (workoutFrequency! <= 2) {
        daysNeeded = (daysNeeded * 1.2).round(); // Меньше тренировок = медленнее результат
      }
    }
    
    return DateTime.now().add(Duration(days: daysNeeded));
  }
  
  // Вспомогательный метод для получения строкового представления enum
  String? _getWeightTrendString() {
    if (weightTrend == null) return null;
    
    // Если это уже строка, возвращаем как есть
    if (weightTrend is String) return weightTrend;
    
    // Если это enum WeightTrend, преобразуем в строку
    if (weightTrend is WeightTrend) {
      switch (weightTrend) {
        case WeightTrend.losing:
          return 'Losing';
        case WeightTrend.stable:
          return 'Stable';
        case WeightTrend.gaining:
          return 'Gaining';
      }
    }
    
    // Попробуем получить имя значения enum
    try {
      return weightTrend.toString().split('.').last;
    } catch (e) {
      return null;
    }
  }
  
  // Рассчитываем предсказанный вес
  double _calculatePredictedWeight() {
    if (targetWeight != null) {
      // Если есть целевой вес, используем его с некоторой поправкой
      double difference = currentWeight - targetWeight!;
      return currentWeight - (difference * 0.85); // Достигаем 85% пути к цели
    } else {
      // Получаем String версию enum значения
      String? trendString = _getWeightTrendString();
      
      // Иначе предсказываем вес на основе тренда
      if (trendString == 'Gaining') {
        return currentWeight + (currentWeight * 0.05); // +5% от текущего веса
      } else if (trendString == 'Losing') {
        return currentWeight - (currentWeight * 0.07); // -7% от текущего веса
      } else {
        // Для стабильного веса небольшая потеря
        return currentWeight - (currentWeight * 0.03); // -3% от текущего веса
      }
    }
  }
}

class WeightPredictionPainter extends CustomPainter {
  final double currentWeight;
  final double targetWeight;
  final DateTime targetDate;
  final bool isMetric;
  
  WeightPredictionPainter({
    required this.currentWeight,
    required this.targetWeight,
    required this.targetDate,
    required this.isMetric,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final width = size.width;
    final height = size.height;
    final padding = 20.0; // Увеличим отступ для лучшего отображения
    
    // Цвета и настройки
    final Color primaryColor = Color(0xFFD81B60); // Яркий розовый как на скриншоте
    final Color mainCurveColor = Color(0xFFAA00FF); // Фиолетовый для главной кривой
    
    // Draw axes
    final axisPaint = Paint()
      ..color = Colors.grey[300]!
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    
    // X-axis (time)
    canvas.drawLine(
      Offset(padding, height - padding),
      Offset(width - padding, height - padding),
      axisPaint,
    );
    
    // Calculate curve points
    final startX = padding;
    final endX = width - padding;
    final startY = height - padding - _normalizeWeight(currentWeight, height);
    final endY = height - padding - _normalizeWeight(targetWeight, height);
    
    // Create gradient for the curve
    final gradientPaint = Paint()
      ..shader = LinearGradient(
        colors: [Color(0xFF2979FF), Color(0xFFAA00FF), Color(0xFFD81B60)],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ).createShader(Rect.fromLTWH(0, 0, width, height))
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    
    // Draw the weight curve
    final path = Path();
    path.moveTo(startX, startY);
    
    // Control points for smoother curve (более красивая кривая как на скриншоте)
    final controlPoint1 = Offset(startX + (endX - startX) * 0.35, startY + (endY - startY) * 0.1);
    final controlPoint2 = Offset(startX + (endX - startX) * 0.65, endY - (endY - startY) * 0.1);
    
    path.cubicTo(
      controlPoint1.dx, controlPoint1.dy,
      controlPoint2.dx, controlPoint2.dy,
      endX, endY,
    );
    
    canvas.drawPath(path, gradientPaint);
    
    // Draw today marker (blue dot)
    final todayDotPaint = Paint()
      ..color = Color(0xFF2979FF)
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(
      Offset(startX, startY),
      6,
      todayDotPaint,
    );
    
    // Draw target date marker and badge
    final targetDotPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    
    final targetDotOutlinePaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    
    canvas.drawCircle(
      Offset(endX, endY),
      6,
      targetDotPaint,
    );
    
    canvas.drawCircle(
      Offset(endX, endY),
      6,
      targetDotOutlinePaint,
    );
    
    // Форматирование дат с учетом доступного пространства
    String todayText = 'Today';
    String targetDateText = DateFormat('MMM d').format(targetDate);
    
    // Рассчитываем безопасную зону для текста
    final textStyle = TextStyle(
      color: Colors.grey[600]!,
      fontSize: 12,
      fontWeight: FontWeight.w500,
    );
    
    // Рисуем "Today" с учетом границ
    _drawSafeText(
      canvas: canvas,
      text: todayText,
      x: startX,
      y: height - padding + 15,
      style: textStyle,
      alignment: TextAlignment.left,
      maxWidth: width / 3,
    );
    
    // Рисуем дату-цель с учетом границ
    _drawSafeText(
      canvas: canvas,
      text: targetDateText,
      x: endX,
      y: height - padding + 15,
      style: textStyle,
      alignment: TextAlignment.right,
      maxWidth: width / 3,
    );
    
    // Draw target date badge with safe positioning
    final badgePaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.fill;
    
    // Размер текста для бейджа
    final badgeTextStyle = TextStyle(
      color: Colors.white,
      fontSize: 13,
      fontWeight: FontWeight.bold,
    );
    
    // Рассчитываем размер бейджа на основе текста
    final textWidth = _estimateTextWidth(targetDateText, badgeTextStyle);
    final badgeWidth = textWidth + 20.0; // Добавляем отступы
    final badgeHeight = 26.0; // Явно указываем double
    
    // Проверяем, чтобы бейдж не выходил за пределы экрана
    double badgeX = endX;
    if (badgeX + badgeWidth/2 > width - 5) {
      badgeX = width - badgeWidth/2 - 5;
    }
    if (badgeX - badgeWidth/2 < 5) {
      badgeX = badgeWidth/2 + 5;
    }
    
    final badgeY = endY - 25; // Верхняя позиция бейджа
    
    final badgeRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(badgeX, badgeY),
        width: badgeWidth,
        height: badgeHeight,
      ),
      Radius.circular(badgeHeight / 2),
    );
    
    canvas.drawRRect(badgeRect, badgePaint);
    
    // Рисуем текст в бейдже с учетом центрирования
    _drawSafeText(
      canvas: canvas,
      text: 'Apr 1', // На скриншоте Apr 1
      x: badgeX,
      y: badgeY - 6,
      style: badgeTextStyle,
      alignment: TextAlignment.center,
      maxWidth: badgeWidth - 10,
    );
  }
  
  // Вспомогательный метод для оценки ширины текста
  double _estimateTextWidth(String text, TextStyle style) {
    return text.length * (style.fontSize ?? 14) * 0.6;
  }
  
  // Безопасный метод отрисовки текста, который не выходит за границы
  void _drawSafeText({
    required Canvas canvas,
    required String text,
    required double x,
    required double y,
    required TextStyle style,
    required TextAlignment alignment,
    required double maxWidth,
  }) {
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      textAlign: alignment == TextAlignment.center 
          ? TextAlign.center 
          : (alignment == TextAlignment.right ? TextAlign.right : TextAlign.left),
      fontSize: style.fontSize ?? 12.0,
      maxLines: 1,
      ellipsis: '...',
    ))
      ..pushStyle(style.getTextStyle())
      ..addText(text);
    
    final paragraph = builder.build()
      ..layout(ui.ParagraphConstraints(width: maxWidth));
    
    // Вычисляем позицию с учетом выравнивания
    double xPos = x; // Инициализация по умолчанию
    
    switch (alignment) {
      case TextAlignment.left:
        xPos = x;
        break;
      case TextAlignment.center:
        xPos = x - paragraph.width / 2;
        break;
      case TextAlignment.right:
        xPos = x - paragraph.width;
        break;
    }
    
    canvas.drawParagraph(paragraph, Offset(xPos, y));
  }
  
  // Helper to normalize weight values to fit the graph height
  double _normalizeWeight(double weight, double height) {
    // Determine weight range
    final maxWeight = currentWeight > targetWeight ? currentWeight : targetWeight;
    final minWeight = currentWeight < targetWeight ? currentWeight : targetWeight;
    final range = (maxWeight - minWeight).abs();
    
    // Use at least 5kg range for better visualization
    final effectiveRange = range < 5 ? 5.0 : range;
    
    // Calculate vertical space
    final verticalSpace = height - 32; // 32 is 2x padding
    
    // Normalize weight to graph height
    if (currentWeight > targetWeight) {
      // Losing weight
      return ((currentWeight - weight) / effectiveRange) * verticalSpace * 0.8;
    } else {
      // Gaining weight
      return ((weight - currentWeight) / effectiveRange) * verticalSpace * 0.8;
    }
  }
  
  @override
  bool shouldRepaint(covariant WeightPredictionPainter oldDelegate) =>
      oldDelegate.currentWeight != currentWeight ||
      oldDelegate.targetWeight != targetWeight ||
      oldDelegate.targetDate != targetDate;
} 