import 'package:flutter/material.dart';
import '../models/exercise.dart';
import '../models/workout.dart';
import '../models/workout_log.dart';
import '../providers/workout_provider.dart';
import 'package:provider/provider.dart';
import 'dart:async';
import '../screens/home_screen.dart';
import '../widgets/blinking_timer.dart';
import '../screens/exercise_set_screen.dart';
import '../widgets/add_exercise_bottom_sheet.dart';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:uuid/uuid.dart';
import '../widgets/exercise_video_instructions.dart';
import '../screens/exercise_history_screen.dart';
import '../services/exercise_rating_service.dart';
import '../screens/workout_summary_screen.dart';

class ActiveWorkoutScreen extends StatefulWidget {
  final List<Exercise> exercises;
  final VoidCallback onComplete;
  final WorkoutLog? previousWorkoutLog;

  const ActiveWorkoutScreen({
    Key? key,
    required this.exercises,
    required this.onComplete,
    this.previousWorkoutLog,
  }) : super(key: key);

  @override
  State<ActiveWorkoutScreen> createState() => _ActiveWorkoutScreenState();
}

class _ActiveWorkoutScreenState extends State<ActiveWorkoutScreen> {
  late Timer _timer;
  Duration _elapsed = Duration.zero;
  bool _isCompleting = false;
  Map<int, List<SetLog>> _exerciseSets = {};
  Map<int, bool> _completedExercises = {};
  late Exercise currentExercise;
  late WorkoutLog workoutLog;
  int currentExerciseIndex = 0;
  int currentSet = 1;
  List<TextEditingController> _repsControllers = [];
  List<TextEditingController> _weightControllers = [];
  int currentRound = 1;
  final int totalRounds = 3;
  bool _isFavorite = false;
  String _notes = '';
  final TextEditingController _notesController = TextEditingController();
  final ExerciseRatingService _ratingService = ExerciseRatingService();
  late DateTime _startTime;

  @override
  void initState() {
    super.initState();
    _startTimer();

    // Если есть предыдущая тренировка, восстанавливаем её состояние
    if (widget.previousWorkoutLog != null) {
      _startTime = widget.previousWorkoutLog!.date;
      _elapsed = DateTime.now().difference(_startTime);

      // Создаем карту предыдущих упражнений для быстрого доступа
      final previousExercises = Map.fromEntries(
        widget.previousWorkoutLog!.exercises.map(
          (e) => MapEntry(e.exercise.id, e),
        ),
      );

      // Инициализируем состояние для всех упражнений
      for (var i = 0; i < widget.exercises.length; i++) {
        final exercise = widget.exercises[i];

        // Проверяем, было ли упражнение в предыдущей тренировке
        if (previousExercises.containsKey(exercise.id)) {
          final prevExercise = previousExercises[exercise.id]!;
          _exerciseSets[i] = List.from(prevExercise.sets);
          _completedExercises[i] = prevExercise.isCompleted;
        } else {
          _exerciseSets[i] = [];
          _completedExercises[i] = false;
        }
      }
    } else {
      // Инициализируем новую тренировку
      _startTime = DateTime.now();
      for (var i = 0; i < widget.exercises.length; i++) {
        _completedExercises[i] = false;
        _exerciseSets[i] = [];
      }
    }

    currentExercise = widget.exercises[0];
    workoutLog = WorkoutLog.fromWorkout(Workout(
      id: const Uuid().v4(),
      name: 'Active Workout',
      description: 'Workout created from exercises',
      exercises: widget.exercises,
      duration: 45,
      difficulty: 'Custom',
      equipment: widget.exercises.map((e) => e.equipment).toSet().toList(),
      targetMuscles:
          widget.exercises.map((e) => e.targetMuscleGroup).toSet().toList(),
      focus: 'Custom Workout',
      calories: 0,
    ));
    _initializeControllers();
  }

  void _initializeControllers() {
    _repsControllers = List.generate(
      int.parse(currentExercise.sets),
      (index) => TextEditingController(text: currentExercise.reps),
    );
    _weightControllers = List.generate(
      int.parse(currentExercise.sets),
      (index) => TextEditingController(text: "50"),
    );
  }

  @override
  void dispose() {
    _timer.cancel();
    for (var controller in _repsControllers) {
      controller.dispose();
    }
    for (var controller in _weightControllers) {
      controller.dispose();
    }
    _notesController.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _elapsed += Duration(seconds: 1);
      });
    });
  }

  void logSet(int reps, double weight) {
    setState(() {
      final setLog = SetLog(reps: reps, weight: weight);
      if (!_exerciseSets.containsKey(currentExerciseIndex)) {
        _exerciseSets[currentExerciseIndex] = [];
      }
      _exerciseSets[currentExerciseIndex]?.add(setLog);

      if (currentExerciseIndex < widget.exercises.length - 1) {
        currentExerciseIndex++;
      } else {
        currentExerciseIndex = 0;
        currentRound++;
      }

      if (currentRound > totalRounds) {
        _completeWorkout();
      }

      currentExercise = widget.exercises[currentExerciseIndex];
    });
  }

  void _showCustomSnackBar(String message, {IconData? icon, Color? color}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: color ?? Color(0xFF1C1C1E).withOpacity(0.95),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 8,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, color: Colors.white, size: 20),
                SizedBox(width: 12),
              ],
              Expanded(
                child: Text(
                  message,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _toggleFavorite() async {
    try {
      final workoutProvider =
          Provider.of<WorkoutProvider>(context, listen: false);

      setState(() {
        _isFavorite = !_isFavorite;
      });

      if (_isFavorite) {
        // Создаем объект тренировки из текущих упражнений
        final workout = Workout(
          id: const Uuid().v4(),
          name: 'Custom Workout',
          description:
              _notes.isNotEmpty ? _notes : 'Custom workout from active session',
          exercises: widget.exercises,
          duration: _elapsed.inMinutes,
          difficulty: 'Custom',
          equipment: widget.exercises.map((e) => e.equipment).toSet().toList(),
          targetMuscles:
              widget.exercises.map((e) => e.targetMuscleGroup).toSet().toList(),
          focus: 'Custom Workout',
          calories: 0,
          isFavorite: true,
        );

        // Сохраняем в избранное
        await workoutProvider.saveWorkout(workout);

        _showCustomSnackBar(
          'Workout added to favorites',
          icon: Icons.star,
          color: Color(0xFFFFD700).withOpacity(0.95),
        );
      } else {
        // Удаляем из избранного если отменили
        await workoutProvider.removeFromFavorites(const Uuid().v4());

        _showCustomSnackBar(
          'Removed from favorites',
          icon: Icons.star_border,
          color: null,
        );
      }
    } catch (e) {
      setState(() {
        _isFavorite =
            !_isFavorite; // Возвращаем состояние обратно в случае ошибки
      });

      _showCustomSnackBar(
        'Error updating favorites: $e',
        icon: Icons.error_outline,
        color: Colors.red.withOpacity(0.95),
      );
    }
  }

  Future<void> _completeWorkout() async {
    if (_isCompleting) return;

    setState(() => _isCompleting = true);
    _timer.cancel();

    try {
      final workoutProvider =
          Provider.of<WorkoutProvider>(context, listen: false);
      final duration = DateTime.now().difference(_startTime);

      // Получаем все упражнения с их текущим состоянием
      final allExercises = widget.exercises.map((exercise) {
        final index = widget.exercises.indexOf(exercise);
        final sets = _exerciseSets[index] ?? [];

        return ExerciseLog(
          exercise: exercise,
          sets: sets,
        );
      }).toList();

      // Добавляем упражнения из предыдущей тренировки
      if (widget.previousWorkoutLog != null) {
        for (var prevExercise in widget.previousWorkoutLog!.exercises) {
          if (!allExercises
              .any((e) => e.exercise.id == prevExercise.exercise.id)) {
            // Добавляем предыдущие упражнения тоже как незавершенные
            allExercises.add(ExerciseLog(
              exercise: prevExercise.exercise,
              sets: prevExercise.sets,
            ));
          }
        }
      }

      // Определяем незавершенные упражнения
      final uncompletedExercises = widget.exercises.where((exercise) {
        final index = widget.exercises.indexOf(exercise);
        final sets = _exerciseSets[index] ?? [];
        return sets.length < int.parse(exercise.sets);
      }).toList();

      final workoutLog = WorkoutLog(
        workoutName: widget.previousWorkoutLog?.workoutName ?? 'Custom Workout',
        date: _startTime,
        duration: duration,
        exercises: allExercises,
        isCompleted: false, // При нажатии на флаг - тренировка НЕ ЗАВЕРШЕНА
        endTime:
            null, // Не устанавливаем время окончания - это сделает кнопка End Workout
      );

      // Переходим к экрану сводки тренировки, НО НЕ СОХРАНЯЕМ лог тренировки
      // Лог будет сохранен только при нажатии на "End Workout" в экране сводки
      if (mounted) {
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => WorkoutSummaryScreen(
              workoutLog: workoutLog,
              uncompletedExercises: uncompletedExercises,
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error completing workout: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isCompleting = false);
      }
    }
  }

  void _showNotesDialog() {
    _notesController.text = _notes;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: Color(0xFF1C1C1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Color(0xFF252527),
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Workout Notes',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        _notes = _notesController.text;
                      });
                      Navigator.pop(context);
                      _showCustomSnackBar(
                        'Notes saved successfully',
                        icon: Icons.check_circle,
                        color: Color(0xFF00BE13).withOpacity(0.95),
                      );
                    },
                    child: Text(
                      'Save',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: TextField(
                  controller: _notesController,
                  maxLines: null,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Add notes about your workout...',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showAddExerciseModal() async {
    // Загружаем упражнения из JSON
    List<Exercise> allExercises = [];
    try {
      final String jsonString =
          await rootBundle.loadString('assets/exercise.json');
      final List<dynamic> jsonList = json.decode(jsonString);

      allExercises = jsonList
          .map((json) {
            if (json is Map<String, dynamic>) {
              return Exercise.fromJson(json);
            } else {
              return null;
            }
          })
          .whereType<Exercise>()
          .toList();
    } catch (e) {
      //print('Error loading exercises: $e');
    }

    // Показываем модальное окно
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AddExerciseBottomSheet(
        allExercises: allExercises,
        onExercisesAdded: (selectedExercises) {
          setState(() {
            widget.exercises.addAll(selectedExercises);
            // Обновляем структуры данных для новых упражнений
            for (var exercise in selectedExercises) {
              if (!_exerciseSets
                  .containsKey(widget.exercises.indexOf(exercise))) {
                _exerciseSets[widget.exercises.indexOf(exercise)] = [];
              }
              _completedExercises[widget.exercises.indexOf(exercise)] = false;
            }
          });
        },
      ),
    );
  }

  Future<List<Exercise>> _findSimilarExercises(Exercise exercise) async {
    try {
      final String jsonString =
          await rootBundle.loadString('assets/exercise.json');
      final List<dynamic> jsonList = json.decode(jsonString);

      final allExercises = jsonList
          .map((json) => Exercise.fromJson(json as Map<String, dynamic>))
          .where((e) =>
              e.targetMuscleGroup == exercise.targetMuscleGroup &&
              e.name != exercise.name)
          .toList();

      // Сортируем по оборудованию - сначала те, что с тем же оборудованием
      allExercises.sort((a, b) {
        if (a.equipment == exercise.equipment &&
            b.equipment != exercise.equipment) {
          return -1;
        }
        if (b.equipment == exercise.equipment &&
            a.equipment != exercise.equipment) {
          return 1;
        }
        return 0;
      });

      return allExercises;
    } catch (e) {
      //print('Error loading exercises: $e');
      return [];
    }
  }

  void _showReplaceExerciseModal(Exercise exercise) async {
    final similarExercises = await _findSimilarExercises(exercise);

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: Color(0xFF1C1C1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          border: Border.all(
            color: Colors.white.withOpacity(0.1),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            // Handle
            Container(
              margin: EdgeInsets.symmetric(vertical: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // Title
            Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Replace ${exercise.name}',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            // Subtitle
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Similar exercises targeting ${exercise.targetMuscleGroup}',
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 14,
                  fontFamily: 'Inter',
                ),
              ),
            ),

            // Exercise list
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 16),
                itemCount: similarExercises.length,
                itemBuilder: (context, index) {
                  final e = similarExercises[index];
                  final bool isSameEquipment =
                      e.equipment == exercise.equipment;

                  return InkWell(
                    onTap: () {
                      // Заменяем упражнение
                      final exerciseIndex = widget.exercises.indexOf(exercise);
                      setState(() {
                        widget.exercises[exerciseIndex] = e;
                        // Переносим логи сетов если нужно
                        if (_exerciseSets.containsKey(exerciseIndex)) {
                          _exerciseSets[widget.exercises.indexOf(e)] =
                              _exerciseSets[exerciseIndex]!;
                          _exerciseSets.remove(exerciseIndex);
                        }
                      });
                      Navigator.pop(context);
                      _showCustomSnackBar(
                        'Exercise replaced successfully',
                        icon: Icons.check_circle,
                        color: Color(0xFF00BE13).withOpacity(0.95),
                      );
                    },
                    child: Container(
                      margin: EdgeInsets.only(bottom: 12),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.1),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: isSameEquipment
                                  ? Colors.blue.withOpacity(0.2)
                                  : Colors.grey.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: Text(
                                _getExerciseEmoji(e.equipment),
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  e.name,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  '${e.equipment} • ${e.sets} sets • ${e.reps} reps',
                                  style: TextStyle(
                                    color: Colors.grey[400],
                                    fontSize: 14,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (isSameEquipment)
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.blue.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                'Same equipment',
                                style: TextStyle(
                                  color: Colors.blue,
                                  fontSize: 12,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Группируем упражнения по superSetId
    final Map<String?, List<Exercise>> exerciseGroups = {};
    for (var exercise in widget.exercises) {
      if (!exerciseGroups.containsKey(exercise.superSetId)) {
        exerciseGroups[exercise.superSetId] = [];
      }
      exerciseGroups[exercise.superSetId]!.add(exercise);
    }

    // Создаем отсортированный список, где валидные суперсеты (2+ упражнения) идут первыми
    final sortedExercises = <Exercise>[];

    // Сначала добавляем упражнения из валидных суперсетов (2 или более)
    exerciseGroups.forEach((superSetId, exercises) {
      if (superSetId != null && exercises.length >= 2) {
        sortedExercises.addAll(exercises);
      }
    });

    // Затем добавляем одиночные упражнения и невалидные суперсеты
    exerciseGroups.forEach((superSetId, exercises) {
      if (superSetId == null || exercises.length < 2) {
        sortedExercises.addAll(exercises);
      }
    });

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          // Основной градиент
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF1A1A1A), // Темный верх
                  Color(0xFF3C1A1A), // Темно-красный
                  Color(0xFF2D1001), // Темно-оранжевый
                  Color(0xFF0F2A4F), // Сине-стальной
                ],
                stops: [
                  0.0,
                  0.3,
                  0.6,
                  1.0
                ], // Контролируем распределение цветов
              ),
            ),
          ),

          // Акцентное свечение обновляем для лучшего сочетания
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(0.0, 0.2),
                  radius: 1.2,
                  colors: [
                    Color(0x1AFF4D00), // Оранжевое свечение с 10% прозрачностью
                    Color(0x262A5F8A), // Синее свечение с 15% прозрачностью
                    Colors.transparent,
                  ],
                  stops: [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          // Текстура с диагональными линиями
          Container(
            decoration: BoxDecoration(
              backgroundBlendMode: BlendMode.overlay,
              gradient: LinearGradient(
                begin: Alignment(-0.5, -0.866), // угол 30°
                end: Alignment(0.5, 0.866),
                colors: [
                  Colors.white.withOpacity(0.03), // 3% белый
                  Colors.transparent,
                ],
                stops: [0.4, 0.6],
                transform: GradientRotation(30 * 3.14 / 180),
              ),
            ),
          ),

          // Нижняя светлая полоса
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 10,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.white.withOpacity(0.02), // 2% белый
                  ],
                ),
              ),
            ),
          ),

          // Рамка
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: Colors.black.withOpacity(0.05), // 5% черный
                width: 1,
              ),
            ),
          ),

          // Основной контент
          SafeArea(
            child: Column(
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Icon(Icons.close, color: Colors.white, size: 24),
                      ),
                      Expanded(
                        child: Text(
                          'Focus Mode',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      SizedBox(width: 24),
                    ],
                  ),
                ),

                // Timer
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    _formatDuration(_elapsed),
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 60,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w800,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),

                // Exercise count
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${widget.exercises.length} exercises',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      IconButton(
                        padding: EdgeInsets.zero,
                        constraints: BoxConstraints(),
                        icon: Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 24,
                        ),
                        onPressed: _showAddExerciseModal,
                      ),
                    ],
                  ),
                ),

                // Exercise list
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.only(
                      left: 16,
                      right: 16,
                      bottom: 80,
                    ),
                    itemCount: sortedExercises.length,
                    itemBuilder: (context, index) {
                      final exercise = sortedExercises[index];
                      return _buildExerciseCard(exercise);
                    },
                  ),
                ),
              ],
            ),
          ),

          // Bottom navigation
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              child: Padding(
                padding: EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  height: 100,
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.bottomCenter,
                    children: [
                      Container(
                        width: 212,
                        height: 58,
                        decoration: BoxDecoration(
                          color: Color(0xFF0F0D10),
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                              onTap: _toggleFavorite,
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  _isFavorite ? Icons.star : Icons.star_border,
                                  color: _isFavorite
                                      ? Color(0xFFFFD700)
                                      : Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                            SizedBox(width: 16),
                            GestureDetector(
                              onTap: _showNotesDialog,
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.chat_bubble_outline,
                                  color: _notes.isNotEmpty
                                      ? Color(0xFFFFD700)
                                      : Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Кнопка с флагом
                      Positioned(
                        left: 66,
                        bottom: -11,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: Color(0xFFFFFFFF),
                            borderRadius: BorderRadius.circular(100),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(100),
                              onTap: _isCompleting ? null : _completeWorkout,
                              child: Center(
                                child: Text(
                                  '🏁',
                                  style: TextStyle(
                                    fontSize: 32,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    int hours = duration.inHours;
    int minutes = duration.inMinutes.remainder(60);
    int seconds = duration.inSeconds.remainder(60);
    return '${hours}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  String _formatTime(int seconds) {
    int hours = seconds ~/ 3600;
    int minutes = (seconds % 3600) ~/ 60;
    int remainingSeconds = seconds % 60;
    return '${hours > 0 ? '$hours:' : ''}${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  String _getExerciseEmoji(String equipment) {
    switch (equipment.toLowerCase()) {
      case 'dumbbells':
        return '🏋️';
      case 'bench':
        return '🛏️';
      case 'none':
        return '🦵';
      default:
        return '💪';
    }
  }

  Widget _buildExerciseCard(Exercise exercise) {
    bool isInSuperset = exercise.superSetId != null;

    // Получаем все упражнения в этом суперсете
    List<Exercise> supersetExercises = isInSuperset
        ? widget.exercises
            .where((e) => e.superSetId == exercise.superSetId)
            .toList()
        : [exercise];

    // Проверяем, является ли это валидным суперсетом (2+ упражнения)
    bool isValidSuperset = isInSuperset && supersetExercises.length >= 2;

    // Если это не валидный суперсет, обрабатываем как обычное упражнение
    if (!isValidSuperset) {
      isInSuperset = false;
      supersetExercises = [exercise];
    }

    bool isFirstInSuperset =
        isValidSuperset && supersetExercises.first == exercise;

    // Пропускаем все упражнения суперсета кроме первого
    if (isValidSuperset && !isFirstInSuperset) return SizedBox.shrink();

    bool isCompleted = isInSuperset
        ? supersetExercises.every((e) =>
            (_exerciseSets[widget.exercises.indexOf(e)]?.length ?? 0) >=
            int.parse(e.sets))
        : (_exerciseSets[widget.exercises.indexOf(exercise)]?.length ?? 0) >=
            int.parse(exercise.sets);

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) {
            Exercise? nextExercise;
            if (exercise.superSetId != null) {
              final currentIndex = widget.exercises.indexOf(exercise);
              if (currentIndex < widget.exercises.length - 1 &&
                  widget.exercises[currentIndex + 1].superSetId ==
                      exercise.superSetId) {
                nextExercise = widget.exercises[currentIndex + 1];
              }
            }

            return ExerciseSetScreen(
              exercise: exercise,
              onSetComplete: (reps, weight) {
                setState(() {
                  _exerciseSets.putIfAbsent(
                      widget.exercises.indexOf(exercise), () => []);
                  _exerciseSets[widget.exercises.indexOf(exercise)]
                      ?.add(SetLog(reps: reps, weight: weight));
                });
              },
              elapsed: _elapsed,
              videoUrl: exercise.videoUrl,
              nextExercise: nextExercise,
              exerciseSets: Map.fromEntries(
                _exerciseSets.entries.map(
                  (entry) => MapEntry(
                    widget.exercises[entry.key],
                    entry.value,
                  ),
                ),
              ),
              updateExerciseSets: (targetExercise, reps, weight) {
                setState(() {
                  _exerciseSets.putIfAbsent(
                      widget.exercises.indexOf(targetExercise), () => []);
                  _exerciseSets[widget.exercises.indexOf(targetExercise)]
                      ?.add(SetLog(reps: reps, weight: weight));
                });
              },
            );
          },
        ),
      ),
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(15),
          gradient: isCompleted
              ? LinearGradient(
                  colors: [Color(0xFF058743), Color(0xFF012110)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : (_exerciseSets[widget.exercises.indexOf(exercise)]?.length ??
                          0) >
                      0
                  ? LinearGradient(
                      colors: [
                        Color(0xFFFFD700).withOpacity(0.3),
                        Color(0xFF211B01)
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    )
                  : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isInSuperset)
              Container(
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Row(
                  children: [
                    Text(
                      'SUPERSET — ${supersetExercises.first.sets} rounds',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Spacer(),
                    if (isCompleted)
                      Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Color(0xFF00BE13),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          'COMPLETED',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ...supersetExercises.map((e) {
              bool isExerciseCompleted =
                  (_exerciseSets[widget.exercises.indexOf(e)]?.length ?? 0) >=
                      int.parse(e.sets);

              return Container(
                padding: EdgeInsets.all(16),
                child: Stack(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: isExerciseCompleted
                                ? Color(0xFF00BE13)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: isExerciseCompleted
                                    ? Color(0xFF00BE13).withOpacity(0.3)
                                    : Colors.transparent,
                                blurRadius: 8,
                                offset: Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              _getExerciseEmoji(e.equipment),
                              style: TextStyle(fontSize: 24),
                            ),
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                e.name,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.3,
                                ),
                              ),
                              if (isExerciseCompleted)
                                Text(
                                  'Completed',
                                  style: TextStyle(
                                    color: Color(0xFF00BE13),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                )
                              else
                                Row(
                                  children: [
                                    Text(
                                      (_exerciseSets[widget.exercises
                                                          .indexOf(e)]
                                                      ?.length ??
                                                  0) >
                                              0
                                          ? '${_exerciseSets[widget.exercises.indexOf(e)]?.length ?? 0}/${e.sets}'
                                          : '${e.sets} sets • ${e.reps} reps • ${e.weight ?? 50} lbs',
                                      style: TextStyle(
                                        color: Colors.grey[400],
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () => _showExerciseOptions(context, e),
                          child: Container(
                            padding: EdgeInsets.all(8),
                            child:
                                Icon(Icons.more_horiz, color: Colors.white70),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  bool _isFirstInSuperset(Exercise exercise) {
    if (exercise.superSetId == null) return false;
    return widget.exercises
            .where((e) => e.superSetId == exercise.superSetId)
            .first ==
        exercise;
  }

  int _getSupersetIndex(String supersetId) {
    final supersets = widget.exercises
        .where((e) => e.superSetId != null)
        .map((e) => e.superSetId)
        .toSet()
        .toList();
    return supersets.indexOf(supersetId) + 1;
  }

  bool _isSupersetCompleted(List<Exercise> supersetGroup) {
    return supersetGroup.every((exercise) {
      final completedSets =
          _exerciseSets[widget.exercises.indexOf(exercise)]?.length ?? 0;
      final totalSets = int.parse(exercise.sets);
      return completedSets == totalSets;
    });
  }

  bool _isSupersetInProgress(List<Exercise> supersetGroup) {
    return supersetGroup.any((exercise) {
      final completedSets =
          _exerciseSets[widget.exercises.indexOf(exercise)]?.length ?? 0;
      final totalSets = int.parse(exercise.sets);
      return completedSets > 0 && completedSets < totalSets;
    });
  }

  String _getSupersetProgress(List<Exercise> supersetGroup) {
    int totalSets = 0;
    int completedSets = 0;

    for (var exercise in supersetGroup) {
      totalSets += int.parse(exercise.sets);
      completedSets +=
          _exerciseSets[widget.exercises.indexOf(exercise)]?.length ?? 0;
    }

    return '$completedSets/$totalSets';
  }

  void _showExerciseOptions(BuildContext context, Exercise e) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewPadding.bottom),
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xFF1C1C1E),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Handle
              Container(
                margin: EdgeInsets.symmetric(vertical: 12),
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Title
              Padding(
                padding: EdgeInsets.only(bottom: 16),
                child: Text(
                  e.name,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              // First group - no dividers
              _buildOptionTile(
                icon: Icons.play_circle_outline,
                iconColor: Colors.blue,
                title: 'Video & Instructions',
                onTap: () {
                  Navigator.pop(context);
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => ExerciseVideoInstructions(
                      exercise: e,
                      videoUrl: e.videoUrl,
                    ),
                  );
                },
              ),
              _buildOptionTile(
                icon: Icons.history,
                iconColor: Colors.purple,
                title: 'Exercise History',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ExerciseHistoryScreen(
                        exercise: e,
                      ),
                    ),
                  );
                },
              ),
              _buildOptionTile(
                icon: Icons.swap_horiz,
                iconColor: Colors.blue,
                title: 'Replace',
                onTap: () {
                  Navigator.pop(context);
                  _showReplaceExerciseModal(e);
                },
              ),

              // Divider with gradient
              Container(
                height: 1,
                margin: EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              // Second group
              _buildOptionTile(
                icon: Icons.thumb_up,
                iconColor: Colors.green,
                title: 'Recommend more',
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Обновляем предпочтение пользователя (лайк)
                    await _ratingService.updateUserPreference(e, 1);
                    _showCustomSnackBar(
                      "We'll recommend more exercises like ${e.name}",
                      icon: Icons.thumb_up,
                      color: Colors.green.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.thumb_down,
                iconColor: Colors.orange,
                title: 'Recommend less',
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Обновляем предпочтение пользователя (дизлайк)
                    await _ratingService.updateUserPreference(e, -1);
                    _showCustomSnackBar(
                      "We'll recommend fewer exercises like ${e.name}",
                      icon: Icons.thumb_down,
                      color: Colors.orange.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.block,
                iconColor: Colors.red,
                title: "Don't recommend again",
                onTap: () async {
                  Navigator.pop(context);
                  try {
                    // Устанавливаем сильный негативный рейтинг
                    final updatedExercise =
                        e.copyWith(baseRating: 1.0, userPreference: -1);
                    await _ratingService.updateExerciseRating(updatedExercise);
                    _showCustomSnackBar(
                      "You won't see ${e.name} in recommendations anymore",
                      icon: Icons.block,
                      color: Colors.red.shade800,
                    );
                  } catch (error) {
                    _showCustomSnackBar(
                      "Couldn't update preference: $error",
                      icon: Icons.error_outline,
                      color: Colors.red.shade800,
                    );
                  }
                },
              ),

              Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),

              _buildOptionTile(
                icon: Icons.delete,
                iconColor: Colors.red,
                title: 'Delete from this workout',
                isDestructive: true,
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    widget.exercises.remove(e);
                    _exerciseSets.remove(widget.exercises.indexOf(e));
                  });
                },
              ),

              SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOptionTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: iconColor,
                size: 18,
              ),
            ),
            SizedBox(width: 12),
            Text(
              title,
              style: TextStyle(
                color: isDestructive ? Colors.red : Colors.white,
                fontSize: 16,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
