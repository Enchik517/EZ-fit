import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'dart:ui' as ui;

// Перечисление для выравнивания текста на верхнем уровне
enum TextAlignment { left, center, right }

class PlanReadyScreen extends StatelessWidget {
  final VoidCallback onGetPlan;
  final String gender;
  final double? currentWeight;
  final double? targetWeight;
  final List<String>? focusAreas;
  
  const PlanReadyScreen({
    Key? key,
    required this.onGetPlan,
    required this.gender,
    this.currentWeight,
    this.targetWeight,
    this.focusAreas,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Вычисляем данные для карточек
    final DateTime targetDate = _calculateTargetDate();
    final String formattedDate = DateFormat('d MMMM').format(targetDate);
    
    // Определяем фокус тренировки
    final String workoutFocus = _determineWorkoutFocus();
    
    // Определяем продолжительность тренировки
    final String workoutDuration = '20-30 min';
    
    // Рассчитываем примерные калории
    final int caloriesPerDay = _calculateDailyCalories();
    
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 40),
          
          // Чекмарк иконка
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: Colors.green,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.check,
              color: Colors.white,
              size: 40,
            ),
          ),
          
          SizedBox(height: 16),
          
          // Заголовок
          Text(
            'Your Plan is Ready',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w600,
            ),
          ),
          
          SizedBox(height: 24),
          
          // Карточка прогресса веса
          Container(
            margin: EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Верхняя надпись
                      Text(
                        'Based on your answers,',
                        style: GoogleFonts.inter(
                          color: Colors.grey[700],
                          fontSize: 12,
                        ),
                      ),
                      
                      SizedBox(height: 8),
                      
                      // Предсказание веса
                      RichText(
                        text: TextSpan(
                          style: GoogleFonts.inter(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                          ),
                          children: [
                            TextSpan(text: 'You\'ll be '),
                            TextSpan(
                              text: '${targetWeight?.toStringAsFixed(1) ?? "94.8"} kg',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            TextSpan(text: ' by'),
                          ],
                        ),
                      ),
                      
                      SizedBox(height: 4),
                      
                      // Целевая дата 
                      Text(
                        formattedDate,
                        style: GoogleFonts.inter(
                          color: Colors.red,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          height: 1.2,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                
                // График прогресса веса
                SizedBox(
                  height: 150,
                  child: CustomPaint(
                    painter: WeightProgressPainter(
                      startWeight: currentWeight ?? 100.8,
                      midWeight: (currentWeight ?? 100.8) * 0.97, // -3% для промежуточной точки
                      targetWeight: targetWeight ?? 94.8,
                      targetDate: targetDate,
                    ),
                  ),
                ),
                
                // Процент успеха
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    '83% of people in a similar situation to you have lost their weight using Juffit.',
                    style: GoogleFonts.inter(
                      color: Colors.grey[700],
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
          
          SizedBox(height: 16),
          
          // Карточка с деталями плана
          Container(
            margin: EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Plan Content',
                    style: GoogleFonts.inter(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                
                // Область фокуса тренировки
                _buildPlanDetailRow(
                  icon: Icons.fitness_center,
                  iconColor: Colors.blue,
                  title: 'Workout Area',
                  value: workoutFocus,
                ),
                
                // Продолжительность тренировки
                _buildPlanDetailRow(
                  icon: Icons.timer,
                  iconColor: Colors.orange,
                  title: 'Workout Duration',
                  value: workoutDuration,
                ),
                
                // Калории в день
                _buildPlanDetailRow(
                  icon: Icons.local_fire_department,
                  iconColor: Colors.red,
                  title: 'Calories',
                  value: '$caloriesPerDay kcal / day',
                  isLast: true,
                ),
              ],
            ),
          ),
          
          SizedBox(height: 24),
          
          // Кнопка GET MY PLAN
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: onGetPlan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF4CAF50),
                  foregroundColor: Colors.white,
                  elevation: 1,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: Text(
                  'GET MY PLAN',
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
          
          SizedBox(height: 24),
        ],
      ),
    );
  }
  
  Widget _buildPlanDetailRow({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String value,
    String? imageAsset,
    bool isLast = false,
  }) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        border: !isLast ? Border(bottom: BorderSide(color: Colors.grey[200]!)) : null,
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 20,
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  value,
                  style: GoogleFonts.inter(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  DateTime _calculateTargetDate() {
    // Простая логика для определения целевой даты
    return DateTime.now().add(Duration(days: 30));
  }
  
  String _determineWorkoutFocus() {
    if (focusAreas != null && focusAreas!.isNotEmpty) {
      if (focusAreas!.contains('Legs') || focusAreas!.contains('Glutes')) {
        return 'Lower body';
      } else if (focusAreas!.contains('Chest') || focusAreas!.contains('Arms')) {
        return 'Upper body';
      } else if (focusAreas!.contains('Core')) {
        return 'Core';
      }
    }
    return 'Full body'; // По умолчанию
  }
  
  int _calculateDailyCalories() {
    // Базовая формула для расчета примерного расхода калорий
    if (gender == 'Male') {
      return 163;
    } else {
      return 143;
    }
  }
}

class WeightProgressPainter extends CustomPainter {
  final double startWeight;
  final double midWeight;
  final double targetWeight;
  final DateTime targetDate;
  
  // Добавляем определение основных цветов для графика
  final primaryColor = Colors.blue[400]!;
  final midColor = Colors.purple[400]!;
  final endColor = Colors.pinkAccent;
  
  WeightProgressPainter({
    required this.startWeight,
    required this.midWeight,
    required this.targetWeight,
    required this.targetDate,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final width = size.width;
    final height = size.height;
    final padding = 20.0; // Увеличиваем отступы для лучшей видимости
    
    // Определяем точки для графика
    final startPoint = Offset(padding, height * 0.3);
    final midPoint = Offset(width * 0.4, height * 0.5);
    final endPoint = Offset(width - padding, height * 0.7);
    
    // Рисуем линию графика с улучшенными контрольными точками для более плавной кривой
    final path = Path()
      ..moveTo(startPoint.dx, startPoint.dy)
      ..quadraticBezierTo(
        midPoint.dx, midPoint.dy,
        endPoint.dx, endPoint.dy,
      );
    
    // Градиентная заливка для линии
    final paint = Paint()
      ..shader = LinearGradient(
        colors: [primaryColor, midColor, endColor],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, width, height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    
    canvas.drawPath(path, paint);
    
    // Рисуем точки на графике
    _drawPoint(canvas, startPoint, primaryColor);
    _drawPoint(canvas, midPoint, midColor);
    _drawPoint(canvas, endPoint, endColor);
    
    // Рисуем текстовые метки весов с учетом ограничений экрана
    _drawWeightLabel(canvas, startPoint, '${startWeight.toStringAsFixed(1)}kg', Alignment.topLeft, primaryColor);
    _drawWeightLabel(canvas, midPoint, '${midWeight.toStringAsFixed(1)}kg', Alignment.topRight, midColor);
    _drawWeightLabel(canvas, endPoint, '${targetWeight.toStringAsFixed(1)}kg', Alignment.center, endColor);
    
    // Рисуем метки времени, используя безопасную отрисовку
    _drawSafeText(
      canvas: canvas, 
      text: 'Today',
      position: Offset(padding, height - 10),
      style: TextStyle(color: Colors.grey[600], fontSize: 10),
      alignment: TextAlignment.left,
      maxWidth: width * 0.3
    );
    
    _drawSafeText(
      canvas: canvas, 
      text: 'Last week',
      position: Offset(width * 0.4, height - 10),
      style: TextStyle(color: Colors.grey[600], fontSize: 10),
      alignment: TextAlignment.center,
      maxWidth: width * 0.3
    );
    
    // Дату отрисовываем отдельно в бейдже
    _drawDateBadge(canvas, endPoint, DateFormat('MMM').format(targetDate), DateFormat('d').format(targetDate), width);
  }
  
  void _drawPoint(Canvas canvas, Offset position, Color color) {
    // Внешний круг
    final outerPaint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(position, 8, outerPaint);
    
    // Внутренний белый круг
    final innerPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(position, 4, innerPaint);
  }
  
  void _drawWeightLabel(Canvas canvas, Offset position, String text, Alignment alignment, Color color) {
    // Используем безопасный метод для рисования текста
    Offset textPosition;
    TextAlignment textAlignment;
    
    if (alignment == Alignment.topLeft) {
      textPosition = Offset(position.dx, position.dy - 20);
      textAlignment = TextAlignment.left;
    } else if (alignment == Alignment.topRight) {
      textPosition = Offset(position.dx, position.dy - 20);
      textAlignment = TextAlignment.center;
    } else {
      textPosition = Offset(position.dx, position.dy + 20);
      textAlignment = TextAlignment.right;
    }
    
    _drawSafeText(
      canvas: canvas,
      text: text,
      position: textPosition,
      style: TextStyle(
        color: color,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),
      alignment: textAlignment,
      maxWidth: 60
    );
  }
  
  // Новый метод для безопасной отрисовки текста с ограничением по ширине
  void _drawSafeText({
    required Canvas canvas,
    required String text,
    required Offset position,
    required TextStyle style,
    TextAlignment alignment = TextAlignment.left,
    double maxWidth = 100,
  }) {
    // Определяем выравнивание текста
    ui.TextAlign textAlign = ui.TextAlign.left; // Устанавливаем значение по умолчанию
    double xOffset = 0;
    
    switch (alignment) {
      case TextAlignment.left:
        textAlign = ui.TextAlign.left;
        break;
      case TextAlignment.center:
        textAlign = ui.TextAlign.center;
        xOffset = -maxWidth / 2;
        break;
      case TextAlignment.right:
        textAlign = ui.TextAlign.right;
        xOffset = -maxWidth;
        break;
    }
    
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      textAlign: textAlign,
      fontSize: style.fontSize ?? 12.0,
      ellipsis: '...',
      maxLines: 1,
    ))
      ..pushStyle(style.getTextStyle())
      ..addText(text);
    
    final paragraph = builder.build()
      ..layout(ui.ParagraphConstraints(width: maxWidth));
    
    canvas.drawParagraph(paragraph, Offset(position.dx + xOffset, position.dy - paragraph.height / 2));
  }
  
  // Улучшенный метод для рисования бейджа с датой
  void _drawDateBadge(Canvas canvas, Offset endPoint, String month, String day, double screenWidth) {
    // Измеряем текст, чтобы определить размер бейджа
    final textStyle = TextStyle(
      color: Colors.white,
      fontSize: 10,
      fontWeight: FontWeight.w600,
    );
    
    final textWidth = _measureText('$month $day', textStyle);
    
    // Минимальная ширина бейджа
    final badgeWidth = textWidth + 20.0;
    final badgeHeight = 26.0;
    
    // Убедимся, что бейдж не выходит за пределы экрана
    double xPos = endPoint.dx;
    if (xPos + badgeWidth/2 > screenWidth - 10) {
      xPos = screenWidth - badgeWidth/2 - 10;
    }
    
    // Рисуем красный прямоугольник
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(xPos, endPoint.dy - 20), width: badgeWidth, height: badgeHeight),
      Radius.circular(badgeHeight / 2),
    );
    
    final paint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;
    
    canvas.drawRRect(rect, paint);
    
    // Рисуем текст месяца и дня вместе, центрированный внутри бейджа
    _drawSafeText(
      canvas: canvas,
      text: "$month $day",
      position: Offset(xPos, endPoint.dy - 20),
      style: textStyle,
      alignment: TextAlignment.center,
      maxWidth: badgeWidth - 10
    );
  }
  
  // Вспомогательный метод для измерения ширины текста
  double _measureText(String text, TextStyle style) {
    final builder = ui.ParagraphBuilder(ui.ParagraphStyle(
      fontSize: style.fontSize ?? 12.0,
    ))
      ..pushStyle(style.getTextStyle())
      ..addText(text);
    
    final paragraph = builder.build()
      ..layout(ui.ParagraphConstraints(width: double.infinity));
    
    return paragraph.longestLine;
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
} 