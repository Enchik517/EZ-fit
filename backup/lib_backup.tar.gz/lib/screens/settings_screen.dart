import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import '../providers/subscription_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final subscriptionProvider = Provider.of<SubscriptionProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          // Пункт меню подписки
          ListTile(
            title: Text(
              subscriptionProvider.isSubscribed ? 'Управление подпиской' : 'Премиум доступ'
            ),
            subtitle: Text(
              subscriptionProvider.isSubscribed ? 'Управление вашей подпиской' : 'Разблокируйте все функции'
            ),
            leading: Icon(
              Icons.star,
              color: subscriptionProvider.isSubscribed ? Colors.amber : Colors.grey,
            ),
            onTap: () => Navigator.of(context).pushNamed('/subscription'),
          ),
          const Divider(),
          ListTile(
            title: const Text('Delete Account'),
            subtitle: const Text('This action cannot be undone'),
            leading: const Icon(Icons.delete_forever, color: Colors.red),
            onTap: () => _showDeleteAccountDialog(context),
          ),
          ListTile(
            title: const Text('Sign Out'),
            leading: const Icon(Icons.logout),
            onTap: () => _signOut(context),
          ),
        ],
      ),
    );
  }

  Future<void> _showDeleteAccountDialog(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Account'),
        content: const Text(
          'Are you sure you want to delete your account? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _deleteAccount(context);
    }
  }

  Future<void> _deleteAccount(BuildContext context) async {
    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.deleteAccount();
      // Navigate to auth screen
      Navigator.of(context).pushReplacementNamed('/auth');
    } catch (e) {
      _showErrorDialog(context, 'Failed to delete account');
    }
  }

  Future<void> _signOut(BuildContext context) async {
    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.signOut();
      // Navigate to auth screen
      Navigator.of(context).pushReplacementNamed('/auth');
    } catch (e) {
      _showErrorDialog(context, 'Failed to sign out');
    }
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
} 