import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import '../models/exercise.dart';

class WorkoutCategoryScreen extends StatefulWidget {
  final String categoryName;
  final String categoryDescription;

  const WorkoutCategoryScreen({
    Key? key,
    required this.categoryName,
    required this.categoryDescription,
  }) : super(key: key);

  @override
  State<WorkoutCategoryScreen> createState() => _WorkoutCategoryScreenState();
}

class _WorkoutCategoryScreenState extends State<WorkoutCategoryScreen> {
  List<Exercise> exercises = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadExercises();
  }

  Future<void> _loadExercises() async {
    try {
      final String jsonString =
          await rootBundle.loadString('assets/exercise.json');
      final List<dynamic> jsonData = json.decode(jsonString);

      // Фильтруем упражнения в зависимости от категории
      List<String> exerciseNames =
          _getExercisesForCategory(widget.categoryName);

      // Преобразуем данные JSON в объекты Exercise
      List<Exercise> loadedExercises = [];
      for (var item in jsonData) {
        if (exerciseNames.contains(item['name'])) {
          loadedExercises.add(Exercise.fromJson(item));
        }
      }

      setState(() {
        exercises = loadedExercises;
        isLoading = false;
      });
    } catch (e) {
      //print('Ошибка загрузки упражнений: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  // Метод для получения списка упражнений для выбранной категории
  List<String> _getExercisesForCategory(String category) {
    switch (category) {
      case 'Express Workouts':
        return [
          'Push-Up',
          'Bodyweight Squat',
          'Forward Lunge',
          'Reverse Lunge',
          'High Plank',
          'Low Plank (Elbow Plank)',
          'Glute Bridge',
          'Superman',
          'Inchworm',
          'Mountain Climber',
        ];
      case 'HIIT':
        return [
          'Jump Squat',
          'Plank Jacks',
          'Mountain Climber',
          'Burpee',
          'Jumping Lunge',
        ];
      case 'Home Vibe':
        return [
          'Push-Up',
          'Knee Push-Up',
          'Incline Push-Up',
          'Wide Grip Push-Up',
          'Spiderman Push-Up',
          'Hindu Push-Up',
          'Bodyweight Squat',
          'Sumo Squat',
          'Narrow Squat',
          'Jump Squat',
          'Split Squat (Bodyweight)',
          'Bulgarian Split Squat (Bodyweight)',
          'Pistol Squat',
          'Wall Sit',
          'Air Squat',
          'Duck Walk',
          'Forward Lunge',
          'Reverse Lunge',
          'Walking Lunge',
          'Curtsy Lunge',
          'Side Lunge',
          'Jumping Lunge',
          'Clock Lunge',
          'Overhead Lunge',
          'Lunge with Twist',
          'Elevated Lunge',
          'High Plank',
          'Low Plank (Elbow Plank)',
          'Side Plank',
          'Plank with Shoulder Taps',
          'Plank Jacks',
          'Plank Up-Downs',
          'Reverse Plank',
          'Single-Leg Plank',
          'Bird Dog Plank',
          'Spider Plank',
          'Burpee',
          'Mountain Climber',
          'Donkey Kick',
          'Glute Bridge',
          'Superman',
          'Bear Crawl',
          'Crab Walk',
          'Inchworm',
          'Hip Thrust (Bodyweight)',
          'V-Up',
        ];
      case 'Peaches 🍑':
        return [
          'Sumo Squat',
          'Split Squat (Bodyweight)',
          'Bulgarian Split Squat (Bodyweight)',
          'Curtsy Lunge',
          'Side Lunge',
          'Donkey Kick',
          'Glute Bridge',
          'Superman',
          'Hip Thrust (Bodyweight)',
          'Barbell Deadlift',
          'Barbell Romanian Deadlift',
          'Barbell Hip Thrust',
        ];
      case 'Strength':
        return [
          'Decline Push-Up',
          'Close Grip Push-Up',
          'Diamond Push-Up',
          'Pike Push-Up',
          'Pistol Squat',
          'Barbell Back Squat',
          'Barbell Front Squat',
          'Barbell Deadlift',
          'Barbell Romanian Deadlift',
          'Barbell Lunge',
          'Barbell Bench Press',
          'Barbell Incline Bench Press',
          'Barbell Decline Bench Press',
          'Barbell Overhead Press',
          'Barbell Bent-Over Row',
          'Barbell Clean',
          'Barbell Snatch',
          'Barbell Hip Thrust',
          'Barbell Shrug',
        ];
      case 'Full Body':
        return [
          'Burpee',
          'Bear Crawl',
          'Crab Walk',
          'Inchworm',
          'Barbell Clean',
          'Barbell Snatch',
        ];
      default:
        return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          widget.categoryName,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              widget.categoryDescription,
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
          ),
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(
                color: Colors.blue,
              ),
            )
          else if (exercises.isEmpty)
            Center(
              child: Text(
                'Упражнения не найдены',
                style: TextStyle(color: Colors.grey[400]),
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: exercises.length,
                itemBuilder: (context, index) {
                  final exercise = exercises[index];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF252527),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            exercise.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            exercise.description,
                            style: TextStyle(
                              color: Colors.grey[400],
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              _buildInfoChip(
                                'Сложность: ${exercise.difficultyLevel}',
                                Colors.blue,
                              ),
                              const SizedBox(width: 8),
                              _buildInfoChip(
                                'Оборудование: ${exercise.equipment}',
                                Colors.green,
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          _buildInfoChip(
                            'Мышечная группа: ${exercise.muscleGroup}',
                            Colors.orange,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color.withOpacity(0.8),
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
