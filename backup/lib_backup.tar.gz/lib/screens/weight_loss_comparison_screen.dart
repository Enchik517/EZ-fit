import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math';

class WeightLossComparisonScreen extends StatelessWidget {
  final VoidCallback onNext;
  final String gender;
  final double? weight;
  final double? bodyFat;
  final double? waistSize;
  
  // Добавляем параметры для желаемых значений
  final double? targetWeight;
  final double? targetBodyFat;
  final double? targetWaistSize;
  
  const WeightLossComparisonScreen({
    Key? key,
    required this.onNext,
    required this.gender,
    this.weight,
    this.bodyFat,
    this.waistSize,
    this.targetWeight, // Новый параметр для целевого веса
    this.targetBodyFat, // Новый параметр для целевого процента жира
    this.targetWaistSize, // Новый параметр для целевого размера талии
  }) : super(key: key);

  // Расчет текущих значений
  double get initialWeight => weight ?? (gender == 'Female' ? 65.0 : 82.0);
  double get initialBodyFat => bodyFat ?? (gender == 'Female' ? 35.0 : 24.0);
  double get initialWaistSize => waistSize ?? (gender == 'Female' ? 83.0 : 92.0);
  
  // Используем введенные пользователем значения или вычисляем, если они не предоставлены
  double get predictedWeight => targetWeight ?? max(initialWeight - 1.0, initialWeight * 0.98);
  double get predictedBodyFat => targetBodyFat ?? max(initialBodyFat - 2.0, initialBodyFat * 0.94);
  double get predictedWaistSize => targetWaistSize ?? max(initialWaistSize - 4.0, initialWaistSize * 0.95);

  @override
  Widget build(BuildContext context) {
    // Получаем размер экрана
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 360; // Определяем маленькие экраны
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 32),
        
        // Title
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Text(
            'Here is how weight loss can\nchange you in just 7 days',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: isSmallScreen ? 22 : 24,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        
        SizedBox(height: 32),
        
        // Comparison card
        Container(
          margin: EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
          padding: EdgeInsets.all(isSmallScreen ? 16 : 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Body fat comparison
              _buildMetricComparisonRow(
                title: 'Body Fat', 
                beforeValue: '${initialBodyFat.toStringAsFixed(0)}%', 
                afterValue: '${predictedBodyFat.toStringAsFixed(0)}%',
                isSmallScreen: isSmallScreen,
              ),
              
              SizedBox(height: 16),
              
              // Waist size comparison
              _buildMetricComparisonRow(
                title: 'Waist Size', 
                beforeValue: '${initialWaistSize.toStringAsFixed(0)} cm', 
                afterValue: '${predictedWaistSize.toStringAsFixed(0)} cm',
                isSmallScreen: isSmallScreen,
              ),
              
              SizedBox(height: 16),
              
              // Weight comparison
              _buildMetricComparisonRow(
                title: 'Weight', 
                beforeValue: '${initialWeight.toStringAsFixed(0)} kg', 
                afterValue: '${predictedWeight.toStringAsFixed(0)} kg',
                isSmallScreen: isSmallScreen,
              ),
              
              SizedBox(height: 20),
              
              // Note about healthy weight loss
              Text(
                'Rapid weight loss isn\'t healthy, but 1-1.5kg per\nweek is achievable and lasting',
                style: GoogleFonts.inter(
                  color: Colors.grey[600],
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        
        Spacer(),
        
        // Next button
        Padding(
          padding: const EdgeInsets.all(24),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Next',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildMetricComparisonRow({
    required String title,
    required String beforeValue,
    required String afterValue,
    bool isSmallScreen = false,
  }) {
    return Column(
      children: [
        // Заголовок метрики
        Container(
          width: double.infinity,
          alignment: Alignment.center,
          margin: EdgeInsets.only(bottom: 8),
          child: Text(
            title,
            style: GoogleFonts.inter(
              color: Colors.black,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        
        // Строка со сравнением значений
        SizedBox(
          height: 36,
          child: Row(
            children: [
              // Значение "до"
              Expanded(
                child: ClipPath(
                  clipper: LeftSlantClipper(),
                  child: Container(
                    color: Colors.black,
                    alignment: Alignment.center,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 4),
                        child: Text(
                          beforeValue,
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 14 : 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              
              // Стрелки между значениями
              Container(
                width: isSmallScreen ? 36 : 50,
                alignment: Alignment.center,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    4,
                    (index) => Padding(
                      padding: EdgeInsets.symmetric(horizontal: isSmallScreen ? 0.5 : 1),
                      child: Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.pink[300],
                        size: isSmallScreen ? 8 : 10,
                      ),
                    ),
                  ),
                ),
              ),
              
              // Значение "после"
              Expanded(
                child: ClipPath(
                  clipper: RightSlantClipper(),
                  child: Container(
                    color: Colors.pink,
                    alignment: Alignment.center,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 4),
                        child: Text(
                          afterValue,
                          style: GoogleFonts.inter(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 14 : 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// Класс для вырезания наклонного левого края (для правого блока)
class RightSlantClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(10, 0); // Начинаем с отступа слева вверху
    path.lineTo(size.width, 0); // Верхняя граница
    path.lineTo(size.width, size.height); // Правая граница
    path.lineTo(10, size.height); // Нижняя граница с тем же отступом
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

// Класс для вырезания наклонного правого края (для левого блока)
class LeftSlantClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, 0); // Начинаем с верхнего левого угла
    path.lineTo(size.width - 10, 0); // Верхняя граница с отступом справа
    path.lineTo(size.width - 10, size.height); // Правая граница с тем же отступом
    path.lineTo(0, size.height); // Нижняя граница
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
} 