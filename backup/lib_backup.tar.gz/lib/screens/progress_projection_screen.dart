import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math'; // Добавляем импорт для функции min
import 'package:flutter/rendering.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;

class ProgressProjectionScreen extends StatelessWidget {
  final VoidCallback onNext;
  final String gender;
  final int? age;
  final double? currentWeight;
  final double? targetWeight;
  final double? height;
  final String? bodyFatRange;
  
  const ProgressProjectionScreen({
    Key? key, 
    required this.onNext,
    required this.gender,
    this.age,
    this.currentWeight,
    this.targetWeight,
    this.height,
    this.bodyFatRange,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final weightDifference = (currentWeight ?? 0) - (targetWeight ?? 0);
    final isWeightLoss = weightDifference > 0;
    final goalDifficulty = _calculateDifficulty();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 16),
        
        // Title
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Text(
            'You have great potential to\ncrush your goals',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        
        SizedBox(height: 32),
        
        // Chart container
        Container(
          margin: EdgeInsets.symmetric(horizontal: 24),
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              // Chart
              SizedBox(
                height: 180,
                width: double.infinity,
                child: CustomPaint(
                  painter: ProgressGraphPainter(
                    difficulty: goalDifficulty,
                    isWeightLoss: isWeightLoss,
                    weightDifference: weightDifference.abs(),
                    useAppleEmojis: true, // Включаем режим Apple эмоджи
                  ),
                ),
              ),
              
              SizedBox(height: 16),
              
              // Text description
              RichText(
                text: TextSpan(
                  style: GoogleFonts.inter(
                    color: Colors.black87,
                    fontSize: 13,
                  ),
                  children: [
                    TextSpan(
                      text: 'Based on historical data. ',
                      style: TextStyle(fontStyle: FontStyle.italic),
                    ),
                    TextSpan(
                      text: gender == 'Female' 
                          ? 'For women in their ${age != null ? "${age}s" : "20s"}' 
                          : 'For men in their ${age != null ? "${age}s" : "20s"}',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    TextSpan(
                      text: _getPersonalizedText(isWeightLoss),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        
        Spacer(),
        
        // Next button
        Padding(
          padding: const EdgeInsets.all(24),
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text(
                'Next',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  double _calculateDifficulty() {
    // 0.0 = легко, 1.0 = сложно
    double difficulty = 0.5; // По умолчанию средняя сложность
    
    if (currentWeight != null && targetWeight != null) {
      // Разница в весе влияет на сложность
      final diff = (currentWeight! - targetWeight!).abs();
      if (diff > 20) difficulty += 0.3;
      else if (diff > 10) difficulty += 0.1;
      else if (diff < 5) difficulty -= 0.1;
    }
    
    if (age != null) {
      // Возраст влияет на сложность
      if (age! > 40) difficulty += 0.2;
      else if (age! < 25) difficulty -= 0.1;
    }
    
    // Ограничиваем от 0.1 до 0.9
    return difficulty.clamp(0.1, 0.9);
  }
  
  String _getPersonalizedText(bool isWeightLoss) {
    if (gender == 'Female') {
      if (isWeightLoss) {
        return ', weight loss is usually delayed at first, but after 7 days, you can burn off calories like crazy!';
      } else {
        return ', muscle building takes consistency but your body will show amazing progress after regular training!';
      }
    } else {
      if (isWeightLoss) {
        return ', men tend to lose weight more steadily, and you should see consistent results within the first 2 weeks!';
      } else {
        return ', muscle growth begins slowly, but after consistent training for 7 days, your body adapts and progress accelerates!';
      }
    }
  }
}

class ProgressGraphPainter extends CustomPainter {
  final double difficulty;
  final bool isWeightLoss;
  final double weightDifference;
  final bool useAppleEmojis; // Новый параметр для контроля типа эмоджи
  
  ProgressGraphPainter({
    this.difficulty = 0.5,
    this.isWeightLoss = true,
    this.weightDifference = 10.0,
    this.useAppleEmojis = false, // По умолчанию используем обычные эмоджи
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final width = size.width;
    final height = size.height;
    
    // Dimensions
    final padding = 15.0;
    final maxHeight = height - 40;
    final safetyMargin = 30.0;
    
    // Colors
    final Color primaryColor = isWeightLoss 
        ? Color(0xFFFF3B69) // Brighter red for weight loss (more vibrant)
        : Color(0xFF00C853); // Brighter green for muscle gain
    
    final Color secondaryColor = isWeightLoss
        ? Color(0xFFFFCCD5) // Light pink
        : Color(0xFFB9FBD0); // Light green
    
    final Color axisColor = Color(0xFF90A4AE);
    final Color labelColor = Color(0xFF546E7A);
    final Color gridLineColor = Color(0xFFECEFF1);
    
    // Setup paints
    final axisPaint = Paint()
      ..color = axisColor
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    
    final gridPaint = Paint()
      ..color = gridLineColor
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    
    final curvePaint = Paint()
      ..color = primaryColor
      ..strokeWidth = 4.0 // Thicker line for more prominence
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    
    final areaGradientPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          primaryColor.withOpacity(0.5),
          primaryColor.withOpacity(0.05),
        ],
      ).createShader(Rect.fromLTWH(0, 0, width, height))
      ..style = PaintingStyle.fill;
    
    final pointOuterPaint = Paint()
      ..color = primaryColor
      ..style = PaintingStyle.fill;
    
    final pointInnerPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    
    final goalPaint = Paint()
      ..color = primaryColor.withOpacity(0.8)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    
    // Text styles
    final labelStyle = TextStyle(
      color: labelColor,
      fontSize: 12,
      fontWeight: FontWeight.w500,
    );
    
    final goalStyle = TextStyle(
      color: primaryColor,
      fontSize: 13,
      fontWeight: FontWeight.bold,
    );
    
    // Draw subtle grid lines
    for (int i = 1; i <= 3; i++) {
      double y = height - 40 - (maxHeight - safetyMargin) * (i / 3);
      canvas.drawLine(
        Offset(padding, y),
        Offset(width - padding, y),
        gridPaint,
      );
    }
    
    // Draw X-axis
    canvas.drawLine(
      Offset(padding, height - 30),
      Offset(width - padding, height - 30),
      axisPaint,
    );
    
    // Draw time labels with improved spacing and color coding
    final labels = ['3 Days', '7 Days', '30 Days'];
    final positions = [
      padding + (width - 2 * padding) * 0.2, 
      padding + (width - 2 * padding) * 0.5, 
      padding + (width - 2 * padding) * 0.85
    ];
    
    for (int i = 0; i < labels.length; i++) {
      // Use different colors for labels to match the milestone colors
      final labelColor = i == 2 ? primaryColor : Color(0xFF2196F3);
      
      final xAxisTextPainter = TextPainter(
        text: TextSpan(
          text: labels[i], 
          style: TextStyle(
            color: labelColor,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          )
        ),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      );
      xAxisTextPainter.layout();
      
      // Обеспечиваем одинаковое центрирование меток под точками
      double labelX = positions[i] - xAxisTextPainter.width / 2;
      
      // Убедимся, что метка не выходит за границы экрана
      labelX = labelX.clamp(padding, width - padding - xAxisTextPainter.width);
      
      xAxisTextPainter.paint(canvas, Offset(labelX, height - 25));
      
      // Draw tick marks on x-axis
      canvas.drawLine(
        Offset(positions[i], height - 30),
        Offset(positions[i], height - 27),
        Paint()..color = labelColor..strokeWidth = 1.5
      );
    }
    
    // Calculate curve parameters
    final maxProgressHeight = maxHeight - safetyMargin;
    double scaleFactor = maxProgressHeight / 180.0;
    
    // Adjust steepness based on weight difference
    final steepnessBase = (weightDifference / 20.0).clamp(0.5, 1.5);
    
    // Scale based on difficulty
    double steepnessFactor = isWeightLoss
        ? (difficulty > 0.5 ? steepnessBase * 1.2 : steepnessBase * 0.9)
        : (difficulty > 0.5 ? steepnessBase * 0.8 : steepnessBase);
    
    // Apply scaling to keep within bounds
    final maxScaledValue = 160.0 * steepnessFactor * scaleFactor;
    if (maxScaledValue > maxProgressHeight) {
      scaleFactor = maxProgressHeight / (160.0 * steepnessFactor);
    }
    
    // Calculate progress values with scaling
    final initialProgress = (difficulty < 0.5 ? 60.0 : 45.0) * scaleFactor;
    final midProgress = (difficulty < 0.5 ? 100.0 : 80.0) * scaleFactor;
    final finalProgress = (difficulty < 0.5 ? 160.0 : 140.0) * scaleFactor;
    
    // Goal position
    final goalPosition = padding + (width - 2 * padding) * (difficulty < 0.5 ? 0.7 : 0.85);
    
    // Start point
    final startPoint = Offset(padding, height - 40);
    
    // Calculate curve points
    final point1 = Offset(positions[0], height - 40 - (initialProgress * steepnessFactor));
    final point2 = Offset(positions[1], height - 40 - (midProgress * steepnessFactor));
    final point3 = Offset(goalPosition, height - 40 - (finalProgress * steepnessFactor));
    
    // Draw path for the gradient fill area
    final areaPath = Path();
    areaPath.moveTo(startPoint.dx, startPoint.dy);
    
    // Use same control points as the curve
    final control1 = Offset(padding + (point1.dx - padding) * 0.5, startPoint.dy);
    final control2 = Offset(padding + (point1.dx - padding) * 0.8, point1.dy + (startPoint.dy - point1.dy) * 0.3);
    areaPath.cubicTo(control1.dx, control1.dy, control2.dx, control2.dy, point1.dx, point1.dy);
    
    final control3 = Offset(point1.dx + (point2.dx - point1.dx) * 0.4, point1.dy - (point1.dy - point2.dy) * 0.1);
    final control4 = Offset(point1.dx + (point2.dx - point1.dx) * 0.7, point2.dy + (point1.dy - point2.dy) * 0.1);
    areaPath.cubicTo(control3.dx, control3.dy, control4.dx, control4.dy, point2.dx, point2.dy);
    
    final control5 = Offset(point2.dx + (point3.dx - point2.dx) * 0.4, point2.dy - (point2.dy - point3.dy) * 0.3);
    final control6 = Offset(point2.dx + (point3.dx - point2.dx) * 0.7, point3.dy + (point2.dy - point3.dy) * 0.1);
    areaPath.cubicTo(control5.dx, control5.dy, control6.dx, control6.dy, point3.dx, point3.dy);
    
    // Complete the path for area fill
    areaPath.lineTo(point3.dx, height - 30);
    areaPath.lineTo(padding, height - 30);
    areaPath.close();
    
    // Draw the area fill
    canvas.drawPath(areaPath, areaGradientPaint);
    
    // Draw the "Goal" vertical line with dash pattern
    final dashWidth = 5.0;
    final dashSpace = 3.0;
    double startY = point3.dy;
    final endY = height - 30;
    
    while (startY < endY) {
      final endDashY = startY + dashWidth < endY ? startY + dashWidth : endY;
      canvas.drawLine(
        Offset(point3.dx, startY),
        Offset(point3.dx, endDashY),
        goalPaint,
      );
      startY = endDashY + dashSpace;
    }
    
    // Draw "Goal" label with custom styling
    final goalTextPainter = TextPainter(
      text: TextSpan(text: 'Goal', style: goalStyle),
      textDirection: TextDirection.ltr,
    );
    goalTextPainter.layout();
    
    // Reposition goal bubble to the right side of the point
    final bubbleRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(point3.dx + 25, point3.dy - 5), // Move to the right and slightly up
        width: goalTextPainter.width + 16,
        height: goalTextPainter.height + 8
      ),
      Radius.circular(12),
    );
    
    final bubblePaint = Paint()
      ..color = secondaryColor
      ..style = PaintingStyle.fill;
    
    canvas.drawRRect(bubbleRect, bubblePaint);
    goalTextPainter.paint(
      canvas, 
      Offset(
        point3.dx + 25 - goalTextPainter.width / 2, 
        point3.dy - 5 - goalTextPainter.height / 2
      )
    );
    
    // Draw progress curve
    final path = Path();
    path.moveTo(startPoint.dx, startPoint.dy);
    
    // Draw the curve with the same control points
    path.cubicTo(control1.dx, control1.dy, control2.dx, control2.dy, point1.dx, point1.dy);
    path.cubicTo(control3.dx, control3.dy, control4.dx, control4.dy, point2.dx, point2.dy);
    path.cubicTo(control5.dx, control5.dy, control6.dx, control6.dy, point3.dx, point3.dy);
    
    canvas.drawPath(path, curvePaint);
    
    // Draw milestone points
    final milestones = [startPoint, point1, point2, point3];
    
    // Используем эмоджи в стиле iOS или обычные Unicode эмоджи
    final emojis = useAppleEmojis 
        ? ['', '😜', '😉', '😄'] // Те же эмоджи, но будут отображаться в стиле iOS
        : ['', '😜', '😉', '😄']; // Те же эмоджи для Android
    
    final emojiTextPainter = TextPainter(
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );
    
    // Сначала отрисовываем точки
    for (int i = 0; i < milestones.length; i++) {
      final point = milestones[i];
      
      // Draw milestone circles for all points except the first
      if (i > 0) {
        // Define colors for each point
        final Color pointColor = i == 3 
            ? primaryColor  // Goal point (red)
            : Color(0xFF2196F3); // Intermediate points (blue)
            
        // Outer circle with glowing effect
        final glowPaint = Paint()
          ..color = pointColor.withOpacity(0.3)
          ..style = PaintingStyle.fill;
        
        canvas.drawCircle(point, 18, glowPaint);
        
        // Main colored circle
        canvas.drawCircle(point, 14, Paint()..color = pointColor..style = PaintingStyle.fill);
        
        // Inner white circle
        canvas.drawCircle(point, 10, pointInnerPaint);
      }
    }
    
    // Точные позиции для эмоджи на основе скриншота
    final List<Offset> exactEmojiPositions = [
      Offset(point1.dx - 30, point1.dy - 30),
      Offset(point1.dx + (point2.dx - point1.dx) * 0.5, point1.dy + (point2.dy - point1.dy) * 0.5 - 40),
      Offset(point3.dx - 60, point3.dy - 50),
    ];
    
    // Устанавливаем шрифт для эмоджи в стиле iOS
    final emojiStyle = TextStyle(
      fontSize: 38,
      fontFamily: _getEmojiFont(useAppleEmojis),
      height: 1.0, // Убираем лишнее пространство
    );
    
    // Отрисовываем эмоджи поверх линий графика
    for (int i = 0; i < exactEmojiPositions.length; i++) {
      // Получаем эмоджи и его позицию
      final emoji = emojis[i + 1];
      final position = exactEmojiPositions[i];
      
      // Настраиваем отрисовку эмоджи с нужным шрифтом
      emojiTextPainter.text = TextSpan(
        text: emoji,
        style: emojiStyle,
      );
      emojiTextPainter.layout();
      
      // Центрируем эмоджи относительно заданной позиции
      double emojiX = position.dx - emojiTextPainter.width / 2;
      double emojiY = position.dy - emojiTextPainter.height / 2;
      
      // Убедимся, что эмоджи не выходит за границы
      emojiX = emojiX.clamp(padding, width - padding - emojiTextPainter.width);
      emojiY = emojiY.clamp(10, height - 40 - emojiTextPainter.height);
      
      // Отображаем эмоджи
      emojiTextPainter.paint(canvas, Offset(emojiX, emojiY));
    }
  }

  @override
  bool shouldRepaint(covariant ProgressGraphPainter oldDelegate) => 
      oldDelegate.difficulty != difficulty ||
      oldDelegate.isWeightLoss != isWeightLoss ||
      oldDelegate.weightDifference != weightDifference ||
      oldDelegate.useAppleEmojis != useAppleEmojis;
}

// Определяем подходящий шрифт для эмоджи в зависимости от платформы
String? _getEmojiFont(bool useAppleStyle) {
  if (!useAppleStyle) return null;
  
  try {
    if (Platform.isIOS || Platform.isMacOS) {
      // На iOS и macOS используем системный шрифт для эмоджи
      return null;
    } else {
      // На других платформах пытаемся использовать Apple Color Emoji
      return 'Apple Color Emoji';
    }
  } catch (e) {
    // Для веб и других платформ, где Platform недоступен
    return null;
  }
} 