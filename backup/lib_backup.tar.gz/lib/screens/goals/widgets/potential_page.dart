import 'package:flutter/material.dart';

class PotentialPage extends StatefulWidget {
  final VoidCallback onNext;

  const PotentialPage({Key? key, required this.onNext}) : super(key: key);

  @override
  _PotentialPageState createState() => _PotentialPageState();
}

class _PotentialPageState extends State<PotentialPage> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'You have great potential to crush your goals',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 48),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildProgressGraph(),
                  SizedBox(height: 32),
                  Text(
                    'Based on JuFit\'s historical data, users with similar profiles achieved their goals within 3-4 months with consistent training.',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                      height: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          ElevatedButton(
            onPressed: widget.onNext,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              padding: EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Next',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressGraph() {
    return Container(
      height: 200,
      child: CustomPaint(
        size: Size.infinite,
        painter: ProgressGraphPainter(),
      ),
    );
  }
}

class ProgressGraphPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.3)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    // Draw grid lines
    for (var i = 0; i < 5; i++) {
      final y = size.height * i / 4;
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        paint..color = Colors.white.withOpacity(0.1),
      );
    }

    // Draw progress curve
    final path = Path();
    path.moveTo(0, size.height * 0.8);

    // Create a smooth curve
    path.quadraticBezierTo(
      size.width * 0.4,
      size.height * 0.7,
      size.width * 0.6,
      size.height * 0.4,
    );
    path.quadraticBezierTo(
      size.width * 0.8,
      size.height * 0.1,
      size.width,
      size.height * 0.2,
    );

    canvas.drawPath(
      path,
      paint
        ..color = Colors.white
        ..strokeWidth = 3,
    );

    // Draw points with emojis
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    
    // Start point
    textPainter.text = TextSpan(text: '👋', style: TextStyle(fontSize: 20));
    textPainter.layout();
    textPainter.paint(canvas, Offset(0, size.height * 0.8 - 10));

    // Middle point
    textPainter.text = TextSpan(text: '💪', style: TextStyle(fontSize: 20));
    textPainter.layout();
    textPainter.paint(canvas, Offset(size.width * 0.6 - 10, size.height * 0.4 - 10));

    // End point
    textPainter.text = TextSpan(text: '🎯', style: TextStyle(fontSize: 20));
    textPainter.layout();
    textPainter.paint(canvas, Offset(size.width - 20, size.height * 0.2 - 10));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
} 