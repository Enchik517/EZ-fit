import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'disclaimer_screen.dart';
import 'onboarding/onboarding_screen.dart';
import 'goals_flow_screen.dart';

class EmailVerificationScreen extends StatefulWidget {
  final String email;
  final String password;

  const EmailVerificationScreen({
    Key? key,
    required this.email,
    required this.password,
  }) : super(key: key);

  @override
  State<EmailVerificationScreen> createState() =>
      _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  bool _isChecking = false;
  bool _isLoading = false;
  Timer? _timer;
  int _attempts = 0;
  late String _password;

  _EmailVerificationScreenState();

  @override
  void initState() {
    super.initState();
    _password = widget.password;
    _startCheckingEmailVerification();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startCheckingEmailVerification() {
    _timer?.cancel();

    //print('Starting verification checking timer...');

    _timer = Timer.periodic(const Duration(seconds: 3), (timer) async {
      if (_attempts >= 60) {
        //print('Maximum verification attempts reached, stopping timer');
        timer.cancel();
        return;
      }

      //print('Verification attempt #${_attempts + 1}');

      if (mounted) {
        setState(() => _isChecking = true);
      }

      try {
        final authProvider = Provider.of<AuthProvider>(context, listen: false);

        final isAuthenticated = await authProvider.checkAuth();

        //print('Authentication check result: $isAuthenticated');

        if (isAuthenticated) {
          //print('User authenticated! Cancelling timer and proceeding');
          timer.cancel();

          if (!mounted) {
            //print('Widget unmounted after authentication');
            return;
          }

          setState(() {
            _isChecking = false;
            _isLoading = true;
          });

          try {
            //print('Signing in with credentials');
            await authProvider.signIn(widget.email, _password);

            if (!mounted) {
              //print('Widget unmounted after sign in');
              return;
            }

            //print('Successfully signed in, navigating to survey screen');
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(builder: (_) => const GoalsFlowScreen()),
            );
          } catch (e) {
            //print('Error signing in after verification: $e');
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Error signing in: $e')),
              );
              setState(() => _isLoading = false);
            }
          }
        } else {
          if (mounted) {
            setState(() {
              _isChecking = false;
              _attempts++;
            });
            //print('Email not verified yet, waiting... (attempt ${_attempts})');
          }
        }
      } catch (e) {
        //print('Error checking verification status: $e');
        if (mounted) {
          setState(() {
            _isChecking = false;
            _attempts++;
          });
        }
      }
    });
  }

  Future<void> _resendVerificationEmail() async {
    try {
      setState(() => _isChecking = true);

      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      await authProvider.resendVerificationEmail(widget.email);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Verification email sent!')),
        );
        setState(() => _isChecking = false);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error sending email: $e')),
        );
        setState(() => _isChecking = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.mail_outline,
                size: 80,
                color: Colors.white,
              ),
              const SizedBox(height: 24),
              Text(
                'Verify your email',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'We\'ve sent a verification email to:\n${widget.email}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey[400],
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 32),
              if (_isLoading)
                CircularProgressIndicator(color: Colors.white)
              else if (_isChecking)
                Column(
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 16),
                    Text(
                      'Checking verification status...',
                      style: TextStyle(color: Colors.grey[400]),
                    ),
                  ],
                )
              else
                ElevatedButton(
                  onPressed: _resendVerificationEmail,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text('Resend Email'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
