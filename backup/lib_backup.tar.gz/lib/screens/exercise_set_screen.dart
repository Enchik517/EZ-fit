import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/exercise.dart';
import '../models/workout_log.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import '../providers/workout_provider.dart';

class ExerciseSetScreen extends StatefulWidget {
  final Exercise exercise;
  final Function(int reps, double weight) onSetComplete;
  final Duration elapsed;
  final String? videoUrl;
  final Exercise? nextExercise;
  final Map<Exercise, List<SetLog>> exerciseSets;
  final Function(Exercise, int, double) updateExerciseSets;

  const ExerciseSetScreen({
    Key? key,
    required this.exercise,
    required this.onSetComplete,
    required this.elapsed,
    this.videoUrl,
    this.nextExercise,
    required this.exerciseSets,
    required this.updateExerciseSets,
  }) : super(key: key);

  @override
  State<ExerciseSetScreen> createState() => _ExerciseSetScreenState();
}

class _ExerciseSetScreenState extends State<ExerciseSetScreen> {
  late VideoPlayerController _videoController;
  late Timer _timer;
  late Duration _elapsed;
  late TextEditingController _repsController;
  late TextEditingController _weightController;
  List<bool> _completedSets = [];
  int _currentSet = 0; // Начинаем с 0
  bool _isResting = false;
  late int _totalSets;
  Timer? _restTimer;
  int _restTimeRemaining = 30;

  @override
  void initState() {
    super.initState();
    _initializeVideo();
    _elapsed = widget.elapsed;
    _startTimer();
    _repsController = TextEditingController(text: widget.exercise.reps);
    _weightController = TextEditingController(text: '50');

    _totalSets = int.parse(widget.exercise.sets);
    _completedSets = List.generate(_totalSets, (index) => false);

    // Восстанавливаем состояние завершенных сетов
    if (widget.exerciseSets.containsKey(widget.exercise)) {
      final completedSetsCount =
          widget.exerciseSets[widget.exercise]?.length ?? 0;
      for (var i = 0; i < completedSetsCount && i < _totalSets; i++) {
        _completedSets[i] = true;
      }
      _currentSet = completedSetsCount;
    }
  }

  Future<void> _initializeVideo() async {
    if (widget.videoUrl != null) {
      _videoController = VideoPlayerController.network(widget.videoUrl!);
      await _videoController.initialize();
      await _videoController.setLooping(true);
      await _videoController.play();
      setState(() {});
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _elapsed += Duration(seconds: 1);
      });
    });
  }

  void _startRestTimer() {
    setState(() {
      _isResting = true;
      _restTimeRemaining = 30;
    });

    _restTimer?.cancel();
    _restTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_restTimeRemaining > 0) {
        setState(() {
          _restTimeRemaining--;
        });
      } else {
        _restTimer?.cancel();
        setState(() {
          _isResting = false;
        });
      }
    });
  }

  void _handleSetComplete() {
    if (_currentSet >= _totalSets) return; // Защита от лишних нажатий

    final reps = int.tryParse(_repsController.text) ?? 0;
    final weight = double.tryParse(_weightController.text) ?? 0;

    setState(() {
      _completedSets[_currentSet] = true;
      _currentSet++;
    });

    // Обновляем сеты для текущего упражнения
    widget.updateExerciseSets(widget.exercise, reps, weight);

    // Сохраняем в историю упражнений
    final workoutProvider =
        Provider.of<WorkoutProvider>(context, listen: false);
    workoutProvider
        .saveExerciseHistory(
      widget.exercise,
      [SetLog(reps: reps, weight: weight)],
      DateTime.now(),
    )
        .catchError((e) {
      //print('Error saving exercise history: $e');
    });

    // Если это упражнение в суперсете
    if (widget.exercise.superSetId != null) {
      // Находим следующее упражнение в суперсете
      final nextExercise = _findNextExerciseInSuperset();

      if (nextExercise != null) {
        // Проверяем, завершены ли все подходы в суперсете
        final allSetsCompleted = _areAllSetsCompleted(nextExercise);

        if (!allSetsCompleted) {
          _navigateToNextExercise(nextExercise);
          return;
        }
      }
    }

    // Если все подходы выполнены или это обычное упражнение
    if (_currentSet >= _totalSets) {
      widget.onSetComplete(reps, weight);
      Navigator.pop(context);
    } else {
      _startRestTimer();
    }
  }

  bool _areAllSetsCompleted(Exercise exercise) {
    final completedSets = widget.exerciseSets[exercise]?.length ?? 0;
    final totalSets = int.parse(exercise.sets);
    return completedSets >= totalSets;
  }

  Exercise? _findNextExerciseInSuperset() {
    if (widget.exercise.superSetId == null) return null;

    // Получаем все упражнения с тем же superSetId
    final supersetExercises = widget.exerciseSets.keys
        .where((e) => e.superSetId == widget.exercise.superSetId)
        .toList();

    // Находим индекс текущего упражнения
    final currentIndex = supersetExercises.indexOf(widget.exercise);

    // Если есть следующее упражнение в суперсете
    if (currentIndex < supersetExercises.length - 1) {
      return supersetExercises[currentIndex + 1];
    }

    // Если это последнее упражнение, возвращаемся к первому
    return supersetExercises[0];
  }

  void _navigateToNextExercise(Exercise nextExercise) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => ExerciseSetScreen(
          exercise: nextExercise,
          onSetComplete: widget.onSetComplete,
          elapsed: _elapsed,
          videoUrl: nextExercise.videoUrl,
          nextExercise: null,
          exerciseSets: widget.exerciseSets,
          updateExerciseSets: widget.updateExerciseSets,
        ),
      ),
    );
  }

  @override
  void dispose() {
    if (widget.videoUrl != null) {
      _videoController.dispose();
    }
    _timer.cancel();
    _restTimer?.cancel();
    _repsController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  Widget _buildSetsSection() {
    return Expanded(
      child: ListView.builder(
        padding: EdgeInsets.symmetric(horizontal: 16),
        itemCount: _totalSets + 1, // +1 для кнопки "Add Set"
        itemBuilder: (context, index) {
          if (index == _totalSets) {
            return Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    margin: EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(4),
                      color: Colors.transparent,
                      border: Border.all(
                        color: Color(0xFFFFD700),
                        width: 2,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        Icons.add,
                        color: Color(0xFFFFD700),
                        size: 16,
                      ),
                    ),
                  ),
                  Text(
                    'Add Set',
                    style: TextStyle(
                      color: Color(0xFFFFD700),
                      fontSize: 16,
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            );
          }

          final isCurrentSet = index == _currentSet;
          final isCompleted = _completedSets[index];

          return Container(
            margin: EdgeInsets.symmetric(vertical: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isCurrentSet)
                  Padding(
                    padding: EdgeInsets.only(left: 32, bottom: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Reps',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontFamily: 'Inter',
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Text(
                              'Weight (kg / lb)',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      margin: EdgeInsets.only(right: 8),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.circular(4),
                        color: isCurrentSet ? Colors.black : Colors.transparent,
                        border: Border.all(
                          color: isCompleted
                              ? Colors.transparent
                              : isCurrentSet
                                  ? Colors.white
                                  : Colors.grey,
                          width: 2,
                        ),
                      ),
                      child: Center(
                        child: isCompleted
                            ? Text('✅', style: TextStyle(fontSize: 18))
                            : Text(
                                (index + 1).toString(),
                                style: TextStyle(
                                  color:
                                      isCurrentSet ? Colors.white : Colors.grey,
                                  fontSize: 14,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFF252527),
                          borderRadius: BorderRadius.circular(8),
                          border: isCurrentSet
                              ? Border.all(color: Colors.white, width: 1)
                              : null,
                        ),
                        child: isCompleted
                            ? Center(
                                child: Text(
                                  _repsController.text,
                                  style: TextStyle(
                                    color: Color(0xFF00BE13),
                                    fontSize: 24,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              )
                            : isCurrentSet
                                ? TextField(
                                    controller: _repsController,
                                    textAlign: TextAlign.center,
                                    keyboardType: TextInputType.number,
                                    style: TextStyle(
                                      color: Color(0xFFFFD700),
                                      fontSize: 24,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: widget.exercise.reps,
                                      hintStyle: TextStyle(
                                        color: Color(0xFFFFD700),
                                        fontSize: 16,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  )
                                : Center(
                                    child: Text(
                                      widget.exercise.reps,
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 24,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color(0xFF252527),
                          borderRadius: BorderRadius.circular(8),
                          border: isCurrentSet
                              ? Border.all(color: Colors.white, width: 1)
                              : null,
                        ),
                        child: isCompleted
                            ? Center(
                                child: Text(
                                  _weightController.text,
                                  style: TextStyle(
                                    color: Color(0xFF00BE13),
                                    fontSize: 24,
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              )
                            : isCurrentSet
                                ? TextField(
                                    controller: _weightController,
                                    textAlign: TextAlign.center,
                                    keyboardType: TextInputType.number,
                                    style: TextStyle(
                                      color: Color(0xFFFFD700),
                                      fontSize: 24,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w700,
                                    ),
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintText: '50',
                                      hintStyle: TextStyle(
                                        color: Color(0xFFFFD700),
                                        fontSize: 16,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  )
                                : Center(
                                    child: Text(
                                      '50',
                                      style: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 24,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black,
              Color(0xFF211B01),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header with timer and close button
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Icon(Icons.close, color: Colors.white, size: 24),
                    ),
                    Text(
                      'Focus Mode',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(width: 24), // For symmetry
                  ],
                ),
              ),

              // Timer
              Text(
                _formatDuration(_elapsed),
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 60,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w800,
                  fontStyle: FontStyle.italic,
                ),
              ),

              // Video preview
              Container(
                height: 200,
                width: double.infinity,
                margin: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                decoration: BoxDecoration(
                  color: Colors.grey[900],
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Stack(
                  children: [
                    if (widget.videoUrl != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: VideoPlayer(_videoController),
                      ),
                    Positioned(
                      left: 16,
                      bottom: 16,
                      child: Text(
                        widget.exercise.name,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Positioned(
                      right: 16,
                      bottom: 16,
                      child: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.play_arrow,
                                color: Colors.white, size: 16),
                            SizedBox(width: 4),
                            Text(
                              'Video',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontFamily: 'Inter',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              _buildSetsSection(),

              // Log set button
              Padding(
                padding: EdgeInsets.all(16),
                child: ElevatedButton(
                  onPressed: _currentSet >= _totalSets
                      ? () => Navigator.pop(context)
                      : _handleSetComplete,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _currentSet >= _totalSets ? '✅' : '✅',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(width: 8),
                      Text(
                        _currentSet >= _totalSets ? 'DONE' : 'LOG SET',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDuration(Duration duration) {
    int hours = duration.inHours;
    int minutes = duration.inMinutes.remainder(60);
    int seconds = duration.inSeconds.remainder(60);
    return '${hours}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }
}
