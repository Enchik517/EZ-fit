import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // Добавьте эту зависимость в pubspec.yaml
import 'goals_flow_screen.dart'; // Импорт экрана опросника для новых пользователей
import 'onboarding/onboarding_screen.dart'; // Импорт экрана онбординга
import '../main.dart' show FirstRunFlag; // Импорт FirstRunFlag из main.dart

class NewAuthScreen extends StatefulWidget {
  const NewAuthScreen({Key? key}) : super(key: key);

  @override
  State<NewAuthScreen> createState() => _NewAuthScreenState();
}

class _NewAuthScreenState extends State<NewAuthScreen>
    with SingleTickerProviderStateMixin {
  bool _isLoading = false;
  late AnimationController _heartController;
  late Animation<double> _heartRotation;

  @override
  void initState() {
    super.initState();
    _heartController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _heartRotation = Tween<double>(begin: 0, end: 0.1).animate(
        CurvedAnimation(parent: _heartController, curve: Curves.easeInOut))
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  void dispose() {
    _heartController.dispose();
    super.dispose();
  }

  Future<void> _continueWithGoogle() async {
    setState(() => _isLoading = true);
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      // Вызываем метод для входа через Google
      await authProvider.signInWithGoogle();

      if (!mounted) return;

      // Добавляем отладочные сообщения
      //debugPrint(
          'Google Sign In completed. isNewUser: ${authProvider.isNewUser}');
      if (authProvider.userProfile != null) {
        //debugPrint(
            'User profile details: ${authProvider.userProfile?.toJson()}');
        //debugPrint(
            'Has completed survey: ${authProvider.userProfile?.hasCompletedSurvey}');
      }

      // Проверяем, нужно ли показать опросник для нового пользователя
      if (authProvider.userProfile != null &&
          !authProvider.userProfile!.hasCompletedSurvey) {
        //debugPrint('Showing GoalsFlowScreen for new Google user');
        // Показываем опросник для сбора данных о пользователе
        await _showSurvey();
      } else {
        //debugPrint('User profile is complete, going to main screen');
        // Переходим на главный экран
        Navigator.pushReplacementNamed(context, '/main');
      }
    } catch (e) {
      //print('Error signing in with Google: $e');
      if (mounted) {
        // Проверяем, была ли это отмена аутентификации пользователем
        if (e.toString().contains('canceled') ||
            e.toString().contains('cancelled') ||
            e.toString().contains('cancel')) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child:
                        Icon(Icons.info_outline, color: Colors.white, size: 20),
                  ),
                  SizedBox(width: 16),
                  Text(
                    'Вход через Google был отменён',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.black.withOpacity(0.9),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              margin: EdgeInsets.all(16),
              duration: Duration(seconds: 3),
              elevation: 8,
              animation: CurvedAnimation(
                parent: const AlwaysStoppedAnimation(1),
                curve: Curves.easeOutCirc,
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.error_outline,
                        color: Colors.white, size: 20),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Не удалось войти через Google',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.red.shade900,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              margin: EdgeInsets.all(16),
              elevation: 8,
              animation: CurvedAnimation(
                parent: const AlwaysStoppedAnimation(1),
                curve: Curves.easeOutCirc,
              ),
            ),
          );
        }
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _continueWithApple() async {
    setState(() => _isLoading = true);
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      // Используем метод авторизации через Apple
      await authProvider.signInWithApple();

      if (!mounted) return;

      // Добавляем отладочные сообщения
      //debugPrint(
          'Apple Sign In completed. isNewUser: ${authProvider.isNewUser}');
      if (authProvider.userProfile != null) {
        //debugPrint(
            'User profile details: ${authProvider.userProfile?.toJson()}');
        //debugPrint(
            'Has completed survey: ${authProvider.userProfile?.hasCompletedSurvey}');
      }

      // Проверяем, нужно ли показать опросник для нового пользователя
      if (authProvider.userProfile != null &&
          !authProvider.userProfile!.hasCompletedSurvey) {
        //debugPrint('Showing GoalsFlowScreen for new Apple user');
        // Показываем опросник для сбора данных о пользователе
        await _showSurvey();
      } else {
        //debugPrint('User profile is complete, going to main screen');
        // Переходим на главный экран
        Navigator.pushReplacementNamed(context, '/main');
      }
    } catch (e) {
      //print('Error signing in with Apple: $e');
      if (mounted) {
        // Проверяем, была ли это отмена аутентификации пользователем
        if (e.toString().contains('canceled') ||
            e.toString().contains('cancelled') ||
            e.toString().contains('cancel')) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child:
                        Icon(Icons.info_outline, color: Colors.white, size: 20),
                  ),
                  SizedBox(width: 16),
                  Text(
                    'Вход через Apple был отменён',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.black.withOpacity(0.9),
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              margin: EdgeInsets.all(16),
              duration: Duration(seconds: 3),
              elevation: 8,
              animation: CurvedAnimation(
                parent: const AlwaysStoppedAnimation(1),
                curve: Curves.easeOutCirc,
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.error_outline,
                        color: Colors.white, size: 20),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Не удалось войти через Apple',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.red.shade900,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              margin: EdgeInsets.all(16),
              elevation: 8,
              animation: CurvedAnimation(
                parent: const AlwaysStoppedAnimation(1),
                curve: Curves.easeOutCirc,
              ),
            ),
          );
        }
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  // Метод для показа опросника
  Future<void> _showSurvey() async {
    if (!mounted) return;

    // Перенаправляем пользователя на экран опросника
    final result = await Navigator.push(context,
        MaterialPageRoute(builder: (context) => const GoalsFlowScreen()));

    if (result != null && mounted) {
      // После завершения опроса обновляем профиль пользователя
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      if (authProvider.userProfile != null) {
        // Обновляем профиль данными из опросника
        final Map<String, dynamic> userData = result as Map<String, dynamic>;

        // Форматируем enum для BodyFatLevel
        String formatBodyFatLevel(dynamic bodyFatLevel) {
          if (bodyFatLevel == null) return '';

          // Убираем префикс "BodyFatLevel."
          String levelStr = bodyFatLevel.toString();
          if (levelStr.contains('BodyFatLevel.')) {
            levelStr = levelStr.replaceAll('BodyFatLevel.', '');

            switch (levelStr) {
              case 'level1':
                return '10-13%';
              case 'level2':
                return '14-17%';
              case 'level3':
                return '18-23%';
              case 'level4':
                return '24-28%';
              case 'level5':
                return '29-33%';
              case 'level6':
                return '34-37%';
              case 'level7':
                return '38-42%';
              case 'level8':
                return '43-49%';
              case 'level9':
                return '50%+';
              default:
                return levelStr;
            }
          }
          return levelStr;
        }

        // Форматируем enum для WorkoutFrequency
        String formatWorkoutFrequency(dynamic frequency) {
          if (frequency == null) return '';

          // Убираем префикс "WorkoutFrequency."
          String freqStr = frequency.toString();
          if (freqStr.contains('WorkoutFrequency.')) {
            freqStr = freqStr.replaceAll('WorkoutFrequency.', '');

            switch (freqStr) {
              case 'none':
                return '0 sessions / week';
              case 'low':
                return '1-3 sessions / week';
              case 'medium':
                return '4-6 sessions / week';
              case 'high':
                return '7+ sessions / week';
              default:
                return freqStr;
            }
          }
          return freqStr;
        }

        final updatedProfile = authProvider.userProfile!.copyWith(
          // Обязательно устанавливаем флаг завершения опроса
          hasCompletedSurvey: true,

          // Обновляем основные данные из результатов опроса
          gender: userData['gender'] as String?,
          birthDate: userData['birthDate'] as DateTime? ??
              authProvider.userProfile!.birthDate,
          height: userData['height'] as double?,
          weight: userData['weight'] as double?,
          fitnessLevel: userData['bodyFatLevel'] != null
              ? formatBodyFatLevel(userData['bodyFatLevel'])
              : authProvider.userProfile!.fitnessLevel,
          goals: userData['selectedGoals'] != null
              ? List<String>.from(userData['selectedGoals'] as List)
              : authProvider.userProfile!.goals,
          weeklyWorkouts: userData['workoutFrequency'] != null
              ? formatWorkoutFrequency(userData['workoutFrequency'])
              : authProvider.userProfile!.weeklyWorkouts,
        );

        await authProvider.saveUserProfile(updatedProfile);
        //debugPrint('Profile updated with survey data');
      }

      // Переходим на главный экран
      Navigator.pushReplacementNamed(context, '/main');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(flex: 1),
              // Вращающееся сердце
              Transform.rotate(
                angle: _heartRotation.value,
                child: const Icon(
                  Icons.favorite,
                  color: Colors.white,
                  size: 48,
                ),
              ),
              const SizedBox(height: 24),
              // Заголовок
              const Text(
                'the body that\nyou always wanted',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  height: 1.2,
                ),
              ),
              const SizedBox(height: 16),
              // Подзаголовок
              Text(
                'with personal AI that understands your goals and creates workouts just for you',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 16,
                  height: 1.4,
                ),
              ),
              const Spacer(flex: 2),
              // Кнопки авторизации
              _buildAuthButton(
                icon: FontAwesomeIcons.apple,
                text: 'Sign in with Apple',
                onPressed: _isLoading ? null : _continueWithApple,
                backgroundColor: Colors.white,
                textColor: Colors.black,
              ),
              const SizedBox(height: 12),
              _buildAuthButton(
                icon: FontAwesomeIcons.google,
                text: 'Sign in with Google',
                onPressed: _isLoading ? null : _continueWithGoogle,
                backgroundColor: Color(0xFFFEF9C3),
                textColor: Colors.black,
              ),
              const Spacer(flex: 1),
              // Условия использования
              Center(
                child: Text.rich(
                  TextSpan(
                    text: 'By continuing, you agree to our ',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.6),
                      fontSize: 12,
                    ),
                    children: [
                      TextSpan(
                        text: 'Terms of Service',
                        style: TextStyle(
                          color: Colors.white,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      TextSpan(text: ' and '),
                      TextSpan(
                        text: 'Privacy Policy',
                        style: TextStyle(
                          color: Colors.white,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ],
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAuthButton({
    required IconData icon,
    required String text,
    required VoidCallback? onPressed,
    required Color backgroundColor,
    required Color textColor,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: textColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          elevation: 0,
          padding: EdgeInsets.zero,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
