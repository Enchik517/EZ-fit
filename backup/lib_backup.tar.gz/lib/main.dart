import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// import 'package:device_preview/device_preview.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/auth_screen.dart';
import 'providers/workout_provider.dart';
import 'theme/app_theme.dart';
import 'package:flutter/foundation.dart';
import 'providers/chat_provider.dart';
import 'providers/survey_provider.dart';
import 'providers/auth_provider.dart';
import 'providers/subscription_provider.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/main_navigation_screen.dart';
import 'screens/disclaimer_screen.dart';
import 'services/auth_service.dart';
import 'services/survey_service.dart';
import 'services/chat_service.dart';
import 'screens/chat_screen.dart';
import 'screens/login_screen.dart';
import 'services/workout_service.dart';
import 'screens/splash_screen.dart';
import 'screens/new_auth_screen.dart';
import 'screens/subscription_screen.dart';
import 'screens/paywall/superwall_screen.dart';
import 'services/superwall_service.dart';
import 'screens/goals_flow_screen.dart';
import 'screens/basics_screen.dart';

// Класс для отслеживания первого запуска
class FirstRunFlag {
  static const String _key = 'has_seen_onboarding';
  static bool _hasBeenShown = false;
  static bool _initialized = false;

  // Инициализирует флаг из SharedPreferences
  static Future<void> initialize() async {
    if (_initialized) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      _hasBeenShown = prefs.getBool(_key) ?? false;
      _initialized = true;
    } catch (e) {
      // Удаляем debugPrint
    }
  }

  // Проверяет, показан ли онбординг
  static bool get hasBeenShown => _hasBeenShown;

  // Устанавливает флаг, что онбординг был показан
  static Future<void> setShown() async {
    _hasBeenShown = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_key, true);
    } catch (e) {
      // Удаляем debugPrint
    }
  }
}

// Класс для отслеживания принятия дисклеймера
class DisclaimerFlag {
  static const String _key = 'has_accepted_disclaimer';
  static bool _hasAccepted = false;
  static bool _initialized = false;

  // Инициализирует флаг из SharedPreferences
  static Future<void> initialize() async {
    if (_initialized) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      _hasAccepted = prefs.getBool(_key) ?? false;
      _initialized = true;
    } catch (e) {
      // Удаляем debugPrint
    }
  }

  // Проверяет, принят ли дисклеймер
  static bool get hasAccepted => _hasAccepted == true;

  // Устанавливает флаг, что дисклеймер был принят
  static Future<void> setAccepted() async {
    _hasAccepted = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_key, true);
    } catch (e) {
      // Удаляем debugPrint
    }
  }
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();

    await dotenv.load();

    final supabaseUrl = dotenv.env['SUPABASE_URL'];
    final supabaseAnonKey = dotenv.env['SUPABASE_ANON_KEY'];

    if (supabaseUrl == null || supabaseAnonKey == null) {
      throw Exception('Missing Supabase URL or Anon Key');
    }

    // Инициализация Supabase
    await Supabase.initialize(
      url: supabaseUrl.trim(),
      anonKey: supabaseAnonKey.trim(),
    );

    // Проверяем, есть ли активная сессия
    final session = await Supabase.instance.client.auth.currentSession;

    // Если есть сессия, обновляем метаданные пользователя
    if (session != null) {
      try {
        // Проверяем наличие флага завершения опроса в базе данных
        final userId = session.user.id;
        final response = await Supabase.instance.client
            .from('user_profiles')
            .select('has_completed_survey')
            .eq('id', userId)
            .single();

        if (response != null && response['has_completed_survey'] == true) {
          // Если опрос пройден в базе данных, обновляем и метаданные пользователя
          await Supabase.instance.client.auth.updateUser(
            UserAttributes(
              data: {
                'has_completed_survey': true,
              },
            ),
          );
        }
      } catch (e) {
        // Удаляем debugPrint
      }
    }

    // Инициализируем флаг первого запуска
    await FirstRunFlag.initialize();

    // Инициализируем флаг принятия дисклеймера
    await DisclaimerFlag.initialize();

    // Инициализация Superwall
    final superwallService = SuperwallService();
    await superwallService.initialize();

    // Загружаем упражнения после инициализации Supabase
    await WorkoutService.loadExercises();

    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(
            create: (_) {
              final provider = WorkoutProvider();
              // Загружаем статистику при создании провайдера
              Future.microtask(() => provider.loadStatistics());
              return provider;
            },
          ),
          ChangeNotifierProxyProvider<WorkoutProvider, AuthProvider>(
            create: (context) => AuthProvider(context.read<WorkoutProvider>()),
            update: (context, workoutProvider, previous) =>
                previous ?? AuthProvider(workoutProvider),
          ),
          Provider<SurveyService>(create: (_) => SurveyService()),
          ChangeNotifierProxyProvider<SurveyService, SurveyProvider>(
            create: (context) => SurveyProvider(context.read<SurveyService>()),
            update: (context, surveyService, previous) =>
                previous ?? SurveyProvider(surveyService),
          ),
          ChangeNotifierProvider(create: (_) => AuthService()),
          Provider<ChatService>(create: (_) => ChatService()),
          ChangeNotifierProxyProvider<ChatService, ChatProvider>(
            create: (context) => ChatProvider(context.read<ChatService>()),
            update: (context, chatService, previous) =>
                previous ?? ChatProvider(chatService),
          ),
          ChangeNotifierProvider(create: (_) => SubscriptionProvider()),
        ],
        child: const MyApp(),
      ),
    );
  } catch (e) {
    // Удаляем debugPrint
    rethrow;
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Инициализируем AuthProvider при старте приложения
    Future.delayed(Duration.zero, () {
      Provider.of<AuthProvider>(context, listen: false).initialize();
      // Инициализируем SubscriptionProvider
      Provider.of<SubscriptionProvider>(context, listen: false).initialize();
    });

    return MaterialApp(
      navigatorKey: navigatorKey,
      // useInheritedMediaQuery: true,
      // locale: DevicePreview.locale(context),
      // builder: DevicePreview.appBuilder,
      title: 'Fitness App',
      theme: AppTheme.darkTheme,
      home: Consumer<AuthProvider>(
        builder: (context, authProvider, _) {
          if (authProvider.isLoading) {
            return const SplashScreen();
          }

          // Проверяем, был ли показан онбординг (первый запуск приложения)
          final bool isFirstRun = _isFirstRun();

          // Если это первый запуск, ВСЕГДА показываем онбординг перед авторизацией
          if (isFirstRun) {
            return OnboardingScreen(
              onComplete: () {
                // Помечаем, что онбординг показан
                _setFirstRunCompleted();
                // После онбординга направляем на экран авторизации
                Navigator.of(navigatorKey.currentContext!)
                    .pushReplacementNamed('/auth');
              },
            );
          }

          // Если пользователь авторизован
          if (authProvider.user != null) {
            // Если дисклеймер принят локально, обновляем состояние провайдера
            if (DisclaimerFlag.hasAccepted) {
              // Синхронизируем статус с провайдером
              if (!authProvider.hasAcceptedDisclaimer) {
                authProvider.setDisclaimerAccepted(true);
              }

              // Проверяем статус опроса
              // Используем профиль пользователя для проверки hasCompletedSurvey,
              // так как hasCompletedSurvey() - это асинхронный метод
              final profile = authProvider.userProfile;

              if (profile == null || profile.hasCompletedSurvey == false) {
                return const GoalsFlowScreen();
              }

              // Переходим на главный экран
              return const MainNavigationScreen();
            } else {
              // Дисклеймер еще не был принят
              return const DisclaimerScreen();
            }
          }

          // Если есть аноним, удаляем его при запуске
          if (kIsWeb) {
            return const NewAuthScreen();
          }

          final user = authProvider.user;
          if (user == null) {
            // Пользователь не авторизован, показываем экран входа
            return const NewAuthScreen();
          }

          final profile = authProvider.userProfile;
          if (profile == null || profile.height == 0 || profile.weight == 0) {
            return const BasicsScreen();
          }

          // Если есть рост и вес, сразу считаем опрос пройденным
          if (profile.height! > 0 &&
              profile.weight! > 0 &&
              !profile.hasCompletedSurvey) {
            WidgetsBinding.instance.addPostFrameCallback((_) async {
              // Обновляем профиль
              await authProvider
                  .saveUserProfile(profile.copyWith(hasCompletedSurvey: true));

              // Обновляем метаданные пользователя
              await authProvider.updateSurveyCompletionFlag(true);
            });
          }

          // Проверяем как флаг профиля, так и метаданные пользователя
          // Если хотя бы один из них указывает, что опрос пройден - считаем его пройденным
          final hasCompletedSurveyInProfile = profile.hasCompletedSurvey;
          final hasCompletedSurveyInMetadata =
              authProvider.hasSurveyCompletionFlag();
          final hasCompletedSurvey =
              hasCompletedSurveyInProfile || hasCompletedSurveyInMetadata;

          if (!hasCompletedSurvey) {
            // ВАЖНО: Проверяем флаг напрямую в базе данных перед показом опроса
            // Возвращаем временный экран загрузки, пока проверяем статус опроса
            return FutureBuilder<bool>(
              future: authProvider.forceCheckSurveyCompletionInDatabase(),
              builder: (context, snapshot) {
                // Если данные загружены
                if (snapshot.connectionState == ConnectionState.done) {
                  // Проверяем результат
                  if (snapshot.data == true) {
                    // Если в базе данных опрос отмечен как пройденный
                    WidgetsBinding.instance.addPostFrameCallback((_) async {
                      // Обновляем профиль
                      await authProvider.saveUserProfile(
                          profile.copyWith(hasCompletedSurvey: true));

                      // Обновляем метаданные пользователя
                      await authProvider.updateSurveyCompletionFlag(true);
                    });

                    // Возвращаем главный экран
                    return const MainNavigationScreen();
                  } else {
                    // Если опрос действительно не пройден, показываем его
                    return const GoalsFlowScreen();
                  }
                }

                // Пока проверяем, показываем индикатор загрузки
                return const Scaffold(
                  backgroundColor: Colors.black,
                  body: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              },
            );
          }

          // Если всё в порядке - переходим на главный экран
          return const MainNavigationScreen();
        },
      ),
      routes: {
        '/auth': (context) => const NewAuthScreen(),
        '/login': (context) => LoginScreen(),
        '/main': (context) => const MainNavigationScreen(),
        '/onboarding': (context) => const OnboardingScreen(),
        '/basics': (context) => const BasicsScreen(),
        '/chat': (context) => const ChatScreen(),
        '/subscription': (context) => const SubscriptionScreen(),
        '/paywall': (context) {
          // Обертка для экрана paywall для перехода на главный экран
          // при нажатии кнопки Назад
          return WillPopScope(
            onWillPop: () async {
              // Переходим на главный экран при нажатии кнопки "Назад"
              Navigator.of(context).pushReplacementNamed('/main');
              return false;
            },
            child: const SuperwallScreen(),
          );
        },
      },
      debugShowCheckedModeBanner: false,
    );
  }

  // Проверяет, является ли это первым запуском приложения
  bool _isFirstRun() {
    // Получаем значение из FirstRunFlag
    return !FirstRunFlag.hasBeenShown;
  }

  // Помечает первый запуск как завершенный
  void _setFirstRunCompleted() {
    // Сохраняем значение через FirstRunFlag
    FirstRunFlag.setShown();
  }
}
