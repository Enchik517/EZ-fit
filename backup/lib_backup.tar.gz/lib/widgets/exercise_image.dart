import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

class ExerciseImage extends StatelessWidget {
  final String exerciseName;

  ExerciseImage({required this.exerciseName});

  String _getExerciseImageUrl(String name) {
    final Map<String, String> imageUrls = {
      // Bodyweight exercises
      'Push-ups': 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=800',
      'Squats': 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=800',
      'Pull-ups': 'https://images.unsplash.com/photo-1598971639058-fab3c3109a00?w=800',
      'Lunges': 'https://images.unsplash.com/photo-1597452485669-2c7bb5fef90d?w=800',
      'Plank': 'https://images.unsplash.com/photo-1566241142559-40e1dab266c6?w=800',

      // Dumbbell exercises
      'Dumbbell Rows': 'https://images.unsplash.com/photo-1603287681836-b174ce5074c2?w=800',
      'Dumbbell Press': 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=800',
      'Dumbbell Curls': 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=800',

      // Compound exercises
      'Deadlift': 'https://images.unsplash.com/photo-1604047095469-78a4c3a91c30?w=800',
      'Bench Press': 'https://images.unsplash.com/photo-1534368959876-26bf04f2c947?w=800',

      // Warmup & Cooldown
      'Dynamic Warm-up': 'https://images.unsplash.com/photo-1601422407692-ec4eeec1d9b3?w=800',
      'Cool-down Stretches': 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800',

      // Core exercises
      'Crunches': 'https://images.unsplash.com/photo-1544216428-10c1ec0e76c1?w=800',
      'Russian Twists': 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=800',

      // Cardio
      'Running': 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=800',
      'Jump Rope': 'https://images.unsplash.com/photo-1434596922112-19c563067271?w=800',
    };

    // Return the specific exercise image or a default fitness image
    return imageUrls[name] ?? 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?w=800';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            CachedNetworkImage(
              imageUrl: _getExerciseImageUrl(exerciseName),
              fit: BoxFit.cover,
              width: double.infinity,
              height: double.infinity,
              placeholder: (context, url) => Container(
                color: Colors.grey[900],
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white70),
                        strokeWidth: 2,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Loading exercise...',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
              errorWidget: (context, url, error) => Container(
                color: Colors.grey[900],
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.fitness_center,
                      size: 48,
                      color: Colors.grey[700],
                    ),
                    SizedBox(height: 12),
                    Text(
                      exerciseName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            // Semi-transparent gradient overlay
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.8),
                      Colors.transparent,
                    ],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      exerciseName,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
} 