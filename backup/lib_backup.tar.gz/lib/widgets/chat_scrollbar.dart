import 'package:flutter/material.dart';

class ChatScrollbar extends StatelessWidget {
  final Widget child;
  final ScrollController scrollController;
  final Color? thumbColor;
  final double thickness;

  const ChatScrollbar({
    super.key,
    required this.child,
    required this.scrollController,
    this.thumbColor,
    this.thickness = 8.0,
  });

  @override
  Widget build(BuildContext context) {
    return RawScrollbar(
      thumbColor: thumbColor ?? Colors.grey.withOpacity(0.5),
      thickness: thickness,
      radius: const Radius.circular(20),
      controller: scrollController,
      child: child,
    );
  }
}

class ChatListView extends StatelessWidget {
  final ScrollController scrollController;
  final List<Widget> children;

  const ChatListView({
    super.key,
    required this.scrollController,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return ChatScrollbar(
      scrollController: scrollController,
      child: ListView(
        controller: scrollController,
        padding: const EdgeInsets.all(8),
        shrinkWrap: true,
        children: children,
      ),
    );
  }
}

class ChatSingleChildScrollView extends StatelessWidget {
  final ScrollController scrollController;
  final Widget child;

  const ChatSingleChildScrollView({
    super.key,
    required this.scrollController,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return ChatScrollbar(
      scrollController: scrollController,
      child: SingleChildScrollView(
        controller: scrollController,
        child: child,
      ),
    );
  }
} 