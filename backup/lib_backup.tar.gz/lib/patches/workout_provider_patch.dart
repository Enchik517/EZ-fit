import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import '../providers/workout_provider.dart';
import '../models/workout.dart';

/// This extension adds debug logging and improved error handling to the WorkoutProvider
extension WorkoutProviderPatch on WorkoutProvider {
  /// Patched method to save workout to history with extra logging and error handling
  Future<bool> saveWorkoutToHistoryWithLogging(Workout workout) async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (kDebugMode)
          //debugPrint('No user ID available for saving workout to history');
        return false;
      }

      // Log the attempt
      if (kDebugMode)
        //debugPrint('Attempting to save workout to history: ${workout.name}');

      // Check if workout already exists in history
      final existing = await Supabase.instance.client
          .from('workout_history')
          .select()
          .eq('user_id', userId)
          .eq('workout_id', workout.id)
          .maybeSingle();

      if (existing != null) {
        if (kDebugMode)
          //debugPrint('Workout already exists in history: ${workout.id}');
        return true;
      }

      // Format the data for insert
      final data = {
        'user_id': userId,
        'workout_id': workout.id,
        'workout_name': workout.name,
        'created_at': DateTime.now().toIso8601String(),
      };

      // Insert into history
      await Supabase.instance.client.from('workout_history').insert(data);

      if (kDebugMode)
        //debugPrint('Workout saved to history successfully: ${workout.name}');
      return true;
    } catch (e) {
      //if (kDebugMode) //debugPrint('Error saving workout to history: $e');
      return false;
    }
  }

  /// Patched method to toggle favorite status with extra logging and error handling
  Future<bool> toggleFavoriteWithLogging(Workout workout) async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (kDebugMode)
          //debugPrint('No user ID available for toggling favorite');
        return false;
      }

      // Check current favorite status
      final existing = await Supabase.instance.client
          .from('favorite_workouts')
          .select()
          .eq('user_id', userId)
          .eq('workout_id', workout.id)
          .maybeSingle();

      // Log the attempt
      if (kDebugMode)
        //debugPrint(
            'Toggling favorite status for workout: ${workout.name}, current status: ${existing != null ? 'favorite' : 'not favorite'}');

      if (existing != null) {
        // Remove from favorites
        await Supabase.instance.client
            .from('favorite_workouts')
            .delete()
            .eq('id', existing['id']);

        if (kDebugMode)
          //debugPrint('Workout removed from favorites: ${workout.name}');
        return false; // No longer a favorite
      } else {
        // Add to favorites
        final data = {
          'user_id': userId,
          'workout_id': workout.id,
          'workout_name': workout.name,
          'created_at': DateTime.now().toIso8601String(),
        };

        await Supabase.instance.client.from('favorite_workouts').insert(data);

        if (kDebugMode)
          //debugPrint('Workout added to favorites: ${workout.name}');
        return true; // Now a favorite
      }
    } catch (e) {
      //if (kDebugMode) //debugPrint('Error toggling favorite status: $e');
      return false;
    }
  }

  /// Verify that workout data is stored correctly
  Future<Map<String, dynamic>> verifyWorkoutData() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        return {'success': false, 'error': 'No user ID available'};
      }

      // Check workout history
      final historyResponse = await Supabase.instance.client
          .from('workout_history')
          .select('count')
          .eq('user_id', userId)
          .single();

      final historyCount = historyResponse['count'] as int? ?? 0;

      // Check favorites
      final favoritesResponse = await Supabase.instance.client
          .from('favorite_workouts')
          .select('count')
          .eq('user_id', userId)
          .single();

      final favoritesCount = favoritesResponse['count'] as int? ?? 0;

      // Log the counts
      //debugPrint('History: $historyCount, Favorites: $favoritesCount');

      return {
        'success': true,
        'history_count': historyCount,
        'favorites_count': favoritesCount,
      };
    } catch (e) {
      //debugPrint('Failed to verify workout data: $e');
      return {'success': false, 'error': e.toString()};
    }
  }
}

/// Widget to add to the app that provides a debugging overlay
class WorkoutDebugOverlay extends StatelessWidget {
  final Widget child;

  const WorkoutDebugOverlay({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton(
            heroTag: 'workout_debug',
            mini: true,
            backgroundColor: Colors.black45,
            child: const Icon(Icons.bug_report, color: Colors.white),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => WorkoutDiagnosticsScreen(),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// Diagnostics screen (imported from the main file)
class WorkoutDiagnosticsScreen extends StatelessWidget {
  const WorkoutDiagnosticsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Workout Diagnostics'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushReplacementNamed(context, '/workout-diagnostics');
          },
          child: const Text('Open Full Diagnostics'),
        ),
      ),
    );
  }
}
